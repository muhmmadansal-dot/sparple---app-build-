#!/usr/bin/env bash
set -e

echo "🔮 Setting up Sparple build environment..."

# Install JS dependencies
npm install

# Add Android platform if not already present
if [ ! -d "android/app/build" ]; then
  echo "📱 Syncing Capacitor Android project..."
fi

# Build the web assets first
npm run build

# Sync Capacitor (copies dist/ into android project, updates native deps)
npx cap sync android

# Generate the proper Gradle wrapper (includes the binary jar Capacitor needs)
cd android
if command -v gradle >/dev/null 2>&1; then
  gradle wrapper --gradle-version 8.4
  chmod +x gradlew
else
  echo "⚠️  'gradle' command not found. Install Gradle or run 'gradle wrapper --gradle-version 8.4' manually inside android/ before building."
fi
cd ..

echo "✅ Setup complete!"
echo ""
echo "To build a debug APK manually, run:"
echo "  cd android && ./gradlew assembleDebug"
echo ""
echo "Or just push to main — GitHub Actions will build it for you."
