package com.sparple.vault;

import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;

import com.getcapacitor.BridgeActivity;
import com.getcapacitor.BridgeWebViewClient;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/**
 * Injects Cross-Origin-Embedder-Policy and Cross-Origin-Opener-Policy headers
 * into every WebView response.  This enables self.crossOriginIsolated = true,
 * which unlocks SharedArrayBuffer and therefore multi-threaded WASM in the
 * ONNX Runtime — making our semantic search model run 2–4× faster.
 *
 * Even on Android versions where full cross-origin isolation is not honoured,
 * these headers are harmless and we have numThreads=1 as a safety net.
 */
public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Override the WebViewClient that Capacitor installs so we can inject
        // security headers on every response served from the local asset bundle.
        getBridge().getWebView().setWebViewClient(new BridgeWebViewClient(getBridge()) {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                WebResourceResponse response = super.shouldInterceptRequest(view, request);
                if (response != null) {
                    Map<String, String> headers = new HashMap<>();
                    if (response.getResponseHeaders() != null) {
                        headers.putAll(response.getResponseHeaders());
                    }
                    // These two headers enable crossOriginIsolated mode, which
                    // unlocks SharedArrayBuffer for multi-threaded WASM.
                    headers.put("Cross-Origin-Embedder-Policy", "require-corp");
                    headers.put("Cross-Origin-Opener-Policy", "same-origin");
                    // Ensure WASM and other binary content is served correctly.
                    headers.put("Cross-Origin-Resource-Policy", "cross-origin");
                    response.setResponseHeaders(headers);
                }
                return response;
            }
        });
    }
}
