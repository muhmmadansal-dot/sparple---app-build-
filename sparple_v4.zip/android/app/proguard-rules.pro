# Capacitor / WebView
-keep class com.getcapacitor.** { *; }
-keep public class * extends com.getcapacitor.Plugin
-dontwarn com.getcapacitor.**
