/**
 * Copies onnxruntime-web WASM + loader JS files into public/ at build time.
 *
 * CONFIRMED root cause (from an actual GitHub Actions build log, not a guess):
 * @xenova/transformers@2.17.2 bootstraps ONNX Runtime via a file called
 * ort-web.min.js. A previous version of this script only copied ort.min.js
 * and ort.js — never ort-web.min.js — so the loader file the runtime
 * actually needs was silently missing from the APK. Result: the app tried
 * to load ONNX Runtime, its own bootstrap file was 404, and it surfaced as:
 *   "both async and sync fetching of the wasm failed"
 * with no build-time warning, because the script exited 0 either way.
 *
 * Fix: copy EVERY .wasm file and EVERY ort*.js/.mjs file from
 * onnxruntime-web/dist, no allowlist of "the ones we think we need." This
 * also checks the @xenova/transformers-nested onnxruntime-web dist first,
 * in case a future version pins its own copy — falling back to top-level
 * if that nested folder doesn't exist (which is the case as of 2.17.2).
 *
 * Hard-fails the build (non-zero exit) if either the wasm files or the
 * loader JS files are missing, instead of silently shipping a broken APK.
 */
import { copyFileSync, existsSync, mkdirSync, readdirSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'

const __dirname = dirname(fileURLToPath(import.meta.url))
const root = join(__dirname, '..')
const destDir = join(root, 'public')

if (!existsSync(destDir)) mkdirSync(destDir, { recursive: true })

const candidates = [
  join(root, 'node_modules', '@xenova', 'transformers', 'node_modules', 'onnxruntime-web', 'dist'),
  join(root, 'node_modules', 'onnxruntime-web', 'dist'),
]

const ortDist = candidates.find(existsSync)

if (!ortDist) {
  console.error('[Sparple] FATAL: could not find onnxruntime-web/dist in either:')
  candidates.forEach(c => console.error('  - ' + c))
  console.error('[Sparple] Run `npm install` first. Aborting build — shipping without')
  console.error('           these files means semantic search will be broken in the APK.')
  process.exit(1)
}

console.log(`[Sparple] Using onnxruntime-web dist: ${ortDist}`)

// Copy every .wasm file. We keep ALL variants (not just non-threaded) because
// which one gets requested depends on runtime SharedArrayBuffer detection —
// better to have all of them present than guess wrong and 404.
const wasmFiles = readdirSync(ortDist).filter(f => f.endsWith('.wasm'))

if (wasmFiles.length === 0) {
  console.error(`[Sparple] FATAL: ${ortDist} exists but contains no .wasm files.`)
  console.error('[Sparple] onnxruntime-web may have changed its dist layout. Aborting build.')
  process.exit(1)
}

for (const file of wasmFiles) {
  copyFileSync(join(ortDist, file), join(destDir, file))
  console.log(`[Sparple] Copied ${file} -> public/${file}`)
}

// Copy every .mjs/.js file whose name contains "ort" — this is deliberately
// broad. The bug that caused "both async and sync fetching of the wasm
// failed" in production was this script only copying ort.min.js/ort.js,
// while @xenova/transformers@2.17.2 actually bootstraps ONNX Runtime via
// ort-web.min.js (confirmed from the real Vite build log referencing
// node_modules/onnxruntime-web/dist/ort-web.min.js). Missing that one file
// silently breaks the WASM loader at runtime with no build-time warning.
// Copying every ort*.js/.mjs file up front means we can never miss the
// "right" one again, regardless of which loader file a future version uses.
const jsCompanions = readdirSync(ortDist).filter(f =>
  (f.endsWith('.mjs') || f.endsWith('.js')) && f.toLowerCase().includes('ort')
)

if (jsCompanions.length === 0) {
  console.error(`[Sparple] FATAL: no ort*.js / ort*.mjs loader files found in ${ortDist}.`)
  console.error('[Sparple] Without a loader file, the .wasm binaries alone are useless.')
  process.exit(1)
}

for (const file of jsCompanions) {
  copyFileSync(join(ortDist, file), join(destDir, file))
  console.log(`[Sparple] Copied ${file} -> public/${file}`)
}

console.log(`[Sparple] ONNX WASM copy complete: ${wasmFiles.length} wasm file(s), ${jsCompanions.length} loader file(s) copied.`)
