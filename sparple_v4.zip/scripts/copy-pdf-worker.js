/**
 * Copies the pdf.js worker file from node_modules into public/
 * so it's available at runtime without needing a CDN (fully offline).
 */
import { copyFileSync, existsSync, mkdirSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'

const __dirname = dirname(fileURLToPath(import.meta.url))
const root = join(__dirname, '..')

const src = join(root, 'node_modules', 'pdfjs-dist', 'build', 'pdf.worker.min.mjs')
const srcFallback = join(root, 'node_modules', 'pdfjs-dist', 'build', 'pdf.worker.min.js')
const destDir = join(root, 'public')
const dest = join(destDir, 'pdf.worker.min.js')

if (!existsSync(destDir)) mkdirSync(destDir, { recursive: true })

if (existsSync(src)) {
  copyFileSync(src, dest)
  console.log('[Sparple] Copied pdf.worker.min.mjs -> public/pdf.worker.min.js')
} else if (existsSync(srcFallback)) {
  copyFileSync(srcFallback, dest)
  console.log('[Sparple] Copied pdf.worker.min.js -> public/pdf.worker.min.js')
} else {
  console.warn('[Sparple] WARNING: pdf.worker file not found in node_modules. PDF text extraction may fail.')
}
