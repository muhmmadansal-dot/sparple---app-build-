import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import styles from './OnboardingScreen.module.css'

const SLIDES = [
  {
    icon: '🔍',
    title: 'Scan Docs & Screenshots',
    desc: 'Sparple scans your Downloads, Documents, and Screenshots in one tap. Nothing else.',
    color: '#7C6FFF',
  },
  {
    icon: '🧠',
    title: 'Understands Your Files',
    desc: 'Passports, marksheets, bills, chat screenshots — identified automatically. Nothing leaves your phone.',
    color: '#A855F7',
  },
  {
    icon: '⚡',
    title: 'Find Anything Instantly',
    desc: 'Real on-device AI search — type what you remember, like "that beach screenshot" or "my passport".',
    color: '#60A5FA',
  },
]

export default function OnboardingScreen() {
  const navigate = useNavigate()
  const [step, setStep] = useState(0)

  const next = () => {
    if (step < SLIDES.length - 1) setStep(step + 1)
    else {
      localStorage.setItem('sparple_onboarded', '1')
      navigate('/', { replace: true })
    }
  }

  const slide = SLIDES[step]

  return (
    <div className={styles.screen}>
      <div className={styles.skip} onClick={() => { localStorage.setItem('sparple_onboarded', '1'); navigate('/', { replace: true }) }}>
        Skip
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={step}
          className={styles.content}
          initial={{ opacity: 0, x: 40 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -40 }}
          transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] }}
        >
          <motion.div
            className={styles.iconWrap}
            style={{ background: `${slide.color}20`, border: `1px solid ${slide.color}30` }}
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <span className={styles.icon}>{slide.icon}</span>
          </motion.div>
          <h1 className={styles.title}>{slide.title}</h1>
          <p className={styles.desc}>{slide.desc}</p>
        </motion.div>
      </AnimatePresence>

      <div className={styles.bottom}>
        <div className={styles.dots}>
          {SLIDES.map((_, i) => (
            <motion.div
              key={i}
              className={styles.dot}
              animate={{ width: i === step ? 24 : 8, background: i === step ? '#7C6FFF' : 'rgba(255,255,255,0.2)' }}
              transition={{ duration: 0.3 }}
            />
          ))}
        </div>
        <motion.button className={styles.btn} onClick={next} whileTap={{ scale: 0.96 }}>
          {step < SLIDES.length - 1 ? 'Next' : 'Get Started'}
        </motion.button>
      </div>
    </div>
  )
}
