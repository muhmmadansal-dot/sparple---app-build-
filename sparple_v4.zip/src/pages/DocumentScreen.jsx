import React, { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { getDocuments, updateDocumentLabel, renameDocument, toggleStar } from '../services/database.js'
import { DOC_TYPES, DOC_LABELS, DOC_CATEGORIES, getSystemLabels } from '../services/classifier.js'
import { persistDB } from '../services/database.js'
import { useAppContext } from '../hooks/useAppContext.jsx'
import styles from './DocumentScreen.module.css'

export default function DocumentScreen() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { refreshStats } = useAppContext()
  const [doc, setDoc] = useState(null)
  const [showRename, setShowRename] = useState(false)
  const [showRelabel, setShowRelabel] = useState(false)
  const [newName, setNewName] = useState('')
  const [starred, setStarred] = useState(false)

  useEffect(() => {
    const results = getDocuments({ limit: 1 })
    // fetch by id
    const all = getDocuments({ limit: 9999 })
    const found = all.find(d => String(d.id) === String(id))
    if (found) {
      setDoc(found)
      setNewName(found.suggested_name || found.name)
      setStarred(found.is_starred === 1)
    }
  }, [id])

  const handleStar = async () => {
    toggleStar(doc.id)
    await persistDB()
    setStarred(!starred)
    refreshStats()
  }

  const handleRename = async () => {
    if (!newName.trim()) return
    renameDocument(doc.id, newName.trim())
    await persistDB()
    setDoc({ ...doc, name: newName.trim() })
    setShowRename(false)
    refreshStats()
  }

  const handleRelabel = async (type) => {
    const label = DOC_LABELS[type]
    const category = DOC_CATEGORIES[type]
    updateDocumentLabel(doc.id, type, label, category)
    await persistDB()
    setDoc({ ...doc, type, label, category, needs_review: 0 })
    setShowRelabel(false)
    refreshStats()
  }

  if (!doc) return (
    <div className={styles.loading}>
      <motion.div className={styles.spinner} animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }} />
    </div>
  )

  const labels = doc.all_labels ? doc.all_labels.split('|') : []
  const ext = doc.name?.split('.').pop()?.toUpperCase() || 'FILE'

  return (
    <div className={styles.screen}>
      {/* Header */}
      <div className={styles.header}>
        <motion.button className={styles.backBtn} onClick={() => navigate(-1)} whileTap={{ scale: 0.9 }}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <path d="M15 18L9 12L15 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </motion.button>
        <span className={styles.headerTitle}>Document</span>
        <motion.button className={styles.starBtn} onClick={handleStar} whileTap={{ scale: 0.8 }}>
          {starred ? '⭐' : '☆'}
        </motion.button>
      </div>

      <div className={styles.scroll}>
        {/* Document hero */}
        <motion.div className={styles.hero} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
          <div className={styles.heroIcon}>
            <span style={{ fontSize: 36 }}>{getTypeIcon(doc.type)}</span>
            <span className={styles.extTag}>{ext}</span>
          </div>
          <h1 className={styles.docName}>{doc.name}</h1>
          <div className={styles.heroMeta}>
            <span className={styles.heroCat} style={{ color: getCatColor(doc.category) }}>{doc.label}</span>
            {doc.confidence > 0 && <span className={styles.heroConf}>{doc.confidence}% confident</span>}
          </div>
          {doc.needs_review === 1 && (
            <div className={styles.reviewAlert}>
              ⚠️ Couldn't identify this document. Tap "Change Type" to label it.
            </div>
          )}
        </motion.div>

        {/* Labels */}
        {labels.length > 0 && (
          <motion.div className={styles.section} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }}>
            <p className={styles.sectionTitle}>Labels</p>
            <div className={styles.labelWrap}>
              {labels.map(l => <span key={l} className={styles.labelTag}>{l}</span>)}
            </div>
          </motion.div>
        )}

        {/* Suggested rename */}
        {doc.suggested_name && doc.suggested_name !== doc.name && (
          <motion.div className={styles.section} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.15 }}>
            <p className={styles.sectionTitle}>Suggested Name</p>
            <div className={styles.suggestedRow}>
              <span className={styles.suggestedName}>{doc.suggested_name}</span>
              <button className={styles.applyBtn} onClick={() => { setNewName(doc.suggested_name); setShowRename(true) }}>
                Apply
              </button>
            </div>
          </motion.div>
        )}

        {/* File info */}
        <motion.div className={styles.section} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}>
          <p className={styles.sectionTitle}>File Info</p>
          <div className={styles.infoGrid}>
            <InfoRow label="Path" value={doc.path} mono />
            <InfoRow label="Size" value={formatSize(doc.file_size)} />
            <InfoRow label="Type" value={doc.mime_type || '—'} />
            <InfoRow label="Indexed" value={formatDate(doc.indexed_at)} />
          </div>
        </motion.div>

        {/* Extracted text preview */}
        {doc.extracted_text && doc.extracted_text.length > 10 && (
          <motion.div className={styles.section} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.25 }}>
            <p className={styles.sectionTitle}>Extracted Text</p>
            <div className={styles.textPreview}>
              {doc.extracted_text.substring(0, 300)}
              {doc.extracted_text.length > 300 && <span className={styles.textMore}>…</span>}
            </div>
          </motion.div>
        )}

        {/* Actions */}
        <motion.div className={styles.actions} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}>
          <ActionButton icon="✏️" label="Rename File" onClick={() => setShowRename(true)} />
          <ActionButton icon="🏷️" label="Change Type" onClick={() => setShowRelabel(true)} accent={doc.needs_review === 1} />
        </motion.div>

        <div style={{ height: 40 }} />
      </div>

      {/* Rename modal */}
      <AnimatePresence>
        {showRename && (
          <Modal title="Rename File" onClose={() => setShowRename(false)}>
            <input
              className={styles.renameInput}
              value={newName}
              onChange={e => setNewName(e.target.value)}
              autoFocus
              onKeyDown={e => e.key === 'Enter' && handleRename()}
            />
            <p className={styles.renameNote}>This renames the actual file on your device.</p>
            <button className={styles.confirmBtn} onClick={handleRename}>Rename</button>
          </Modal>
        )}
      </AnimatePresence>

      {/* Relabel modal */}
      <AnimatePresence>
        {showRelabel && (
          <Modal title="What type is this?" onClose={() => setShowRelabel(false)}>
            <div className={styles.typeList}>
              {Object.entries(DOC_LABELS).filter(([k]) => k !== 'unknown').map(([type, label]) => (
                <button
                  key={type}
                  className={`${styles.typeBtn} ${doc.type === type ? styles.typeBtnActive : ''}`}
                  onClick={() => handleRelabel(type)}
                >
                  <span>{getTypeIcon(type)}</span>
                  <span>{label}</span>
                </button>
              ))}
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  )
}

function Modal({ title, children, onClose }) {
  return (
    <motion.div
      className={styles.modalOverlay}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
    >
      <motion.div
        className={styles.modal}
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', stiffness: 400, damping: 40 }}
        onClick={e => e.stopPropagation()}
      >
        <div className={styles.modalHandle} />
        <p className={styles.modalTitle}>{title}</p>
        {children}
      </motion.div>
    </motion.div>
  )
}

function InfoRow({ label, value, mono }) {
  return (
    <div className={styles.infoRow}>
      <span className={styles.infoLabel}>{label}</span>
      <span className={`${styles.infoValue} ${mono ? styles.mono : ''}`}>{value || '—'}</span>
    </div>
  )
}

function ActionButton({ icon, label, onClick, accent }) {
  return (
    <motion.button
      className={`${styles.actionBtn} ${accent ? styles.actionBtnAccent : ''}`}
      onClick={onClick}
      whileTap={{ scale: 0.96 }}
    >
      <span>{icon}</span>
      <span>{label}</span>
    </motion.button>
  )
}

function getTypeIcon(type) {
  const map = {
    passport:'🛂', aadhaar:'🪪', pan:'💳', voter_id:'🗳️',
    driving_license:'🚗', birth_certificate:'👶', tenth_marksheet:'📚',
    twelfth_marksheet:'📚', degree_certificate:'🎓', college_id:'🏫',
    medical_report:'🩺', prescription:'💊', insurance:'🛡️',
    bank_statement:'🏦', salary_slip:'💰', itr:'📊', gst_invoice:'🧾',
    electricity_bill:'⚡', gas_bill:'🔥', water_bill:'💧', mobile_bill:'📱',
    receipt:'🧾', amazon_receipt:'📦', flight_ticket:'✈️', train_ticket:'🚆',
    bus_ticket:'🚌', hotel_booking:'🏨', vehicle_rc:'🚗',
    property_document:'🏠', unknown:'📄',
  }
  return map[type] || '📄'
}

function getCatColor(cat) {
  const map = {
    Government:'var(--doc-government)', Education:'var(--doc-education)',
    Medical:'var(--doc-medical)', Financial:'var(--doc-financial)',
    Travel:'var(--doc-travel)', Bills:'var(--doc-identity)',
    Shopping:'#FB923C', Vehicle:'var(--doc-other)',
    Property:'#86EFAC', Other:'var(--doc-other)',
  }
  return map[cat] || 'var(--text-secondary)'
}

function formatSize(bytes) {
  if (!bytes) return '—'
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1048576) return `${(bytes/1024).toFixed(1)} KB`
  return `${(bytes/1048576).toFixed(1)} MB`
}

function formatDate(iso) {
  if (!iso) return '—'
  return new Date(iso).toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' })
}
