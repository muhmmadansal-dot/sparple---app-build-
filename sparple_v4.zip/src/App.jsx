import React, { useEffect, useState } from 'react'
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import HomeScreen from './pages/HomeScreen.jsx'
import ScanScreen from './pages/ScanScreen.jsx'
import SearchScreen from './pages/SearchScreen.jsx'
import DocumentScreen from './pages/DocumentScreen.jsx'
import LibraryScreen from './pages/LibraryScreen.jsx'
import OnboardingScreen from './pages/OnboardingScreen.jsx'
import BottomNav from './components/BottomNav.jsx'
import { AppProvider } from './hooks/useAppContext.jsx'

function AnimatedRoutes() {
  const location = useLocation()

  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/onboarding" element={<OnboardingScreen />} />
        <Route path="/" element={<HomeScreen />} />
        <Route path="/scan" element={<ScanScreen />} />
        <Route path="/search" element={<SearchScreen />} />
        <Route path="/library" element={<LibraryScreen />} />
        <Route path="/document/:id" element={<DocumentScreen />} />
      </Routes>
    </AnimatePresence>
  )
}

export default function App() {
  const [ready, setReady] = useState(false)

  useEffect(() => {
    // Small delay to let splash screen handle
    const t = setTimeout(() => setReady(true), 100)
    return () => clearTimeout(t)
  }, [])

  if (!ready) {
    return (
      <div style={{
        width: '100%', height: '100%',
        background: '#0A0A0F',
        display: 'flex', alignItems: 'center', justifyContent: 'center'
      }}>
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, ease: [0.34, 1.56, 0.64, 1] }}
        >
          <SparpleLogo size={64} />
        </motion.div>
      </div>
    )
  }

  return (
    <AppProvider>
      <BrowserRouter>
        <AppShell />
      </BrowserRouter>
    </AppProvider>
  )
}

function AppShell() {
  const location = useLocation()
  const hideNav = ['/onboarding', '/scan'].includes(location.pathname)

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg-base)' }}>
      {/* Ambient background glow */}
      <div style={{
        position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
        background: `
          radial-gradient(ellipse 80% 40% at 50% -10%, rgba(124,111,255,0.12) 0%, transparent 70%),
          radial-gradient(ellipse 60% 30% at 80% 80%, rgba(168,85,247,0.06) 0%, transparent 60%)
        `,
        pointerEvents: 'none',
        zIndex: 0,
      }} />

      <div style={{ flex: 1, position: 'relative', zIndex: 1, overflow: 'hidden' }}>
        <AnimatedRoutes />
      </div>

      {!hideNav && <BottomNav />}
    </div>
  )
}

function SparpleLogo({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none">
      <rect width="40" height="40" rx="12" fill="url(#logo-grad)" />
      <path d="M12 20L18 14L24 20L18 26L12 20Z" fill="white" fillOpacity="0.9" />
      <path d="M20 12L28 20L20 28" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" fill="none" opacity="0.6" />
      <defs>
        <linearGradient id="logo-grad" x1="0" y1="0" x2="40" y2="40">
          <stop offset="0%" stopColor="#7C6FFF" />
          <stop offset="100%" stopColor="#A855F7" />
        </linearGradient>
      </defs>
    </svg>
  )
}
