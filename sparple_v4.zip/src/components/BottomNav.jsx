import React from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { motion } from 'framer-motion'
import styles from './BottomNav.module.css'

const NAV_ITEMS = [
  {
    path: '/',
    label: 'Home',
    icon: (active) => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <path d="M3 9.5L12 3L21 9.5V20C21 20.6 20.6 21 20 21H15V15H9V21H4C3.4 21 3 20.6 3 20V9.5Z"
          fill={active ? 'url(#nav-grad)' : 'none'}
          stroke={active ? 'url(#nav-grad)' : 'currentColor'}
          strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
        <defs>
          <linearGradient id="nav-grad" x1="0" y1="0" x2="24" y2="24">
            <stop offset="0%" stopColor="#7C6FFF" />
            <stop offset="100%" stopColor="#A855F7" />
          </linearGradient>
        </defs>
      </svg>
    ),
  },
  {
    path: '/search',
    label: 'Search',
    icon: (active) => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <circle cx="10.5" cy="10.5" r="6.5"
          stroke={active ? '#7C6FFF' : 'currentColor'} strokeWidth="1.8" />
        <path d="M15.5 15.5L20 20" stroke={active ? '#A855F7' : 'currentColor'}
          strokeWidth="1.8" strokeLinecap="round" />
      </svg>
    ),
  },
  {
    path: '/scan',
    label: 'Scan',
    icon: () => (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
        <path d="M3 7V5C3 3.9 3.9 3 5 3H7" stroke="white" strokeWidth="2" strokeLinecap="round" />
        <path d="M17 3H19C20.1 3 21 3.9 21 5V7" stroke="white" strokeWidth="2" strokeLinecap="round" />
        <path d="M21 17V19C21 20.1 20.1 21 19 21H17" stroke="white" strokeWidth="2" strokeLinecap="round" />
        <path d="M7 21H5C3.9 21 3 20.1 3 19V17" stroke="white" strokeWidth="2" strokeLinecap="round" />
        <path d="M3 12H21" stroke="white" strokeWidth="2" strokeLinecap="round" />
      </svg>
    ),
    special: true,
  },
  {
    path: '/library',
    label: 'Library',
    icon: (active) => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <rect x="3" y="3" width="7" height="7" rx="1.5"
          fill={active ? 'rgba(124,111,255,0.2)' : 'none'}
          stroke={active ? '#7C6FFF' : 'currentColor'} strokeWidth="1.8" />
        <rect x="14" y="3" width="7" height="7" rx="1.5"
          fill={active ? 'rgba(168,85,247,0.2)' : 'none'}
          stroke={active ? '#A855F7' : 'currentColor'} strokeWidth="1.8" />
        <rect x="3" y="14" width="7" height="7" rx="1.5"
          stroke={active ? '#7C6FFF' : 'currentColor'} strokeWidth="1.8" />
        <rect x="14" y="14" width="7" height="7" rx="1.5"
          stroke={active ? '#A855F7' : 'currentColor'} strokeWidth="1.8" />
      </svg>
    ),
  },
]

export default function BottomNav() {
  const navigate = useNavigate()
  const location = useLocation()

  return (
    <nav className={styles.nav}>
      <div className={styles.inner}>
        {NAV_ITEMS.map((item) => {
          const active = location.pathname === item.path

          if (item.special) {
            return (
              <button
                key={item.path}
                className={styles.scanBtn}
                onClick={() => navigate(item.path)}
              >
                <motion.div
                  className={styles.scanBtnInner}
                  whileTap={{ scale: 0.9 }}
                  transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                >
                  {item.icon(active)}
                </motion.div>
              </button>
            )
          }

          return (
            <motion.button
              key={item.path}
              className={`${styles.item} ${active ? styles.active : ''}`}
              onClick={() => navigate(item.path)}
              whileTap={{ scale: 0.85 }}
              transition={{ type: 'spring', stiffness: 500, damping: 30 }}
            >
              <div className={styles.icon}>
                {item.icon(active)}
              </div>
              <span className={styles.label}>{item.label}</span>
              {active && (
                <motion.div
                  className={styles.dot}
                  layoutId="nav-dot"
                  transition={{ type: 'spring', stiffness: 500, damping: 40 }}
                />
              )}
            </motion.button>
          )
        })}
      </div>
    </nav>
  )
}
