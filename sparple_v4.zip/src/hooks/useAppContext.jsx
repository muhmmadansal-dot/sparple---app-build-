import React, { createContext, useContext, useState, useCallback, useEffect } from 'react'
import { initDB, getStats, getCategoryCounts, getDocuments } from '../services/database.js'

const AppContext = createContext(null)

export function AppProvider({ children }) {
  const [dbReady, setDbReady] = useState(false)
  const [stats, setStats] = useState({ total: 0, needs_review: 0, starred: 0, categories: 0 })
  const [categoryCounts, setCategoryCounts] = useState([])
  const [hasScanned, setHasScanned] = useState(false)
  const [scanProgress, setScanProgress] = useState(null)

  useEffect(() => {
    initDB().then(() => {
      setDbReady(true)
      refreshStats()
      const scanned = localStorage.getItem('sparple_scanned')
      setHasScanned(!!scanned)
    }).catch(console.error)
  }, [])

  const refreshStats = useCallback(() => {
    try {
      const s = getStats()
      setStats(s)
      const cats = getCategoryCounts()
      setCategoryCounts(cats)
    } catch (err) {
      console.error('[App] Stats error:', err)
    }
  }, [])

  const markScanned = useCallback(() => {
    localStorage.setItem('sparple_scanned', '1')
    setHasScanned(true)
  }, [])

  return (
    <AppContext.Provider value={{
      dbReady,
      stats,
      categoryCounts,
      hasScanned,
      scanProgress,
      setScanProgress,
      refreshStats,
      markScanned,
    }}>
      {children}
    </AppContext.Provider>
  )
}

export function useAppContext() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useAppContext must be used inside AppProvider')
  return ctx
}
