/**
 * SPARPLE Scanner Service
 * Scans device storage, extracts text, classifies documents
 */

import { Filesystem, Directory } from '@capacitor/filesystem'
import { classifyDocument, suggestFilename, getSystemLabels } from './classifier.js'
import {
  initDB, persistDB, insertDocument, insertDocumentLabels,
  documentExists, insertScanHistory, setDocumentEmbedding, setDocumentImageEmbedding
} from './database.js'
import { preloadModels, embedText, embedImage, vectorToBytes } from './embeddings.js'

// Sparple only indexes documents and screenshots — not your whole camera
// roll. These are the folders where those actually live on Android.
const SCAN_DIRECTORIES = [
  { path: 'Download', directory: Directory.ExternalStorage },
  { path: 'Documents', directory: Directory.ExternalStorage },
  { path: 'DCIM/Screenshots', directory: Directory.ExternalStorage },
  { path: 'Pictures/Screenshots', directory: Directory.ExternalStorage },
  { path: 'WhatsApp/Media/WhatsApp Documents', directory: Directory.ExternalStorage },
]

const SUPPORTED_EXTENSIONS = new Set([
  'pdf', 'jpg', 'jpeg', 'png', 'webp',
  'doc', 'docx', 'txt',
])

export class Scanner {
  constructor(onProgress) {
    this.onProgress = onProgress || (() => {})
    this.aborted = false
    this.worker = null
  }

  abort() {
    this.aborted = true
  }

  async scan() {
    const startTime = Date.now()
    await initDB()

    let totalFiles = 0
    let processed = 0
    let newFiles = 0
    const errors = []

    // Load both on-device semantic search models first. First run only —
    // they download once (~110MB total: MiniLM ~23MB + CLIP ~87MB) and are
    // cached by the browser afterwards. Every search after this is offline.
    this.onProgress({ phase: 'model', progress: 0, message: 'Preparing on-device AI search…' })
    const modelResults = await preloadModels((p) => {
      const label = p.which === 'clip' ? 'image search' : 'text search'
      this.onProgress({
        phase: 'model',
        progress: p.pct || 0,
        message: p.pct < 100 ? `Downloading ${label} model… ${p.pct}%` : 'Almost ready…',
      })
    })
    // Text and image semantic search are independent — one failing to load
    // (e.g. flaky connection) shouldn't stop the other from working, and
    // shouldn't stop the scan either. Keyword search always works regardless.
    this.textSemanticReady = modelResults.text
    this.imageSemanticReady = modelResults.clip

    this.onProgress({ phase: 'discovering', progress: 0, message: 'Finding your files...' })

    // Discover all files
    const allFiles = await this.discoverFiles()
    totalFiles = allFiles.length

    // Nothing found — emit complete immediately (not an error)
    if (totalFiles === 0) {
      const durationMs = Date.now() - startTime
      insertScanHistory({ totalFiles: 0, newFiles: 0, durationMs })
      await persistDB()
      this.onProgress({
        phase: 'complete', progress: 100,
        message: 'No files found in scanned folders',
        total: 0, processed: 0, newFiles: 0, durationMs,
      })
      return { totalFiles: 0, newFiles: 0, durationMs, errors: [] }
    }

    this.onProgress({
      phase: 'scanning',
      progress: 0,
      message: `Found ${totalFiles} files`,
      total: totalFiles,
    })

    // Process in batches
    const BATCH_SIZE = 5
    for (let i = 0; i < allFiles.length; i += BATCH_SIZE) {
      if (this.aborted) break

      const batch = allFiles.slice(i, i + BATCH_SIZE)
      await Promise.allSettled(
        batch.map(async (file) => {
          try {
            const isNew = await this.processFile(file)
            if (isNew) newFiles++
          } catch (err) {
            errors.push({ file: file.path, error: err.message })
          }
          processed++
          this.onProgress({
            phase: 'scanning',
            progress: Math.round((processed / totalFiles) * 100),
            message: `Processing ${processed} of ${totalFiles}`,
            current: file.name,
            total: totalFiles,
            processed,
            newFiles,
          })
        })
      )
    }

    await persistDB()

    const durationMs = Date.now() - startTime
    insertScanHistory({ totalFiles, newFiles, durationMs })
    await persistDB()

    this.onProgress({
      phase: 'complete',
      progress: 100,
      message: `Indexed ${newFiles} new documents`,
      total: totalFiles,
      processed: totalFiles,
      newFiles,
      durationMs,
    })

    return { totalFiles, newFiles, durationMs, errors }
  }

  async discoverFiles() {
    const files = []

    for (const dir of SCAN_DIRECTORIES) {
      try {
        await this.walkDirectory(dir.path, dir.directory, files)
      } catch {
        // Directory doesn't exist or no permission — skip
      }
    }

    return files
  }

  async walkDirectory(path, directory, files, depth = 0) {
    if (depth > 3) return // Don't go too deep

    try {
      const result = await Filesystem.readdir({ path, directory })

      for (const item of result.files) {
        if (this.aborted) return

        const fullPath = `${path}/${item.name}`

        if (item.type === 'directory') {
          await this.walkDirectory(fullPath, directory, files, depth + 1)
        } else {
          const ext = item.name.split('.').pop()?.toLowerCase()
          if (SUPPORTED_EXTENSIONS.has(ext)) {
            files.push({
              name: item.name,
              path: fullPath,
              directory,
              size: item.size || 0,
              mtime: item.mtime,
              ext,
            })
          }
        }
      }
    } catch {
      // Skip unreadable directories
    }
  }

  async processFile(file) {
    // Skip if already indexed
    if (documentExists(file.path)) return false

    let extractedText = ''
    let thumbnailB64 = ''
    const mimeType = getMimeType(file.ext)

    try {
      if (file.ext === 'pdf') {
        extractedText = await this.extractPdfText(file)
      } else if (['jpg', 'jpeg', 'png', 'webp'].includes(file.ext)) {
        const result = await this.extractImageText(file)
        extractedText = result.text
        thumbnailB64 = result.thumbnail
      } else if (file.ext === 'txt') {
        extractedText = await this.readTextFile(file)
      }
    } catch (err) {
      console.warn(`[Scanner] Text extraction failed for ${file.name}:`, err)
    }

    const classification = classifyDocument(extractedText)
    const needsReview = classification.confidence < 40

    const docData = {
      name: file.name,
      originalName: file.name,
      path: file.path,
      type: classification.type,
      category: classification.category,
      label: classification.label,
      confidence: classification.confidence,
      extractedText: extractedText.substring(0, 10000), // Cap at 10k chars
      suggestedName: suggestFilename(classification, extractedText, file.name),
      fileSize: file.size,
      mimeType,
      thumbnailB64,
      needsReview,
      createdAt: file.mtime ? new Date(file.mtime).toISOString() : new Date().toISOString(),
      modifiedAt: file.mtime ? new Date(file.mtime).toISOString() : new Date().toISOString(),
    }

    const docId = insertDocument(docData)
    if (docId) {
      const labels = getSystemLabels(classification.type)
      insertDocumentLabels(docId, labels)

      // Text embedding (MiniLM) — always attempt if there's meaningful text,
      // whether it came from a PDF/txt file or OCR on an image/screenshot.
      if (this.textSemanticReady && extractedText.trim().length > 0) {
        try {
          const embeddingText = [classification.label, classification.category, file.name, extractedText.slice(0, 1500)]
            .filter(Boolean)
            .join(' — ')
          const vector = await embedText(embeddingText)
          if (vector) setDocumentEmbedding(docId, vectorToBytes(vector))
        } catch (err) {
          console.warn(`[Scanner] Text embedding failed for ${file.name}:`, err)
        }
      }

      // Image embedding (CLIP) — for every actual photo, regardless of
      // whether OCR found any text on it. This is what makes a query like
      // "beach photo" match a beach photo that has no text in it at all.
      const isImage = ['jpg', 'jpeg', 'png', 'webp'].includes(file.ext)
      if (this.imageSemanticReady && isImage && thumbnailB64) {
        try {
          const imgVector = await embedImage(thumbnailB64)
          if (imgVector) setDocumentImageEmbedding(docId, vectorToBytes(imgVector))
        } catch (err) {
          console.warn(`[Scanner] Image embedding failed for ${file.name}:`, err)
        }
      }
    }

    return true
  }

  async extractPdfText(file) {
    const pdfjsLib = await import('pdfjs-dist')
    pdfjsLib.GlobalWorkerOptions.workerSrc = '/pdf.worker.min.js'

    try {
      const fileData = await Filesystem.readFile({
        path: file.path,
        directory: file.directory,
      })

      const arrayBuffer = base64ToArrayBuffer(fileData.data)
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise

      let text = ''
      const maxPages = Math.min(pdf.numPages, 5) // First 5 pages

      for (let i = 1; i <= maxPages; i++) {
        const page = await pdf.getPage(i)
        const content = await page.getTextContent()
        text += content.items.map(item => item.str).join(' ') + '\n'
      }

      return text
    } catch (err) {
      throw new Error(`PDF extraction failed: ${err.message}`)
    }
  }

  async extractImageText(file) {
    const Tesseract = await import('tesseract.js')

    try {
      const fileData = await Filesystem.readFile({
        path: file.path,
        directory: file.directory,
      })

      const dataUrl = `data:${getMimeType(file.ext)};base64,${fileData.data}`

      const result = await Tesseract.recognize(dataUrl, 'eng', {
        logger: () => {}, // Suppress verbose logs
      })

      return {
        text: result.data.text,
        thumbnail: dataUrl,
      }
    } catch (err) {
      throw new Error(`OCR failed: ${err.message}`)
    }
  }

  async readTextFile(file) {
    const result = await Filesystem.readFile({
      path: file.path,
      directory: file.directory,
      encoding: 'utf8',
    })
    return result.data
  }
}

// --- File renaming ---

export async function renameFile(oldPath, newName, directory) {
  const dir = oldPath.substring(0, oldPath.lastIndexOf('/'))
  const newPath = `${dir}/${newName}`

  await Filesystem.rename({
    from: oldPath,
    to: newPath,
    directory,
  })

  return newPath
}

// --- Helpers ---

function getMimeType(ext) {
  const map = {
    pdf: 'application/pdf',
    jpg: 'image/jpeg',
    jpeg: 'image/jpeg',
    png: 'image/png',
    webp: 'image/webp',
    doc: 'application/msword',
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    txt: 'text/plain',
  }
  return map[ext] || 'application/octet-stream'
}

function base64ToArrayBuffer(base64) {
  const binary = atob(base64)
  const buffer = new ArrayBuffer(binary.length)
  const view = new Uint8Array(buffer)
  for (let i = 0; i < binary.length; i++) {
    view[i] = binary.charCodeAt(i)
  }
  return buffer
}
