/**
 * SPARPLE Embeddings Service
 *
 * Two models, two jobs — this is what makes vague search actually work:
 *
 * 1. Xenova/all-MiniLM-L6-v2 (text, quantized ONNX, ~23 MB)
 *    Embeds OCR'd / extracted TEXT (documents, screenshots with text).
 *    Powers queries like "handwritten notes" against a doc whose OCR text
 *    reads like a handwritten note, even if the word "handwritten" never
 *    appears in it.
 *
 * 2. Xenova/clip-vit-base-patch32 (image + text, quantized ONNX, ~87 MB)
 *    Embeds the actual PIXELS of every photo, and embeds the search query
 *    itself into the SAME 512-dim vector space via CLIP's text tower.
 *    This is what makes "beach photo" find a beach photo that has zero
 *    text on it — CLIP is trained specifically so a text description and
 *    a matching image land close together in embedding space.
 *
 * Both are fetched once (~110MB total) on first scan and cached in the
 * browser's Cache Storage — every search after that is 100% offline.
 *
 * API note: we use the low-level CLIPTextModelWithProjection /
 * CLIPVisionModelWithProjection classes directly (not the high-level
 * `pipeline('zero-shot-image-classification', ...)` wrapper), because the
 * pipeline wrapper is built for image-vs-candidate-labels classification
 * and doesn't cleanly expose raw text/image embedding vectors. This is
 * the documented pattern for cross-modal embedding with this library.
 *
 * ──────────────────────────────────────────────────────────────────────────
 * Android WebView / Capacitor compatibility
 * ──────────────────────────────────────────────────────────────────────────
 * @xenova/transformers ships its own NESTED copy of onnxruntime-web
 * (node_modules/@xenova/transformers/node_modules/onnxruntime-web), which
 * can differ in version from whatever's hoisted to the top-level
 * node_modules/onnxruntime-web. scripts/copy-onnx-wasm.js copies from the
 * NESTED copy first (falling back to top-level), so the .wasm files that
 * land in public/ actually match what this code requests at runtime.
 * Get that mismatched and you get: "both async and sync fetching of the
 * wasm failed" — which is exactly the bug this used to have, because the
 * previous copy script silently exited 0 even when it found nothing useful.
 *
 * wasmPaths is set to an absolute-from-origin path ('/') which resolves to
 * capacitor://localhost/<file>.wasm inside the compiled APK's WebView,
 * where MainActivity.java injects the COOP/COEP headers needed for cross-
 * origin isolation. The APK is the real target environment for this code.
 * ──────────────────────────────────────────────────────────────────────────
 */

import {
  env,
  pipeline,
  AutoTokenizer,
  AutoProcessor,
  CLIPTextModelWithProjection,
  CLIPVisionModelWithProjection,
  RawImage,
} from '@xenova/transformers'

// ── ONNX / WASM configuration (must happen before first model load) ────────

env.backends.onnx.wasm.wasmPaths = '/'
env.backends.onnx.wasm.numThreads = 1
env.backends.onnx.wasm.proxy = false

env.useBrowserCache = true
env.allowLocalModels = false

// ── Model IDs ────────────────────────────────────────────────────────────

const TEXT_MODEL_ID = 'Xenova/all-MiniLM-L6-v2'
const CLIP_MODEL_ID  = 'Xenova/clip-vit-base-patch32'

// ── Status tracking ──────────────────────────────────────────────────────

let _status = {
  text: 'idle',   // 'idle' | 'downloading' | 'ready' | 'error'
  clip: 'idle',
}

export function getModelStatus() {
  // 'ready' if either model is usable — one failing shouldn't sink the other.
  if (_status.text === 'ready' || _status.clip === 'ready') return 'ready'
  if (_status.text === 'error' && _status.clip === 'error') return 'error'
  return (_status.text === 'downloading' || _status.clip === 'downloading') ? 'downloading' : 'idle'
}

export function getModelStatusDetail() {
  return { ..._status }
}

// ── Text model (MiniLM) ──────────────────────────────────────────────────

let _textPipePromise = null

function loadTextModel(onProgress) {
  if (_textPipePromise) return _textPipePromise
  _status.text = 'downloading'

  _textPipePromise = pipeline('feature-extraction', TEXT_MODEL_ID, {
    quantized: true,
    progress_callback: (info) => {
      if (!onProgress) return
      if (info.status === 'progress' || info.status === 'download') {
        const pct = info.total ? Math.round((info.loaded / info.total) * 100) : 0
        onProgress({ pct, label: pct < 99 ? `Downloading text model… ${pct}%` : 'Almost ready…' })
      }
    },
  })
    .then((model) => { _status.text = 'ready'; return model })
    .catch((err) => {
      _status.text = 'error'
      _textPipePromise = null
      console.error('[Embeddings] Text model load failed:', err)
      throw err
    })

  return _textPipePromise
}

/**
 * Embed a text string with MiniLM → normalized Float32Array[384], or null.
 */
export async function embedText(text) {
  const s = (text || '').trim().slice(0, 2000)
  if (!s) return null
  try {
    const pipe = await loadTextModel()
    const out = await pipe(s, { pooling: 'mean', normalize: true })
    return Float32Array.from(out.data)
  } catch (err) {
    console.warn('[Embeddings] embedText failed:', err)
    return null
  }
}

// ── CLIP model (image + text, shared space) ──────────────────────────────

let _clipPromise = null // resolves to { tokenizer, processor, textModel, visionModel }

function loadClip(onProgress) {
  if (_clipPromise) return _clipPromise
  _status.clip = 'downloading'

  const progress_callback = (info) => {
    if (!onProgress) return
    if (info.status === 'progress' || info.status === 'download') {
      const pct = info.total ? Math.round((info.loaded / info.total) * 100) : 0
      onProgress({ pct, label: pct < 99 ? `Downloading image model… ${pct}%` : 'Almost ready…' })
    }
  }

  _clipPromise = Promise.all([
    AutoTokenizer.from_pretrained(CLIP_MODEL_ID),
    AutoProcessor.from_pretrained(CLIP_MODEL_ID),
    CLIPTextModelWithProjection.from_pretrained(CLIP_MODEL_ID, { quantized: true, progress_callback }),
    CLIPVisionModelWithProjection.from_pretrained(CLIP_MODEL_ID, { quantized: true, progress_callback }),
  ])
    .then(([tokenizer, processor, textModel, visionModel]) => {
      _status.clip = 'ready'
      return { tokenizer, processor, textModel, visionModel }
    })
    .catch((err) => {
      _status.clip = 'error'
      _clipPromise = null
      console.error('[Embeddings] CLIP load failed:', err)
      throw err
    })

  return _clipPromise
}

/**
 * Embed an image (data URL) with CLIP's vision tower →
 * normalized Float32Array[512], or null on failure.
 */
export async function embedImage(imageDataUrl) {
  if (!imageDataUrl) return null
  try {
    const { processor, visionModel } = await loadClip()
    const image = await RawImage.fromURL(imageDataUrl)
    const imageInputs = await processor(image)
    const { image_embeds } = await visionModel(imageInputs)
    return l2Normalize(Float32Array.from(image_embeds.data))
  } catch (err) {
    console.warn('[Embeddings] embedImage failed:', err)
    return null
  }
}

/**
 * Embed a search query into CLIP's shared text/image space, so it can be
 * compared directly against embedImage() vectors. This is the mechanism
 * behind "beach photo" finding a beach photo with zero OCR text.
 */
export async function embedQueryForImages(text) {
  const s = (text || '').trim().slice(0, 200)
  if (!s) return null
  try {
    const { tokenizer, textModel } = await loadClip()
    const textInputs = tokenizer([s], { padding: true, truncation: true })
    const { text_embeds } = await textModel(textInputs)
    return l2Normalize(Float32Array.from(text_embeds.data))
  } catch (err) {
    console.warn('[Embeddings] embedQueryForImages failed:', err)
    return null
  }
}

/**
 * Pre-warm both models before scanning begins.
 * Each model loads independently — one failing doesn't block the other.
 */
export async function preloadModels(onProgress) {
  const results = { text: false, clip: false }

  await Promise.allSettled([
    loadTextModel((p) => onProgress?.({ ...p, which: 'text' })).then(() => { results.text = true }),
    loadClip((p) => onProgress?.({ ...p, which: 'clip' })).then(() => { results.clip = true }),
  ])

  return results
}

// ── Shared helpers ────────────────────────────────────────────────────────

function l2Normalize(vec) {
  let sum = 0
  for (let i = 0; i < vec.length; i++) sum += vec[i] * vec[i]
  const norm = Math.sqrt(sum) || 1
  for (let i = 0; i < vec.length; i++) vec[i] /= norm
  return vec
}

/**
 * Dot-product cosine similarity. Vectors are already L2-normalized.
 */
export function cosineSimilarity(a, b) {
  if (!a || !b || a.length !== b.length) return 0
  let d = 0
  for (let i = 0; i < a.length; i++) d += a[i] * b[i]
  return d
}

// ── Float32Array ↔ raw bytes for SQLite BLOB persistence ────────────────────

export function vectorToBytes(vec) {
  if (!vec) return null
  const buf = vec.buffer
  return new Uint8Array(buf.slice ? buf.slice(0) : buf)
}

export function bytesToVector(bytes) {
  if (!bytes || !bytes.length) return null
  const buf = bytes.buffer
    ? bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength)
    : bytes
  return new Float32Array(buf)
}
