/**
 * SPARPLE Search Service
 *
 * Three signals merged into one ranked list:
 *
 * 1. Lexical (SQLite FTS5)      — exact/prefix keyword matches. Always available.
 * 2. Text-semantic (MiniLM)     — query vs. OCR'd/extracted text meaning.
 *    Finds "handwritten notes" even if that phrase never appears verbatim.
 * 3. Image-semantic (CLIP)      — query vs. actual photo pixels.
 *    Finds "beach photo" even for a photo with zero text on it, because
 *    CLIP's text tower and vision tower share one embedding space.
 *
 * A document can score from more than one signal at once (e.g. a scanned
 * receipt might match both lexically AND semantically) — those scores add.
 */

import {
  searchDocuments as ftsSearch, getDocuments,
  getAllEmbeddings, getAllImageEmbeddings, getDocumentsByIds,
} from './database.js'
import {
  embedText, embedQueryForImages, cosineSimilarity, bytesToVector, getModelStatusDetail,
} from './embeddings.js'

const TEXT_SEMANTIC_MIN_SCORE  = 0.32 // below this, a MiniLM "match" is just noise
const IMAGE_SEMANTIC_MIN_SCORE = 0.22 // CLIP similarities run lower on average than MiniLM's

export async function search(query, { limit = 30 } = {}) {
  const q = (query || '').trim()
  if (!q) return { results: getDocuments({ limit }), semanticActive: false }

  const scored = new Map()
  const addScore = (id, doc, delta) => {
    const existing = scored.get(id)
    if (existing) existing.score += delta
    else scored.set(id, { doc, score: delta })
  }

  // 1. Lexical — fast, exact word/prefix matches
  const lexical = ftsSearch(q, limit)
  lexical.forEach((doc, i) => {
    addScore(doc.id, doc, 1.4 - i * (1 / Math.max(lexical.length, 1)))
  })

  const modelStatus = getModelStatusDetail()
  let semanticActive = false

  // 2. Text-semantic (MiniLM) — understands meaning of extracted/OCR'd text
  if (modelStatus.text !== 'error') {
    try {
      const qVec = await embedText(q)
      if (qVec) {
        const all = getAllEmbeddings()
        if (all.length) {
          const ranked = all
            .map(({ id, embedding }) => ({ id, sim: cosineSimilarity(qVec, bytesToVector(embedding)) }))
            .filter(r => r.sim >= TEXT_SEMANTIC_MIN_SCORE)
            .sort((a, b) => b.sim - a.sim)
            .slice(0, limit)

          if (ranked.length) {
            semanticActive = true
            const docsById = getDocumentsByIds(ranked.map(r => r.id))
            for (const r of ranked) {
              const doc = docsById[r.id]
              if (doc) addScore(r.id, doc, r.sim)
            }
          }
        }
      }
    } catch (err) {
      console.warn('[Search] Text-semantic search skipped:', err)
    }
  }

  // 3. Image-semantic (CLIP) — understands actual photo content, no OCR needed.
  // This is what makes "beach photo" find a beach photo with no text on it.
  if (modelStatus.clip !== 'error') {
    try {
      const qImgVec = await embedQueryForImages(q)
      if (qImgVec) {
        const allImg = getAllImageEmbeddings()
        if (allImg.length) {
          const ranked = allImg
            .map(({ id, embedding }) => ({ id, sim: cosineSimilarity(qImgVec, bytesToVector(embedding)) }))
            .filter(r => r.sim >= IMAGE_SEMANTIC_MIN_SCORE)
            .sort((a, b) => b.sim - a.sim)
            .slice(0, limit)

          if (ranked.length) {
            semanticActive = true
            const docsById = getDocumentsByIds(ranked.map(r => r.id))
            for (const r of ranked) {
              const doc = docsById[r.id]
              if (doc) addScore(r.id, doc, r.sim)
            }
          }
        }
      }
    } catch (err) {
      console.warn('[Search] Image-semantic search skipped:', err)
    }
  }

  const results = Array.from(scored.values())
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(({ doc, score }) => ({ ...doc, _matchScore: score }))

  return { results, semanticActive }
}
