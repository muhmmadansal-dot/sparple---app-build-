package com.sparple.vault;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.util.Base64;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.Files;

/**
 * Bridges the gap that @capacitor/filesystem cannot cross on Android 11+:
 *
 *  1. Filesystem.requestPermissions() only ever triggers the runtime
 *     media-permission dialog (READ_MEDIA_IMAGES/VIDEO). It has no concept
 *     of MANAGE_EXTERNAL_STORAGE, which is granted through a dedicated
 *     system Settings screen (ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION),
 *     not a runtime dialog. Only native code can launch that screen.
 *
 *  2. Even with MANAGE_EXTERNAL_STORAGE granted, Directory.ExternalStorage
 *     in @capacitor/filesystem resolves to the app's private sandbox
 *     (/Android/data/<pkg>/files), NOT the public shared storage root
 *     (/storage/emulated/0/...). So Filesystem.readdir/readFile can never
 *     see the user's real Download/Documents/DCIM folders, regardless of
 *     permission state. This plugin reads real absolute paths directly
 *     via java.io.File once MANAGE_EXTERNAL_STORAGE is granted.
 */
@CapacitorPlugin(name = "StoragePlugin")
public class StoragePlugin extends Plugin {

    @PluginMethod
    public void hasManageStorage(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("granted", checkManageStorage());
        call.resolve(ret);
    }

    private boolean checkManageStorage() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return Environment.isExternalStorageManager();
        }
        // Below Android 11, MANAGE_EXTERNAL_STORAGE doesn't exist as a concept —
        // normal runtime storage permissions (already handled by Capacitor's
        // Filesystem plugin) are sufficient.
        return true;
    }

    @PluginMethod
    public void openManageStorageSettings(PluginCall call) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            // Nothing to do on old Android — resolve immediately as granted.
            JSObject ret = new JSObject();
            ret.put("granted", true);
            call.resolve(ret);
            return;
        }

        saveCall(call);
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
            intent.setData(Uri.parse("package:" + getContext().getPackageName()));
            startActivityForResult(call, intent, "handleManageStorageResult");
        } catch (Exception e) {
            // Some OEMs don't ship the per-app screen — fall back to the general one.
            try {
                Intent fallback = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                startActivityForResult(call, fallback, "handleManageStorageResult");
            } catch (Exception e2) {
                call.reject("Could not open storage settings: " + e2.getMessage());
            }
        }
    }

    @ActivityCallback
    private void handleManageStorageResult(PluginCall call, androidx.activity.result.ActivityResult result) {
        if (call == null) return;
        JSObject ret = new JSObject();
        // The settings screen doesn't return a meaningful result code either way —
        // we just re-check the real permission state once the user comes back.
        ret.put("granted", checkManageStorage());
        call.resolve(ret);
    }

    /**
     * List files/directories at a real absolute path (e.g. "/storage/emulated/0/Download").
     */
    @PluginMethod
    public void readdirAbsolute(PluginCall call) {
        String path = call.getString("path");
        if (path == null) {
            call.reject("path is required");
            return;
        }
        if (!checkManageStorage()) {
            call.reject("MANAGE_EXTERNAL_STORAGE not granted");
            return;
        }

        File dir = new File(path);
        if (!dir.exists() || !dir.isDirectory()) {
            JSObject ret = new JSObject();
            ret.put("files", new JSArray());
            call.resolve(ret);
            return;
        }

        File[] children = dir.listFiles();
        JSArray files = new JSArray();
        if (children != null) {
            for (File f : children) {
                JSObject entry = new JSObject();
                entry.put("name", f.getName());
                entry.put("type", f.isDirectory() ? "directory" : "file");
                entry.put("size", f.length());
                entry.put("mtime", f.lastModified());
                files.put(entry);
            }
        }
        JSObject ret = new JSObject();
        ret.put("files", files);
        call.resolve(ret);
    }

    /**
     * Read a file at a real absolute path and return its contents base64-encoded.
     */
    @PluginMethod
    public void readFileAbsolute(PluginCall call) {
        String path = call.getString("path");
        if (path == null) {
            call.reject("path is required");
            return;
        }
        if (!checkManageStorage()) {
            call.reject("MANAGE_EXTERNAL_STORAGE not granted");
            return;
        }

        File file = new File(path);
        if (!file.exists() || !file.isFile()) {
            call.reject("File not found: " + path);
            return;
        }

        try (FileInputStream fis = new FileInputStream(file)) {
            byte[] bytes = Files.readAllBytes(file.toPath());
            String b64 = Base64.encodeToString(bytes, Base64.NO_WRAP);
            JSObject ret = new JSObject();
            ret.put("data", b64);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Failed to read file: " + e.getMessage());
        }
    }

    /**
     * Rename/move a file at a real absolute path to a new absolute path.
     */
    @PluginMethod
    public void renameAbsolute(PluginCall call) {
        String from = call.getString("from");
        String to = call.getString("to");
        if (from == null || to == null) {
            call.reject("from and to are required");
            return;
        }
        if (!checkManageStorage()) {
            call.reject("MANAGE_EXTERNAL_STORAGE not granted");
            return;
        }

        File src = new File(from);
        File dst = new File(to);
        if (!src.exists()) {
            call.reject("Source file not found: " + from);
            return;
        }
        if (src.renameTo(dst)) {
            call.resolve();
        } else {
            call.reject("Rename failed for " + from);
        }
    }

    /**
     * Returns the real absolute root of shared/public external storage,
     * e.g. "/storage/emulated/0". JS uses this to build absolute scan paths.
     */
    @PluginMethod
    public void getPublicStorageRoot(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("path", Environment.getExternalStorageDirectory().getAbsolutePath());
        call.resolve(ret);
    }
}
