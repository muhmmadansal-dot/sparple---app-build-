# Sparple v7 — Bugfix Notes

All 7 bugs traced back to **two root causes**, plus one independent UI bug.

## Root cause 1: MANAGE_EXTERNAL_STORAGE was never actually requested
`Filesystem.requestPermissions()` (Capacitor) can only trigger the basic
media-permission dialog (READ_MEDIA_IMAGES/VIDEO). It has no concept of
`MANAGE_EXTERNAL_STORAGE` ("All files access"), which requires a dedicated
system Settings screen that only native code can launch.

**Fix:** New native plugin `StoragePlugin.java` (registered in
`MainActivity.java`) exposing:
- `hasManageStorage()` — checks `Environment.isExternalStorageManager()`
- `openManageStorageSettings()` — launches `ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION`
- `readdirAbsolute()` / `readFileAbsolute()` / `renameAbsolute()` — see root cause 2
- `getPublicStorageRoot()` — returns `/storage/emulated/0`

`ScanScreen.jsx` now checks `hasManageStorage()` before starting a scan, and
routes to a new `needsFullAccess` screen state that sends the user to the
real settings screen if it's not granted.

## Root cause 2: Directory.ExternalStorage ≠ public storage
Even with `MANAGE_EXTERNAL_STORAGE` granted, Capacitor's
`Directory.ExternalStorage` constant resolves to the app's **private
sandbox** (`/Android/data/<pkg>/files`), not the real shared storage root.
So `Filesystem.readdir()` under that directory could never see the user's
actual Download/Documents/DCIM folders — explaining why only ~14 photos
(reachable via the media-permission fallback) were found and zero documents.

**Fix:** `scanner.js` now walks real absolute paths
(`/storage/emulated/0/Download`, etc.) via `StoragePlugin.readdirAbsolute`/
`readFileAbsolute` when running on a native device. A Capacitor-Filesystem
fallback path is kept for web/emulator dev only.

## Downstream effects of the above two (no separate fix needed)
- **0 documents found, only some images** — direct result of root cause 2.
- **Everything landed in "needs review"** — `classifyDocument()` forces
  confidence to 0 (and thus `needsReview = true`) whenever extracted text is
  under 10 characters. With file reads silently failing, every OCR/PDF
  extraction returned empty text. Fixed automatically once real reads work.
- **Semantic search showing nothing / flickering** — the embeddings table was
  essentially empty because so few documents were ever successfully indexed
  with real text. `SearchScreen.jsx`'s debounce/race-guard logic was already
  correct; nothing to fix there.

## Independent bug: vault thumbnails never rendered
`DocumentCard.jsx` and `DocumentScreen.jsx` were storing `thumbnail_b64` in
the database but never rendering it — cards always showed a generic emoji
icon regardless of whether a thumbnail existed. This is why cards showed
"a text snippet" instead of an image.

**Fix:** Both components now render `doc.thumbnail_b64` as an `<img>` when
present, falling back to the type icon otherwise.

## Independent bug: progress bar sawtooth (80%→20%→38%→100%)
`preloadModels()` downloads the text (MiniLM) and image (CLIP) models in
parallel, and each reports its own independent 0–100% stream through the
same `onProgress` callback. The UI was displaying whichever raw percentage
arrived most recently, causing the jump.

**Fix:** `scanner.js` now combines both streams into a single weighted,
monotonic percentage (weighted ~23MB text / ~87MB clip) before reporting
progress, so the bar only moves forward.

## Files changed
- `android/app/src/main/java/com/sparple/vault/StoragePlugin.java` (new)
- `android/app/src/main/java/com/sparple/vault/MainActivity.java`
- `src/services/scanner.js`
- `src/pages/ScanScreen.jsx`
- `src/components/DocumentCard.jsx` + `.module.css`
- `src/pages/DocumentScreen.jsx`

## Before you build
- Run a full clean rebuild (`npx cap sync android` then rebuild in Android
  Studio) since a new native plugin class was added.
- Uninstall the app from your test device first — Android caches the
  MANAGE_EXTERNAL_STORAGE grant state per-install and old test data with
  broken/empty extracted text will otherwise stick around in the local
  SQLite DB.
- When you tap "Start Scanning" you should now see a new **"Full Storage
  Access Needed"** screen before the download begins (first run only) — tap
  through to the real Android settings screen and enable the toggle, then
  return to the app.
