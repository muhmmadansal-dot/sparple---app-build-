/**
 * SPARPLE Scanner Service
 * Scans device storage, extracts text, classifies documents
 */

import { Filesystem, Directory } from '@capacitor/filesystem'
import { Capacitor, registerPlugin } from '@capacitor/core'
import { classifyDocument, suggestFilename, getSystemLabels } from './classifier.js'
import {
  initDB, persistDB, insertDocument, insertDocumentLabels,
  documentExists, insertScanHistory, setDocumentEmbedding, setDocumentImageEmbedding
} from './database.js'
import { preloadModels, embedText, embedImage, vectorToBytes } from './embeddings.js'

// Native bridge: real public-storage access. @capacitor/filesystem's
// Directory.ExternalStorage only ever resolves to the app's private sandbox
// (/Android/data/<pkg>/files), even with MANAGE_EXTERNAL_STORAGE granted —
// it has no directory constant for the real shared storage root. This plugin
// (registered in MainActivity.java) reads real absolute paths instead.
const StoragePlugin = registerPlugin('StoragePlugin')

// Folders Sparple scans on Android. Originally scoped to just
// Downloads/Documents/Screenshots, but the user wants full photo library
// coverage too, so DCIM/Camera and Pictures (the two real camera-roll
// locations on stock Android) are now included alongside document folders.
const SCAN_SUBPATHS = [
  'Download',
  'Documents',
  'DCIM/Camera',
  'DCIM/Screenshots',
  'Pictures',
  'WhatsApp/Media/WhatsApp Documents',
  'WhatsApp/Media/WhatsApp Images',
]

const SUPPORTED_EXTENSIONS = new Set([
  'pdf', 'jpg', 'jpeg', 'png', 'webp',
  'doc', 'docx', 'txt',
])

export class Scanner {
  constructor(onProgress) {
    this.onProgress = onProgress || (() => {})
    this.aborted = false
    this.worker = null
  }

  abort() {
    this.aborted = true
  }

  async scan() {
    const startTime = Date.now()
    await initDB()

    let totalFiles = 0
    let processed = 0
    let newFiles = 0
    const errors = []

    // Load both on-device semantic search models first. First run only —
    // they download once (~110MB total: MiniLM ~23MB + CLIP ~87MB) and are
    // cached by the browser afterwards. Every search after this is offline.
    //
    // Both models download in parallel, each reporting its own independent
    // 0-100% stream through the same callback. Reporting those raw values
    // directly produces a sawtooth ("80% -> 20% -> 38%") because two
    // unrelated percentages are being shown on one bar. Instead we track
    // both streams separately and report a single weighted, monotonic
    // combined percentage — MiniLM is ~23MB and CLIP is ~87MB, so CLIP is
    // weighted roughly 4x more heavily in the combined figure.
    this.onProgress({ phase: 'model', progress: 0, message: 'Preparing on-device AI search…' })
    const modelWeight = { text: 23, clip: 87 }
    const modelPct = { text: 0, clip: 0 }
    let combinedMax = 0
    const reportCombined = (which, pct, label) => {
      modelPct[which] = pct
      const totalWeight = modelWeight.text + modelWeight.clip
      const combined = Math.round(
        (modelPct.text * modelWeight.text + modelPct.clip * modelWeight.clip) / totalWeight
      )
      // Never let the bar visually go backwards.
      combinedMax = Math.max(combinedMax, combined)
      this.onProgress({
        phase: 'model',
        progress: combinedMax,
        message: combinedMax < 99 ? `${label}… ${combinedMax}%` : 'Almost ready…',
      })
    }

    const modelResults = await preloadModels((p) => {
      const label = p.which === 'clip' ? 'Downloading image search model' : 'Downloading text search model'
      reportCombined(p.which, p.pct || 0, label)
    })
    // Text and image semantic search are independent — one failing to load
    // (e.g. flaky connection) shouldn't stop the other from working, and
    // shouldn't stop the scan either. Keyword search always works regardless.
    this.textSemanticReady = modelResults.text
    this.imageSemanticReady = modelResults.clip

    this.onProgress({ phase: 'discovering', progress: 0, message: 'Finding your files...' })

    // Discover all files
    const allFiles = await this.discoverFiles()
    totalFiles = allFiles.length

    // Nothing found — emit complete immediately (not an error)
    if (totalFiles === 0) {
      const durationMs = Date.now() - startTime
      insertScanHistory({ totalFiles: 0, newFiles: 0, durationMs })
      await persistDB()
      this.onProgress({
        phase: 'complete', progress: 100,
        message: 'No files found in scanned folders',
        total: 0, processed: 0, newFiles: 0, durationMs,
      })
      return { totalFiles: 0, newFiles: 0, durationMs, errors: [] }
    }

    this.onProgress({
      phase: 'scanning',
      progress: 0,
      message: `Found ${totalFiles} files`,
      total: totalFiles,
    })

    // Process in batches
    const BATCH_SIZE = 5
    const fileDiagnostics = []
    for (let i = 0; i < allFiles.length; i += BATCH_SIZE) {
      if (this.aborted) break

      const batch = allFiles.slice(i, i + BATCH_SIZE)
      await Promise.allSettled(
        batch.map(async (file) => {
          try {
            const outcome = await this.processFile(file)
            if (outcome.isNew) newFiles++
            fileDiagnostics.push({
              name: file.name,
              ext: file.ext,
              isNew: outcome.isNew,
              extractedChars: outcome.extractedChars ?? null,
              extractionError: outcome.extractionError ?? null,
              classification: outcome.classification ?? null,
              confidence: outcome.confidence ?? null,
            })
          } catch (err) {
            errors.push({ file: file.path, error: err.message })
            fileDiagnostics.push({
              name: file.name,
              ext: file.ext,
              isNew: false,
              extractionError: `processFile threw: ${err.message}`,
            })
          }
          processed++
          this.onProgress({
            phase: 'scanning',
            progress: Math.round((processed / totalFiles) * 100),
            message: `Processing ${processed} of ${totalFiles}`,
            current: file.name,
            total: totalFiles,
            processed,
            newFiles,
          })
        })
      )
    }

    await persistDB()

    const durationMs = Date.now() - startTime
    insertScanHistory({ totalFiles, newFiles, durationMs })
    await persistDB()

    this.onProgress({
      phase: 'complete',
      progress: 100,
      message: `Indexed ${newFiles} new documents`,
      total: totalFiles,
      processed: totalFiles,
      newFiles,
      durationMs,
      errors,
      fileDiagnostics,
      modelStatus: { text: this.textSemanticReady, clip: this.imageSemanticReady },
    })

    return { totalFiles, newFiles, durationMs, errors, fileDiagnostics }
  }

  async discoverFiles() {
    const files = []
    const useNative = Capacitor.isNativePlatform()

    let publicRoot = null
    if (useNative) {
      try {
        const res = await StoragePlugin.getPublicStorageRoot()
        publicRoot = res.path // e.g. /storage/emulated/0
      } catch (err) {
        console.warn('[Scanner] Could not get public storage root, falling back:', err)
      }
    }

    for (const subpath of SCAN_SUBPATHS) {
      try {
        if (publicRoot) {
          await this.walkDirectoryNative(`${publicRoot}/${subpath}`, files)
        } else {
          // Web/emulator dev fallback — uses Capacitor's sandboxed Filesystem API.
          await this.walkDirectoryCapacitor(subpath, Directory.ExternalStorage, files)
        }
      } catch {
        // Directory doesn't exist or no permission — skip
      }
    }

    return files
  }

  // Real device path: reads actual shared storage via the native StoragePlugin.
  async walkDirectoryNative(absPath, files, depth = 0) {
    if (depth > 3) return // Don't go too deep

    try {
      const result = await StoragePlugin.readdirAbsolute({ path: absPath })

      for (const item of result.files) {
        if (this.aborted) return

        const fullPath = `${absPath}/${item.name}`

        if (item.type === 'directory') {
          await this.walkDirectoryNative(fullPath, files, depth + 1)
        } else {
          const ext = item.name.split('.').pop()?.toLowerCase()
          if (SUPPORTED_EXTENSIONS.has(ext)) {
            files.push({
              name: item.name,
              path: fullPath,
              native: true, // read via StoragePlugin.readFileAbsolute, not Filesystem
              size: item.size || 0,
              mtime: item.mtime,
              ext,
            })
          }
        }
      }
    } catch {
      // Skip unreadable directories
    }
  }

  // Web/emulator dev fallback path — old Capacitor Filesystem sandbox behavior.
  async walkDirectoryCapacitor(path, directory, files, depth = 0) {
    if (depth > 3) return

    try {
      const result = await Filesystem.readdir({ path, directory })

      for (const item of result.files) {
        if (this.aborted) return

        const fullPath = `${path}/${item.name}`

        if (item.type === 'directory') {
          await this.walkDirectoryCapacitor(fullPath, directory, files, depth + 1)
        } else {
          const ext = item.name.split('.').pop()?.toLowerCase()
          if (SUPPORTED_EXTENSIONS.has(ext)) {
            files.push({
              name: item.name,
              path: fullPath,
              directory,
              native: false,
              size: item.size || 0,
              mtime: item.mtime,
              ext,
            })
          }
        }
      }
    } catch {
      // Skip unreadable directories
    }
  }

  async processFile(file) {
    // Skip if already indexed
    if (documentExists(file.path)) return { isNew: false }

    let extractedText = ''
    let thumbnailB64 = ''
    let extractionError = null
    const mimeType = getMimeType(file.ext)

    try {
      if (file.ext === 'pdf') {
        extractedText = await this.extractPdfText(file)
      } else if (['jpg', 'jpeg', 'png', 'webp'].includes(file.ext)) {
        const result = await this.extractImageText(file)
        extractedText = result.text
        thumbnailB64 = result.thumbnail
      } else if (file.ext === 'txt') {
        extractedText = await this.readTextFile(file)
      }
    } catch (err) {
      extractionError = err.message || String(err)
      console.warn(`[Scanner] Text extraction failed for ${file.name}:`, err)
    }

    const classification = classifyDocument(extractedText)
    const needsReview = classification.confidence < 40

    const docData = {
      name: file.name,
      originalName: file.name,
      path: file.path,
      type: classification.type,
      category: classification.category,
      label: classification.label,
      confidence: classification.confidence,
      extractedText: extractedText.substring(0, 10000), // Cap at 10k chars
      suggestedName: suggestFilename(classification, extractedText, file.name),
      fileSize: file.size,
      mimeType,
      thumbnailB64,
      needsReview,
      createdAt: file.mtime ? new Date(file.mtime).toISOString() : new Date().toISOString(),
      modifiedAt: file.mtime ? new Date(file.mtime).toISOString() : new Date().toISOString(),
    }

    const docId = insertDocument(docData)
    if (docId) {
      const labels = getSystemLabels(classification.type)
      insertDocumentLabels(docId, labels)

      // Text embedding (MiniLM) — always attempt if there's meaningful text,
      // whether it came from a PDF/txt file or OCR on an image/screenshot.
      if (this.textSemanticReady && extractedText.trim().length > 0) {
        try {
          const embeddingText = [classification.label, classification.category, file.name, extractedText.slice(0, 1500)]
            .filter(Boolean)
            .join(' — ')
          const vector = await embedText(embeddingText)
          if (vector) setDocumentEmbedding(docId, vectorToBytes(vector))
        } catch (err) {
          console.warn(`[Scanner] Text embedding failed for ${file.name}:`, err)
        }
      }

      // Image embedding (CLIP) — for every actual photo, regardless of
      // whether OCR found any text on it. This is what makes a query like
      // "beach photo" match a beach photo that has no text in it at all.
      const isImage = ['jpg', 'jpeg', 'png', 'webp'].includes(file.ext)
      if (this.imageSemanticReady && isImage && thumbnailB64) {
        try {
          const imgVector = await embedImage(thumbnailB64)
          if (imgVector) setDocumentImageEmbedding(docId, vectorToBytes(imgVector))
        } catch (err) {
          console.warn(`[Scanner] Image embedding failed for ${file.name}:`, err)
        }
      }
    }

    return {
      isNew: true,
      extractedChars: extractedText.trim().length,
      extractionError,
      classification: classification.type,
      confidence: classification.confidence,
    }
  }

  async readFileB64(file) {
    if (file.native) {
      const res = await StoragePlugin.readFileAbsolute({ path: file.path })
      return res.data
    }
    const res = await Filesystem.readFile({ path: file.path, directory: file.directory })
    return res.data
  }

  async extractPdfText(file) {
    const pdfjsLib = await import('pdfjs-dist')
    pdfjsLib.GlobalWorkerOptions.workerSrc = '/pdf.worker.min.js'

    try {
      const dataB64 = await this.readFileB64(file)
      const arrayBuffer = base64ToArrayBuffer(dataB64)
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise

      let text = ''
      const maxPages = Math.min(pdf.numPages, 5) // First 5 pages

      for (let i = 1; i <= maxPages; i++) {
        const page = await pdf.getPage(i)
        const content = await page.getTextContent()
        text += content.items.map(item => item.str).join(' ') + '\n'
      }

      return text
    } catch (err) {
      throw new Error(`PDF extraction failed: ${err.message}`)
    }
  }

  async extractImageText(file) {
    const Tesseract = await import('tesseract.js')

    try {
      const dataB64 = await this.readFileB64(file)
      const dataUrl = `data:${getMimeType(file.ext)};base64,${dataB64}`

      const result = await Tesseract.recognize(dataUrl, 'eng', {
        logger: () => {}, // Suppress verbose logs
      })

      return {
        text: result.data.text,
        thumbnail: dataUrl,
      }
    } catch (err) {
      throw new Error(`OCR failed: ${err.message}`)
    }
  }

  async readTextFile(file) {
    if (file.native) {
      // Native reads always return base64 (binary-safe); decode to utf8 text.
      const b64 = await StoragePlugin.readFileAbsolute({ path: file.path }).then(r => r.data)
      const bytes = base64ToArrayBuffer(b64)
      return new TextDecoder('utf-8').decode(bytes)
    }
    const result = await Filesystem.readFile({
      path: file.path,
      directory: file.directory,
      encoding: 'utf8',
    })
    return result.data
  }
}

// --- File renaming ---

export async function renameFile(oldPath, newName, directory) {
  const dir = oldPath.substring(0, oldPath.lastIndexOf('/'))
  const newPath = `${dir}/${newName}`

  // Absolute paths (starting with '/') came from native discovery — the
  // Capacitor Filesystem plugin can't operate on them since they live
  // outside its sandboxed Directory roots.
  if (oldPath.startsWith('/')) {
    await StoragePlugin.renameAbsolute({ from: oldPath, to: newPath })
    return newPath
  }

  await Filesystem.rename({
    from: oldPath,
    to: newPath,
    directory,
  })

  return newPath
}

// --- Helpers ---

function getMimeType(ext) {
  const map = {
    pdf: 'application/pdf',
    jpg: 'image/jpeg',
    jpeg: 'image/jpeg',
    png: 'image/png',
    webp: 'image/webp',
    doc: 'application/msword',
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    txt: 'text/plain',
  }
  return map[ext] || 'application/octet-stream'
}

function base64ToArrayBuffer(base64) {
  const binary = atob(base64)
  const buffer = new ArrayBuffer(binary.length)
  const view = new Uint8Array(buffer)
  for (let i = 0; i < binary.length; i++) {
    view[i] = binary.charCodeAt(i)
  }
  return buffer
}
