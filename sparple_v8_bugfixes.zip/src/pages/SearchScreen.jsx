import React, { useState, useEffect, useRef, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { getDocuments } from '../services/database.js'
import { search } from '../services/search.js'
import DocumentCard from '../components/DocumentCard.jsx'
import styles from './SearchScreen.module.css'

const SUGGESTIONS = [
  'passport', 'aadhaar', 'PAN card', '10th marksheet',
  'electricity bill', 'bank statement', 'salary slip',
  'insurance', 'flight ticket', 'Amazon receipt',
]

export default function SearchScreen() {
  const navigate = useNavigate()
  const [query, setQuery] = useState('')
  const [results, setResults] = useState([])
  const [recentSearches, setRecentSearches] = useState([])
  const [loading, setLoading] = useState(false)
  const [semanticActive, setSemanticActive] = useState(false)
  const [vaultCount, setVaultCount] = useState(null)
  const inputRef = useRef(null)
  const debounceRef = useRef(null)
  const requestIdRef = useRef(0)

  useEffect(() => {
    inputRef.current?.focus()
    const saved = JSON.parse(localStorage.getItem('sparple_searches') || '[]')
    setRecentSearches(saved)
    // Show recent docs on empty
    const recent = getDocuments({ limit: 10 })
    setResults(recent)
    // Total vault size (not just the 10 shown) — lets the empty-results
    // state tell "search found nothing" apart from "vault is empty".
    setVaultCount(getDocuments({ limit: 9999 }).length)
  }, [])

  const doSearch = useCallback(async (q) => {
    const requestId = ++requestIdRef.current
    if (!q.trim()) {
      setResults(getDocuments({ limit: 10 }))
      setSemanticActive(false)
      return
    }
    setLoading(true)
    const { results: res, semanticActive: active } = await search(q)
    if (requestId !== requestIdRef.current) return // a newer search already started
    setResults(res)
    setSemanticActive(active)
    setLoading(false)
  }, [])

  const handleChange = (e) => {
    const q = e.target.value
    setQuery(q)
    clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => doSearch(q), 250)
  }

  const handleSubmit = (q = query) => {
    if (!q.trim()) return
    doSearch(q)
    const updated = [q, ...recentSearches.filter(s => s !== q)].slice(0, 8)
    setRecentSearches(updated)
    localStorage.setItem('sparple_searches', JSON.stringify(updated))
  }

  const clearSearch = () => {
    setQuery('')
    setResults(getDocuments({ limit: 10 }))
    setSemanticActive(false)
    inputRef.current?.focus()
  }

  return (
    <div className={styles.screen}>
      {/* Search bar */}
      <div className={styles.searchHeader}>
        <motion.button
          className={styles.backBtn}
          onClick={() => navigate(-1)}
          whileTap={{ scale: 0.9 }}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <path d="M15 18L9 12L15 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </motion.button>

        <div className={styles.inputWrapper}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" className={styles.searchIcon}>
            <circle cx="10.5" cy="10.5" r="6.5" stroke="var(--text-tertiary)" strokeWidth="1.8" />
            <path d="M15.5 15.5L20 20" stroke="var(--text-tertiary)" strokeWidth="1.8" strokeLinecap="round" />
          </svg>
          <input
            ref={inputRef}
            className={styles.input}
            value={query}
            onChange={handleChange}
            onKeyDown={e => e.key === 'Enter' && handleSubmit()}
            placeholder="Search your documents…"
            autoComplete="off"
            autoCorrect="off"
            spellCheck="false"
          />
          <AnimatePresence>
            {query && (
              <motion.button
                className={styles.clearBtn}
                onClick={clearSearch}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                whileTap={{ scale: 0.8 }}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                  <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                </svg>
              </motion.button>
            )}
          </AnimatePresence>
        </div>
      </div>

      <div className={styles.scroll}>
        {/* No query — show suggestions */}
        {!query && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
          >
            {recentSearches.length > 0 && (
              <div className={styles.section}>
                <p className={styles.sectionTitle}>Recent</p>
                <div className={styles.chipRow}>
                  {recentSearches.map((s) => (
                    <button key={s} className={styles.recentChip} onClick={() => { setQuery(s); handleSubmit(s) }}>
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
                        <path d="M12 6V12L15 15M21 12C21 16.97 16.97 21 12 21C7.03 21 3 16.97 3 12C3 7.03 7.03 3 12 3C16.97 3 21 7.03 21 12Z"
                          stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                      </svg>
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className={styles.section}>
              <p className={styles.sectionTitle}>Try searching for</p>
              <div className={styles.chipRow}>
                {SUGGESTIONS.map((s) => (
                  <button key={s} className={styles.suggChip} onClick={() => { setQuery(s); handleSubmit(s) }}>
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <div className={styles.section}>
              <p className={styles.sectionTitle}>All Documents</p>
              <div className={styles.resultList}>
                {results.map((doc, i) => (
                  <DocumentCard key={doc.id} doc={doc} index={i} />
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {/* Has query — show results */}
        {query && (
          <div>
            {loading ? (
              <div className={styles.loading}>
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                  className={styles.spinner}
                />
              </div>
            ) : results.length === 0 ? (
              <motion.div
                className={styles.empty}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                <span className={styles.emptyIcon}>🔍</span>
                <p className={styles.emptyTitle}>No results for "{query}"</p>
                <p className={styles.emptyDesc}>Try a different keyword or scan more documents.</p>
                {vaultCount !== null && (
                  <p className={styles.emptyDesc} style={{ marginTop: 4, opacity: 0.7 }}>
                    {vaultCount} document{vaultCount !== 1 ? 's' : ''} in your vault total
                  </p>
                )}
              </motion.div>
            ) : (
              <div>
                <p className={styles.resultCount}>
                  {results.length} result{results.length !== 1 ? 's' : ''}
                  {semanticActive && <span className={styles.aiBadge}>✨ AI search</span>}
                </p>
                <div className={styles.resultList}>
                  {results.map((doc, i) => (
                    <DocumentCard key={doc.id} doc={doc} index={i} query={query} />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
