# Sparple v8 — Bugfix Notes

Fixes on top of v7 (permission + storage-path bugs), now that a real device
test with permission granted surfaced the next layer of bugs.

## Bug: only 21 of ~50+ files found (design scope, not a crash)
`SCAN_SUBPATHS` in `scanner.js` originally only covered Downloads,
Documents, and Screenshots — deliberately excluding the regular camera
roll (`DCIM/Camera`, `Pictures`). That's why most of your 31 photos never
showed up; they live in the camera roll, which was intentionally skipped.

**Fix (per your request):** added `DCIM/Camera`, `Pictures`, and
`WhatsApp/Media/WhatsApp Images` to the scan list, so all photos are now
included alongside documents.

## Bug: search returns nothing, even for an exact word in a file
This was the real bug. `searchDocuments()` built the FTS5 query as
`rawUserText + '*'` and passed it straight into `MATCH`. FTS5 treats many
characters as syntax — periods, hyphens, colons, quotes, parentheses — and
also treats the bare words `AND`/`OR`/`NOT`/`NEAR` as operators, not
search terms. A search for something as ordinary as a filename containing
a period, or a word that happens to collide with FTS5 syntax, made SQLite
throw a query-parse error.

That error was being **silently swallowed** by `execQuery()`'s catch block,
which just logged to console and returned `[]` — so from the user's side,
search "just didn't work," with no visible reason why.

**Fix:** added `toFtsQuery()` in `database.js`, which tokenizes the query,
strips FTS5-special characters from each token, wraps every token in
double quotes (which disables operator interpretation — a quoted "AND" is
just the word "and"), and joins tokens with explicit `AND`. This makes
`MATCH` receive valid syntax no matter what the user types.

## Bug: everything lands in "Review" instead of being categorized
Clarified: Sparple never physically moves files into folders — "Review" is
a virtual filter (`needs_review = 1` in the database), not a folder. The
classifier is rule-based keyword matching against known document types
(passport, Aadhaar, bills, etc.) — a random photo correctly has no match
and correctly lands in Review. But if actual matching documents (bills,
receipts) were landing in Review too, that means their extracted text was
empty, which happens when PDF/OCR extraction silently fails.

**Fix:** rather than guess further blind, added in-app diagnostics (see
below) so failures are visible without needing `adb logcat`.

## New: in-app scan diagnostics
Previously, extraction errors were caught internally and only ever logged
to `console.warn` — invisible unless you had a laptop running `adb logcat`.

**Added:**
- `processFile()` now returns per-file diagnostics (chars extracted,
  extraction error if any, classification result, confidence) instead of
  a bare boolean.
- The scan's `complete` event now carries `fileDiagnostics`, `errors`, and
  `modelStatus` (whether the text/image AI models actually loaded).
- The "All Done" screen after a scan now shows a quick-glance summary
  (extraction errors / empty-text files / review count) plus a **"Show
  scan details"** expandable panel listing every file with its exact
  extraction result — including the real error message if one occurred —
  and a "Copy full report" button so you can paste it back here directly
  from your phone.
- The Search screen's empty-results state now also shows total vault size,
  so you can tell "search is broken" apart from "vault has nothing in it."

## Files changed since v7
- `src/services/scanner.js` — wider scan scope, per-file diagnostics
- `src/services/database.js` — FTS5 query sanitization
- `src/pages/ScanScreen.jsx` — diagnostics panel on the Complete screen
- `src/pages/SearchScreen.jsx` — vault-size hint on empty results

## What to check next
1. Rebuild, reinstall (uninstall old app first — schema/DB migrations
   between versions aren't reconciled), and run a scan.
2. On the "All Done" screen, tap **"Show scan details"** — this tells us
   directly whether the AI models loaded, whether any files threw real
   extraction errors, and what confidence/classification each file got.
3. If search still misbehaves, the empty-results screen now shows total
   vault count — if that's 0 or very low, the issue is upstream in
   scanning, not search itself.
4. If you hit any more issues, tap "Copy full report" on the scan-details
   panel and paste it here — that's the fastest path to a real fix instead
   of guessing.
