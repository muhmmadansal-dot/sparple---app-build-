package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.width
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.viewmodel.MainViewModel

@Composable
fun MainScreen(
    viewModel: MainViewModel,
    onRequestPermission: () -> Unit,
    onTriggerScan: () -> Unit,
    modifier: Modifier = Modifier
) {
    val files by viewModel.files.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val chatMessages by viewModel.chatMessages.collectAsState()
    val isTyping by viewModel.isTyping.collectAsState()
    val hasPermission by viewModel.hasStoragePermission.collectAsState()

    var selectedTab by remember { mutableStateOf(0) }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
    ) {
        val isWideScreen = maxWidth >= 720.dp

        if (isWideScreen) {
            // Side-by-side dual pane layout for wide screens
            Row(modifier = Modifier.fillMaxSize()) {
                FileLayout(
                    files = files,
                    isScanning = isScanning,
                    hasPermission = hasPermission,
                    onRequestPermission = onRequestPermission,
                    onTriggerScan = onTriggerScan,
                    modifier = Modifier.weight(1.1f)
                )

                // Split border divider
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(1.dp)
                        .background(Color(0xFF1E293B))
                )

                ChatLayout(
                    messages = chatMessages,
                    isTyping = isTyping,
                    onSendMessage = { text -> viewModel.sendMessage(text) },
                    modifier = Modifier.weight(1f)
                )
            }
        } else {
            // Multi-tab single pane layout for narrow mobile screens
            Column(modifier = Modifier.fillMaxSize()) {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color(0xFF0F172A),
                    contentColor = Color(0xFF10B981),
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = Color(0xFF10B981)
                        )
                    },
                    divider = {
                        HorizontalDivider(color = Color(0xFF1E293B))
                    }
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Text(
                                "Memory Files",
                                fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == 0) Color(0xFFF8FAFC) else Color(0xFF64748B)
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Text(
                                "Sparple Agent",
                                fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == 1) Color(0xFFF8FAFC) else Color(0xFF64748B)
                            )
                        }
                    )
                }

                if (selectedTab == 0) {
                    FileLayout(
                        files = files,
                        isScanning = isScanning,
                        hasPermission = hasPermission,
                        onRequestPermission = onRequestPermission,
                        onTriggerScan = onTriggerScan,
                        modifier = Modifier.weight(1f)
                    )
                } else {
                    ChatLayout(
                        messages = chatMessages,
                        isTyping = isTyping,
                        onSendMessage = { text -> viewModel.sendMessage(text) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}
