package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SplashScreen(
    onSplashFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    val animatableX = remember { Animatable(initialValue = -120f) }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A)), // Premium Deep Slate/Obsidian background
        contentAlignment = Alignment.Center
    ) {
        val screenWidthDp = with(LocalDensity.current) { constraints.maxWidth.toDp() }
        val rabbitWidthDp = 90.dp
        val startX = -rabbitWidthDp
        val endX = screenWidthDp + rabbitWidthDp

        LaunchedEffect(Unit) {
            animatableX.animateTo(
                targetValue = endX.value,
                animationSpec = tween(
                    durationMillis = 1500,
                    easing = FastOutSlowInEasing
                )
            )
            onSplashFinished()
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Sparple",
                style = MaterialTheme.typography.displayLarge.copy(
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 4.sp
                ),
                color = Color(0xFFF8FAFC) // Elegant crisp white
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Text describing purpose
            Text(
                text = "SECOND MEMORY INDEXER",
                style = MaterialTheme.typography.labelLarge.copy(
                    letterSpacing = 5.sp
                ),
                color = Color(0xFF64748B) // Balanced muted text
            )

            Spacer(modifier = Modifier.height(48.dp))

            // The animation runway where the rabbit dashes across
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                MinimalRabbit(
                    modifier = Modifier
                        .offset(x = animatableX.value.dp)
                        .size(width = rabbitWidthDp, height = 45.dp),
                    color = Color(0xFF10B981) // Vibrant Mint/Emerald
                )
            }
        }
    }
}

@Composable
fun MinimalRabbit(
    modifier: Modifier = Modifier,
    color: Color = Color(0xFF10B981)
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Clean modern geometric rabbit silhouette
        // 1. Sleek running body
        drawOval(
            color = color,
            topLeft = androidx.compose.ui.geometry.Offset(w * 0.25f, h * 0.25f),
            size = androidx.compose.ui.geometry.Size(w * 0.45f, h * 0.45f)
        )

        // 2. Head
        drawOval(
            color = color,
            topLeft = androidx.compose.ui.geometry.Offset(w * 0.62f, h * 0.15f),
            size = androidx.compose.ui.geometry.Size(w * 0.20f, h * 0.30f)
        )

        // 3. Ear 1 (Pointing sleekly backward)
        val earPath1 = Path().apply {
            moveTo(w * 0.65f, h * 0.20f)
            quadraticTo(w * 0.50f, h * 0.02f, w * 0.40f, h * 0.10f)
            quadraticTo(w * 0.52f, h * 0.24f, w * 0.63f, h * 0.24f)
            close()
        }
        drawPath(path = earPath1, color = color)

        // 4. Ear 2 (Overlapping offset ear)
        val earPath2 = Path().apply {
            moveTo(w * 0.67f, h * 0.22f)
            quadraticTo(w * 0.54f, h * 0.05f, w * 0.44f, h * 0.13f)
            quadraticTo(w * 0.56f, h * 0.26f, w * 0.65f, h * 0.26f)
            close()
        }
        drawPath(path = earPath2, color = color)

        // 5. Fluffy circle tail
        drawCircle(
            color = color,
            radius = h * 0.10f,
            center = androidx.compose.ui.geometry.Offset(w * 0.23f, h * 0.38f)
        )

        // 6. Extended back running leg
        val backLeg = Path().apply {
            moveTo(w * 0.30f, h * 0.60f)
            quadraticTo(w * 0.12f, h * 0.82f, w * 0.08f, h * 0.78f)
            quadraticTo(w * 0.22f, h * 0.52f, w * 0.35f, h * 0.52f)
            close()
        }
        drawPath(path = backLeg, color = color)

        // 7. Extended front running leg
        val frontLeg = Path().apply {
            moveTo(w * 0.62f, h * 0.58f)
            quadraticTo(w * 0.80f, h * 0.82f, w * 0.86f, h * 0.78f)
            quadraticTo(w * 0.70f, h * 0.48f, w * 0.56f, h * 0.48f)
            close()
        }
        drawPath(path = frontLeg, color = color)
    }
}
