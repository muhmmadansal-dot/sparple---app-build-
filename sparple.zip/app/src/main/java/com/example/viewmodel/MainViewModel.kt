package com.example.viewmodel

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.ChatMessage
import com.example.model.FileType
import com.example.model.MediaFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel : ViewModel() {

    private val _files = MutableStateFlow<List<MediaFile>>(emptyList())
    val files: StateFlow<List<MediaFile>> = _files.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(listOf(
        ChatMessage(
            text = "Welcome to Sparple, your advanced 'Second Memory' neural indexer. I have initialized. Let's start organizing your workspace.",
            isUser = false
        )
    ))
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isTyping = MutableStateFlow(false)
    val isTyping: StateFlow<Boolean> = _isTyping.asStateFlow()

    private val _hasStoragePermission = MutableStateFlow(false)
    val hasStoragePermission: StateFlow<Boolean> = _hasStoragePermission.asStateFlow()

    init {
        loadMockFiles()
    }

    fun setPermissionGranted(granted: Boolean) {
        _hasStoragePermission.value = granted
    }

    fun sendMessage(text: String) {
        if (text.isBlank()) return
        
        // Add user message
        val userMsg = ChatMessage(text = text, isUser = true)
        _chatMessages.value = _chatMessages.value + userMsg

        // Start typing effect for AI
        viewModelScope.launch {
            _isTyping.value = true
            delay(1200) // realistic delay
            _isTyping.value = false
            
            val responseText = "Sparple Index Engine is initializing... [Scanned ${_files.value.size} items from storage. Offline neural model layers are fully cached.]"
            _chatMessages.value = _chatMessages.value + ChatMessage(text = responseText, isUser = false)
        }
    }

    private fun loadMockFiles() {
        _files.value = listOf(
            MediaFile(1, "Brainstorming_Session.mp4", 124000000, "/storage/emulated/0/Movies/Brainstorming_Session.mp4", FileType.VIDEO, System.currentTimeMillis() / 1000 - 3600 * 2, "video/mp4", ""),
            MediaFile(2, "Product_Blueprint_V1.png", 3400000, "/storage/emulated/0/Pictures/Product_Blueprint_V1.png", FileType.IMAGE, System.currentTimeMillis() / 1000 - 3600 * 5, "image/png", ""),
            MediaFile(3, "Sparple_Whitepaper.pdf", 1250000, "/storage/emulated/0/Documents/Sparple_Whitepaper.pdf", FileType.DOCUMENT, System.currentTimeMillis() / 1000 - 3600 * 24, "application/pdf", ""),
            MediaFile(4, "Core_Values_Pitch.pdf", 890000, "/storage/emulated/0/Documents/Core_Values_Pitch.pdf", FileType.DOCUMENT, System.currentTimeMillis() / 1000 - 3600 * 25, "application/pdf", ""),
            MediaFile(5, "User_Interview_Audio.m4a", 45000000, "/storage/emulated/0/Music/User_Interview_Audio.m4a", FileType.AUDIO, System.currentTimeMillis() / 1000 - 3600 * 48, "audio/mp4", ""),
            MediaFile(6, "Feature_List_Draft.txt", 12000, "/storage/emulated/0/Documents/Feature_List_Draft.txt", FileType.DOCUMENT, System.currentTimeMillis() / 1000 - 3600 * 72, "text/plain", "")
        )
    }

    fun performStorageScan(context: Context) {
        if (!_hasStoragePermission.value) return
        
        viewModelScope.launch {
            _isScanning.value = true
            val scannedList = mutableListOf<MediaFile>()
            
            withContext(Dispatchers.IO) {
                try {
                    val resolver: ContentResolver = context.contentResolver
                    
                    // 1. Scan Images
                    val imageUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    val imageProjection = arrayOf(
                        MediaStore.Images.Media._ID,
                        MediaStore.Images.Media.DISPLAY_NAME,
                        MediaStore.Images.Media.SIZE,
                        MediaStore.Images.Media.DATA,
                        MediaStore.Images.Media.DATE_MODIFIED,
                        MediaStore.Images.Media.MIME_TYPE
                    )
                    resolver.query(imageUri, imageProjection, null, null, "${MediaStore.Images.Media.DATE_MODIFIED} DESC")?.use { cursor ->
                        val idCol = cursor.getColumnIndex(MediaStore.Images.Media._ID)
                        val nameCol = cursor.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME)
                        val sizeCol = cursor.getColumnIndex(MediaStore.Images.Media.SIZE)
                        val dataCol = cursor.getColumnIndex(MediaStore.Images.Media.DATA)
                        val dateCol = cursor.getColumnIndex(MediaStore.Images.Media.DATE_MODIFIED)
                        val mimeCol = cursor.getColumnIndex(MediaStore.Images.Media.MIME_TYPE)
                        
                        var count = 0
                        while (cursor.moveToNext() && count < 200) {
                            val id = if (idCol >= 0) cursor.getLong(idCol) else 0L
                            val name = if (nameCol >= 0) cursor.getString(nameCol) else null
                            val size = if (sizeCol >= 0) cursor.getLong(sizeCol) else 0L
                            val data = if (dataCol >= 0) cursor.getString(dataCol) else ""
                            val date = if (dateCol >= 0) cursor.getLong(dateCol) else 0L
                            val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null
                            val fileUri = ContentUris.withAppendedId(imageUri, id).toString()
                            
                            scannedList.add(
                                MediaFile(
                                    id = id,
                                    name = name ?: "Unknown_Image_$id",
                                    size = size,
                                    path = data ?: "",
                                    type = FileType.IMAGE,
                                    dateModified = date,
                                    mimeType = mime,
                                    uriString = fileUri
                                )
                            )
                            count++
                        }
                    }

                    // 2. Scan Videos
                    val videoUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                    val videoProjection = arrayOf(
                        MediaStore.Video.Media._ID,
                        MediaStore.Video.Media.DISPLAY_NAME,
                        MediaStore.Video.Media.SIZE,
                        MediaStore.Video.Media.DATA,
                        MediaStore.Video.Media.DATE_MODIFIED,
                        MediaStore.Video.Media.MIME_TYPE
                    )
                    resolver.query(videoUri, videoProjection, null, null, "${MediaStore.Video.Media.DATE_MODIFIED} DESC")?.use { cursor ->
                        val idCol = cursor.getColumnIndex(MediaStore.Video.Media._ID)
                        val nameCol = cursor.getColumnIndex(MediaStore.Video.Media.DISPLAY_NAME)
                        val sizeCol = cursor.getColumnIndex(MediaStore.Video.Media.SIZE)
                        val dataCol = cursor.getColumnIndex(MediaStore.Video.Media.DATA)
                        val dateCol = cursor.getColumnIndex(MediaStore.Video.Media.DATE_MODIFIED)
                        val mimeCol = cursor.getColumnIndex(MediaStore.Video.Media.MIME_TYPE)
                        
                        var count = 0
                        while (cursor.moveToNext() && count < 100) {
                            val id = if (idCol >= 0) cursor.getLong(idCol) else 0L
                            val name = if (nameCol >= 0) cursor.getString(nameCol) else null
                            val size = if (sizeCol >= 0) cursor.getLong(sizeCol) else 0L
                            val data = if (dataCol >= 0) cursor.getString(dataCol) else ""
                            val date = if (dateCol >= 0) cursor.getLong(dateCol) else 0L
                            val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null
                            val fileUri = ContentUris.withAppendedId(videoUri, id).toString()
                            
                            scannedList.add(
                                MediaFile(
                                    id = id,
                                    name = name ?: "Unknown_Video_$id",
                                    size = size,
                                    path = data ?: "",
                                    type = FileType.VIDEO,
                                    dateModified = date,
                                    mimeType = mime,
                                    uriString = fileUri
                                )
                            )
                            count++
                        }
                    }

                    // 3. Scan Audio
                    val audioUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                    val audioProjection = arrayOf(
                        MediaStore.Audio.Media._ID,
                        MediaStore.Audio.Media.DISPLAY_NAME,
                        MediaStore.Audio.Media.SIZE,
                        MediaStore.Audio.Media.DATA,
                        MediaStore.Audio.Media.DATE_MODIFIED,
                        MediaStore.Audio.Media.MIME_TYPE
                    )
                    resolver.query(audioUri, audioProjection, null, null, "${MediaStore.Audio.Media.DATE_MODIFIED} DESC")?.use { cursor ->
                        val idCol = cursor.getColumnIndex(MediaStore.Audio.Media._ID)
                        val nameCol = cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
                        val sizeCol = cursor.getColumnIndex(MediaStore.Audio.Media.SIZE)
                        val dataCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
                        val dateCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATE_MODIFIED)
                        val mimeCol = cursor.getColumnIndex(MediaStore.Audio.Media.MIME_TYPE)
                        
                        var count = 0
                        while (cursor.moveToNext() && count < 100) {
                            val id = if (idCol >= 0) cursor.getLong(idCol) else 0L
                            val name = if (nameCol >= 0) cursor.getString(nameCol) else null
                            val size = if (sizeCol >= 0) cursor.getLong(sizeCol) else 0L
                            val data = if (dataCol >= 0) cursor.getString(dataCol) else ""
                            val date = if (dateCol >= 0) cursor.getLong(dateCol) else 0L
                            val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null
                            val fileUri = ContentUris.withAppendedId(audioUri, id).toString()
                            
                            scannedList.add(
                                MediaFile(
                                    id = id,
                                    name = name ?: "Unknown_Audio_$id",
                                    size = size,
                                    path = data ?: "",
                                    type = FileType.AUDIO,
                                    dateModified = date,
                                    mimeType = mime,
                                    uriString = fileUri
                                )
                            )
                            count++
                        }
                    }

                    // 4. Scan general files (Documents/Downloads) via MediaStore.Files
                    val filesUri = MediaStore.Files.getContentUri("external")
                    val filesProjection = arrayOf(
                        MediaStore.Files.FileColumns._ID,
                        MediaStore.Files.FileColumns.DISPLAY_NAME,
                        MediaStore.Files.FileColumns.SIZE,
                        MediaStore.Files.FileColumns.DATA,
                        MediaStore.Files.FileColumns.DATE_MODIFIED,
                        MediaStore.Files.FileColumns.MIME_TYPE
                    )
                    val selection = "${MediaStore.Files.FileColumns.MIME_TYPE} LIKE ? OR " +
                            "${MediaStore.Files.FileColumns.MIME_TYPE} LIKE ? OR " +
                            "${MediaStore.Files.FileColumns.MIME_TYPE} = ? OR " +
                            "${MediaStore.Files.FileColumns.MIME_TYPE} = ?"
                    val selectionArgs = arrayOf(
                        "application/%",
                        "text/%",
                        "application/pdf",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    )
                    resolver.query(filesUri, filesProjection, selection, selectionArgs, "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC")?.use { cursor ->
                        val idCol = cursor.getColumnIndex(MediaStore.Files.FileColumns._ID)
                        val nameCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME)
                        val sizeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.SIZE)
                        val dataCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATA)
                        val dateCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATE_MODIFIED)
                        val mimeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.MIME_TYPE)
                        
                        var count = 0
                        while (cursor.moveToNext() && count < 200) {
                            val id = if (idCol >= 0) cursor.getLong(idCol) else 0L
                            val name = if (nameCol >= 0) cursor.getString(nameCol) else null
                            val size = if (sizeCol >= 0) cursor.getLong(sizeCol) else 0L
                            val data = if (dataCol >= 0) cursor.getString(dataCol) else ""
                            val date = if (dateCol >= 0) cursor.getLong(dateCol) else 0L
                            val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null
                            val fileUri = ContentUris.withAppendedId(filesUri, id).toString()
                            
                            if (data.isNotEmpty() && scannedList.none { it.path == data }) {
                                scannedList.add(
                                    MediaFile(
                                        id = id,
                                        name = name ?: "Document_$id",
                                        size = size,
                                        path = data,
                                        type = FileType.DOCUMENT,
                                        dateModified = date,
                                        mimeType = mime,
                                        uriString = fileUri
                                    )
                                )
                            }
                            count++
                        }
                    }

                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            
            // If we successfully found real device files, overwrite mock list
            if (scannedList.isNotEmpty()) {
                _files.value = scannedList.sortedByDescending { it.dateModified }
            }
            _isScanning.value = false
        }
    }
}
