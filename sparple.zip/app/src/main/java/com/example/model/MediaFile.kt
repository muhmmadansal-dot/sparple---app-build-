package com.example.model

enum class FileType {
    IMAGE, VIDEO, AUDIO, DOCUMENT, OTHER
}

data class MediaFile(
    val id: Long,
    val name: String,
    val size: Long,
    val path: String,
    val type: FileType,
    val dateModified: Long,
    val mimeType: String?,
    val uriString: String
)
