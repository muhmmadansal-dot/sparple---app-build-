package com.example

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.example.ui.components.MainScreen
import com.example.ui.components.SplashScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    
    private val mainViewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val context = LocalContext.current
                var isSplashActive by remember { mutableStateOf(true) }

                // Check permissions on startup
                LaunchedEffect(Unit) {
                    val alreadyGranted = hasStoragePermissions(context)
                    mainViewModel.setPermissionGranted(alreadyGranted)
                    if (alreadyGranted) {
                        mainViewModel.performStorageScan(context)
                    }
                }

                // Standard permission launcher
                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestMultiplePermissions()
                ) { permissionsMap ->
                    val isAnyGranted = permissionsMap.values.any { it }
                    mainViewModel.setPermissionGranted(isAnyGranted)
                    if (isAnyGranted) {
                        mainViewModel.performStorageScan(context)
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    Crossfade(
                        targetState = isSplashActive,
                        animationSpec = tween(durationMillis = 600),
                        label = "SplashToMainTransition",
                        modifier = Modifier.padding(innerPadding)
                    ) { active ->
                        if (active) {
                            SplashScreen(
                                onSplashFinished = {
                                    isSplashActive = false
                                }
                            )
                        } else {
                            MainScreen(
                                viewModel = mainViewModel,
                                onRequestPermission = {
                                    permissionLauncher.launch(getRequiredPermissions())
                                },
                                onTriggerScan = {
                                    if (hasStoragePermissions(context)) {
                                        mainViewModel.performStorageScan(context)
                                    } else {
                                        permissionLauncher.launch(getRequiredPermissions())
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    private fun hasStoragePermissions(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun getRequiredPermissions(): Array<String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }
}
