import React from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import styles from './DocumentCard.module.css'

const TYPE_COLORS = {
  Government: 'var(--doc-government)',
  Education: 'var(--doc-education)',
  Medical: 'var(--doc-medical)',
  Financial: 'var(--doc-financial)',
  Travel: 'var(--doc-travel)',
  Bills: 'var(--doc-identity)',
  Shopping: '#FB923C',
  Photos: '#FB7185',
  Videos: '#22D3EE',
  Vehicle: 'var(--doc-other)',
  Property: '#86EFAC',
  Other: 'var(--doc-other)',
}

const TYPE_ICONS = {
  passport: '🛂',
  aadhaar: '🪪',
  pan: '💳',
  voter_id: '🗳️',
  driving_license: '🚗',
  birth_certificate: '👶',
  tenth_marksheet: '📚',
  twelfth_marksheet: '📚',
  degree_certificate: '🎓',
  college_id: '🏫',
  medical_report: '🩺',
  prescription: '💊',
  insurance: '🛡️',
  bank_statement: '🏦',
  salary_slip: '💰',
  itr: '📊',
  gst_invoice: '🧾',
  electricity_bill: '⚡',
  gas_bill: '🔥',
  water_bill: '💧',
  mobile_bill: '📱',
  receipt: '🧾',
  amazon_receipt: '📦',
  flight_ticket: '✈️',
  train_ticket: '🚆',
  bus_ticket: '🚌',
  hotel_booking: '🏨',
  vehicle_rc: '🚗',
  property_document: '🏠',
  photo: '🖼️',
  video: '🎬',
  unknown: '📄',
}

export default function DocumentCard({ doc, index = 0, query }) {
  const navigate = useNavigate()
  const color = TYPE_COLORS[doc.category] || 'var(--doc-other)'
  const icon = TYPE_ICONS[doc.type] || '📄'
  const ext = doc.name?.split('.').pop()?.toUpperCase() || 'FILE'
  const labels = doc.all_labels ? doc.all_labels.split('|') : []

  const handleTap = () => {
    navigate(`/document/${doc.id}`)
  }

  return (
    <motion.button
      className={styles.card}
      onClick={handleTap}
      whileTap={{ scale: 0.97 }}
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.04, duration: 0.3, ease: [0.4, 0, 0.2, 1] }}
      style={{ '--type-color': color }}
    >
      {/* File type accent */}
      <div className={styles.accent} />

      {/* Icon */}
      <div className={styles.iconWrap}>
        <span className={styles.typeIcon}>{icon}</span>
        <span className={styles.extBadge}>{ext}</span>
      </div>

      {/* Content */}
      <div className={styles.content}>
        <p className={styles.name}>{doc.name}</p>
        <div className={styles.meta}>
          <span className={styles.label} style={{ color }}>
            {doc.label}
          </span>
          {doc.confidence > 0 && (
            <span className={styles.confidence}>{doc.confidence}%</span>
          )}
          {doc.needs_review === 1 && (
            <span className={styles.reviewTag}>Review</span>
          )}
        </div>
        {labels.slice(0, 3).length > 0 && (
          <div className={styles.labelChips}>
            {labels.slice(0, 3).map(l => (
              <span key={l} className={styles.labelChip}>{l}</span>
            ))}
          </div>
        )}
      </div>

      {/* Arrow */}
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" className={styles.arrow}>
        <path d="M9 18L15 12L9 6" stroke="var(--text-tertiary)" strokeWidth="1.8" strokeLinecap="round" />
      </svg>

      {doc.is_starred === 1 && (
        <div className={styles.star}>⭐</div>
      )}
    </motion.button>
  )
}
