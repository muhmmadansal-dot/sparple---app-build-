import React from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import styles from './ResultCard.module.css'

const TYPE_COLORS = {
  Government: '#818CF8', Education: '#34D399', Medical: '#F87171',
  Financial: '#FBBF24', Travel: '#60A5FA', Bills: '#A78BFA',
  Shopping: '#FB923C', Vehicle: '#94A3B8', Property: '#86EFAC',
  Photos: '#FB7185', Videos: '#22D3EE', Other: '#94A3B8',
}

const TYPE_ICONS = {
  passport: '🛂', aadhaar: '🪪', pan: '💳', voter_id: '🗳️',
  driving_license: '🚗', birth_certificate: '👶', tenth_marksheet: '📚',
  twelfth_marksheet: '📚', degree_certificate: '🎓', college_id: '🏫',
  medical_report: '🩺', prescription: '💊', insurance: '🛡️',
  bank_statement: '🏦', salary_slip: '💰', itr: '📊', gst_invoice: '🧾',
  electricity_bill: '⚡', gas_bill: '🔥', water_bill: '💧', mobile_bill: '📱',
  receipt: '🧾', amazon_receipt: '📦', flight_ticket: '✈️', train_ticket: '🚆',
  bus_ticket: '🚌', hotel_booking: '🏨', vehicle_rc: '🚗',
  property_document: '🏠', photo: '🖼️', video: '🎬', unknown: '📄',
}

/**
 * Premium chat-style result card. Big thumbnail when available,
 * rich metadata row, matched-text snippet with highlight.
 * This is the "feels like a billion dollar app" search result.
 */
export default function ResultCard({ doc, index = 0, query }) {
  const navigate = useNavigate()
  const color = TYPE_COLORS[doc.category] || '#94A3B8'
  const icon = TYPE_ICONS[doc.type] || '📄'
  const hasThumbnail = !!doc.thumbnail_b64
  const isMedia = doc.type === 'photo' || doc.type === 'video'
  const ext = doc.name?.split('.').pop()?.toUpperCase() || 'FILE'

  const snippet = getSnippet(doc.extracted_text, query)

  return (
    <motion.button
      className={styles.card}
      onClick={() => navigate(`/document/${doc.id}`)}
      whileTap={{ scale: 0.97 }}
      initial={{ opacity: 0, y: 20, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ delay: index * 0.05, duration: 0.35, ease: [0.4, 0, 0.2, 1] }}
      style={{ '--type-color': color }}
    >
      {/* Thumbnail header — only for images/videos that have one */}
      {hasThumbnail && (
        <div className={styles.thumbWrap}>
          <img src={doc.thumbnail_b64} alt="" className={styles.thumb} />
          <div className={styles.thumbGradient} />
          {doc.type === 'video' && doc.duration_seconds > 0 && (
            <span className={styles.durationBadge}>{formatDuration(doc.duration_seconds)}</span>
          )}
          <div className={styles.thumbOverlay}>
            <span className={styles.thumbIcon}>{icon}</span>
            <span className={styles.thumbLabel}>{doc.label}</span>
          </div>
        </div>
      )}

      {/* No thumbnail — compact icon row (PDFs, docs) */}
      {!hasThumbnail && (
        <div className={styles.iconRow}>
          <div className={styles.iconBox}>
            <span className={styles.docIcon}>{icon}</span>
            <span className={styles.extTag}>{ext}</span>
          </div>
          <div className={styles.iconRowText}>
            <span className={styles.label} style={{ color }}>{doc.label}</span>
            {doc.confidence > 0 && !isMedia && (
              <span className={styles.confidence}>{doc.confidence}% match</span>
            )}
          </div>
        </div>
      )}

      {/* Body */}
      <div className={styles.body}>
        <p className={styles.name}>{doc.name}</p>

        {snippet && (
          <p className={styles.snippet} dangerouslySetInnerHTML={{ __html: snippet }} />
        )}

        <div className={styles.metaRow}>
          {doc._fuzzyScore !== undefined && (
            <span className={styles.fuzzyTag}>Close match</span>
          )}
          {doc.all_labels && doc.all_labels.split('|').slice(0, 2).map(l => (
            <span key={l} className={styles.tag}>{l}</span>
          ))}
          {doc.needs_review === 1 && (
            <span className={styles.reviewTag}>⚠️ Needs review</span>
          )}
          {doc.is_starred === 1 && <span className={styles.starTag}>⭐</span>}
        </div>
      </div>

      <div className={styles.chevron}>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
          <path d="M9 18L15 12L9 6" stroke="var(--text-tertiary)" strokeWidth="2" strokeLinecap="round" />
        </svg>
      </div>
    </motion.button>
  )
}

function getSnippet(text, query) {
  if (!text) return null
  const clean = text.replace(/\s+/g, ' ').trim()
  if (!clean) return null

  if (!query) return escapeHtml(clean.substring(0, 90)) + (clean.length > 90 ? '…' : '')

  const lowerText = clean.toLowerCase()
  const lowerQuery = query.toLowerCase()
  const idx = lowerText.indexOf(lowerQuery)

  if (idx === -1) {
    return escapeHtml(clean.substring(0, 90)) + (clean.length > 90 ? '…' : '')
  }

  const start = Math.max(0, idx - 30)
  const end = Math.min(clean.length, idx + query.length + 60)
  let snippet = clean.substring(start, end)
  if (start > 0) snippet = '…' + snippet
  if (end < clean.length) snippet = snippet + '…'

  // Highlight the match
  const escaped = escapeHtml(snippet)
  const re = new RegExp(`(${escapeRegex(query)})`, 'ig')
  return escaped.replace(re, '<mark>$1</mark>')
}

function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
}

function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

function formatDuration(seconds) {
  const m = Math.floor(seconds / 60)
  const s = seconds % 60
  return `${m}:${s.toString().padStart(2, '0')}`
}
