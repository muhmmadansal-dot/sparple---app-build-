/**
 * SPARPLE Scanner Service
 * Scans device storage, extracts text, classifies documents
 */

import { Filesystem, Directory } from '@capacitor/filesystem'
import { classifyDocument, classifyMedia, suggestFilename, getSystemLabels } from './classifier.js'
import {
  initDB, persistDB, insertDocument, insertDocumentLabels,
  documentExists, insertScanHistory
} from './database.js'
import { refreshSearchIndex } from './search.js'

// Folders to scan on Android — full device scan, not just document folders
const SCAN_DIRECTORIES = [
  { path: 'Downloads', directory: Directory.ExternalStorage },
  { path: 'Documents', directory: Directory.ExternalStorage },
  { path: 'DCIM', directory: Directory.ExternalStorage },
  { path: 'Pictures', directory: Directory.ExternalStorage },
  { path: 'Movies', directory: Directory.ExternalStorage },
  { path: 'WhatsApp/Media/WhatsApp Documents', directory: Directory.ExternalStorage },
  { path: 'WhatsApp/Media/WhatsApp Images', directory: Directory.ExternalStorage },
  { path: 'WhatsApp/Media/WhatsApp Video', directory: Directory.ExternalStorage },
  { path: 'Telegram', directory: Directory.ExternalStorage },
]

const DOCUMENT_EXTENSIONS = new Set(['pdf', 'doc', 'docx', 'txt'])
const IMAGE_EXTENSIONS = new Set(['jpg', 'jpeg', 'png', 'webp', 'heic', 'heif', 'gif', 'bmp'])
const VIDEO_EXTENSIONS = new Set(['mp4', 'mov', 'mkv', 'webm', '3gp', 'avi', 'm4v'])

const SUPPORTED_EXTENSIONS = new Set([
  ...DOCUMENT_EXTENSIONS, ...IMAGE_EXTENSIONS, ...VIDEO_EXTENSIONS,
])

// Confidence below this on an image means "not a recognizable document" —
// it gets bucketed as a Photo instead of flagged for review
const DOCUMENT_CONFIDENCE_FLOOR = 40

export class Scanner {
  constructor(onProgress) {
    this.onProgress = onProgress || (() => {})
    this.aborted = false
    this.worker = null
  }

  abort() {
    this.aborted = true
  }

  async scan() {
    const startTime = Date.now()
    await initDB()

    let totalFiles = 0
    let processed = 0
    let newFiles = 0
    const errors = []

    this.onProgress({ phase: 'discovering', progress: 0, message: 'Finding your files...' })

    // Discover all files
    const allFiles = await this.discoverFiles()
    totalFiles = allFiles.length

    this.onProgress({
      phase: 'scanning',
      progress: 0,
      message: `Found ${totalFiles} files`,
      total: totalFiles,
    })

    // Process in batches
    const BATCH_SIZE = 5
    for (let i = 0; i < allFiles.length; i += BATCH_SIZE) {
      if (this.aborted) break

      const batch = allFiles.slice(i, i + BATCH_SIZE)
      await Promise.allSettled(
        batch.map(async (file) => {
          try {
            const isNew = await this.processFile(file)
            if (isNew) newFiles++
          } catch (err) {
            errors.push({ file: file.path, error: err.message })
          }
          processed++
          this.onProgress({
            phase: 'scanning',
            progress: Math.round((processed / totalFiles) * 100),
            message: `Processing ${processed} of ${totalFiles}`,
            current: file.name,
            total: totalFiles,
            processed,
            newFiles,
          })
        })
      )
    }

    await persistDB()

    const durationMs = Date.now() - startTime
    insertScanHistory({ totalFiles, newFiles, durationMs })
    await persistDB()

    // Rebuild the fuzzy search index so new documents are searchable right away
    refreshSearchIndex()

    this.onProgress({
      phase: 'complete',
      progress: 100,
      message: `Indexed ${newFiles} new documents`,
      total: totalFiles,
      processed: totalFiles,
      newFiles,
      durationMs,
    })

    return { totalFiles, newFiles, durationMs, errors }
  }

  async discoverFiles() {
    const files = []

    for (const dir of SCAN_DIRECTORIES) {
      try {
        await this.walkDirectory(dir.path, dir.directory, files)
      } catch {
        // Directory doesn't exist or no permission — skip
      }
    }

    return files
  }

  async walkDirectory(path, directory, files, depth = 0) {
    if (depth > 3) return // Don't go too deep

    try {
      const result = await Filesystem.readdir({ path, directory })

      for (const item of result.files) {
        if (this.aborted) return

        const fullPath = `${path}/${item.name}`

        if (item.type === 'directory') {
          await this.walkDirectory(fullPath, directory, files, depth + 1)
        } else {
          const ext = item.name.split('.').pop()?.toLowerCase()
          if (SUPPORTED_EXTENSIONS.has(ext)) {
            files.push({
              name: item.name,
              path: fullPath,
              directory,
              size: item.size || 0,
              mtime: item.mtime,
              ext,
            })
          }
        }
      }
    } catch {
      // Skip unreadable directories
    }
  }

  async processFile(file) {
    // Skip if already indexed
    if (documentExists(file.path)) return false

    let extractedText = ''
    let thumbnailB64 = ''
    let classification
    let mediaMeta = {}
    const mimeType = getMimeType(file.ext)

    try {
      if (DOCUMENT_EXTENSIONS.has(file.ext)) {
        // Pure documents — PDF, DOC, TXT — always go through text extraction
        if (file.ext === 'pdf') {
          extractedText = await this.extractPdfText(file)
        } else if (file.ext === 'txt') {
          extractedText = await this.readTextFile(file)
        }
        classification = classifyDocument(extractedText)

      } else if (IMAGE_EXTENSIONS.has(file.ext)) {
        // Images — run OCR to check if it's a document, otherwise it's a photo
        const result = await this.extractImageText(file)
        extractedText = result.text
        thumbnailB64 = result.thumbnail

        const docGuess = classifyDocument(extractedText)
        if (docGuess.confidence >= DOCUMENT_CONFIDENCE_FLOOR) {
          classification = docGuess
        } else {
          classification = classifyMedia('photo')
        }

      } else if (VIDEO_EXTENSIONS.has(file.ext)) {
        // Videos — no OCR, just catalog with a frame thumbnail
        const result = await this.extractVideoThumbnail(file)
        thumbnailB64 = result.thumbnail
        mediaMeta = { duration: result.duration, width: result.width, height: result.height }
        classification = classifyMedia('video')
      }
    } catch (err) {
      console.warn(`[Scanner] Processing failed for ${file.name}:`, err)
      classification = IMAGE_EXTENSIONS.has(file.ext)
        ? classifyMedia('photo')
        : VIDEO_EXTENSIONS.has(file.ext)
          ? classifyMedia('video')
          : { type: 'unknown', label: 'Unknown', category: 'Other', confidence: 0, tags: [] }
    }

    // Only documents with genuinely low confidence need human review —
    // photos and videos are never flagged for review, they're just media
    const isDocumentFile = DOCUMENT_EXTENSIONS.has(file.ext) ||
      (IMAGE_EXTENSIONS.has(file.ext) && classification.type !== 'photo')
    const needsReview = isDocumentFile && classification.confidence < DOCUMENT_CONFIDENCE_FLOOR

    const docData = {
      name: file.name,
      originalName: file.name,
      path: file.path,
      type: classification.type,
      category: classification.category,
      label: classification.label,
      confidence: classification.confidence,
      extractedText: extractedText.substring(0, 10000),
      suggestedName: isDocumentFile ? suggestFilename(classification, extractedText, file.name) : file.name,
      fileSize: file.size,
      mimeType,
      thumbnailB64,
      needsReview,
      createdAt: file.mtime ? new Date(file.mtime).toISOString() : new Date().toISOString(),
      modifiedAt: file.mtime ? new Date(file.mtime).toISOString() : new Date().toISOString(),
      durationSeconds: mediaMeta.duration || 0,
    }

    const docId = insertDocument(docData)
    if (docId) {
      const labels = getSystemLabels(classification.type)
      insertDocumentLabels(docId, labels)
    }

    return true
  }

  async extractPdfText(file) {
    const pdfjsLib = await import('pdfjs-dist')
    pdfjsLib.GlobalWorkerOptions.workerSrc = '/pdf.worker.min.js'

    try {
      const fileData = await Filesystem.readFile({
        path: file.path,
        directory: file.directory,
      })

      const arrayBuffer = base64ToArrayBuffer(fileData.data)
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise

      let text = ''
      const maxPages = Math.min(pdf.numPages, 5) // First 5 pages

      for (let i = 1; i <= maxPages; i++) {
        const page = await pdf.getPage(i)
        const content = await page.getTextContent()
        text += content.items.map(item => item.str).join(' ') + '\n'
      }

      return text
    } catch (err) {
      throw new Error(`PDF extraction failed: ${err.message}`)
    }
  }

  async extractImageText(file) {
    const Tesseract = await import('tesseract.js')

    try {
      const fileData = await Filesystem.readFile({
        path: file.path,
        directory: file.directory,
      })

      const dataUrl = `data:${getMimeType(file.ext)};base64,${fileData.data}`
      const thumbnail = await this.resizeImageThumbnail(dataUrl)

      const result = await Tesseract.recognize(dataUrl, 'eng', {
        logger: () => {}, // Suppress verbose logs
      })

      return {
        text: result.data.text,
        thumbnail,
      }
    } catch (err) {
      throw new Error(`OCR failed: ${err.message}`)
    }
  }

  resizeImageThumbnail(dataUrl, maxDim = 320) {
    return new Promise((resolve) => {
      const img = new Image()
      img.onload = () => {
        try {
          const scale = Math.min(maxDim / img.width, maxDim / img.height, 1)
          const canvas = document.createElement('canvas')
          canvas.width = img.width * scale
          canvas.height = img.height * scale
          const ctx = canvas.getContext('2d')
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
          resolve(canvas.toDataURL('image/jpeg', 0.7))
        } catch {
          resolve(dataUrl) // Fallback to original if resize fails
        }
      }
      img.onerror = () => resolve(dataUrl)
      img.src = dataUrl
    })
  }

  async extractVideoThumbnail(file) {
    const fileData = await Filesystem.readFile({
      path: file.path,
      directory: file.directory,
    })

    const dataUrl = `data:${getMimeType(file.ext)};base64,${fileData.data}`

    return new Promise((resolve, reject) => {
      const video = document.createElement('video')
      video.preload = 'metadata'
      video.muted = true
      video.playsInline = true
      video.src = dataUrl

      const timeout = setTimeout(() => {
        cleanup()
        reject(new Error('Video thumbnail timed out'))
      }, 8000)

      const cleanup = () => {
        clearTimeout(timeout)
        video.src = ''
        video.remove()
      }

      video.onloadedmetadata = () => {
        // Seek to 1s in, or 10% of duration for very short clips
        const seekTime = Math.min(1, video.duration * 0.1)
        video.currentTime = isFinite(seekTime) ? seekTime : 0
      }

      video.onseeked = () => {
        try {
          const canvas = document.createElement('canvas')
          const maxDim = 320
          const scale = Math.min(maxDim / video.videoWidth, maxDim / video.videoHeight, 1)
          canvas.width = video.videoWidth * scale
          canvas.height = video.videoHeight * scale

          const ctx = canvas.getContext('2d')
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height)
          const thumbnail = canvas.toDataURL('image/jpeg', 0.7)

          const result = {
            thumbnail,
            duration: Math.round(video.duration || 0),
            width: video.videoWidth,
            height: video.videoHeight,
          }
          cleanup()
          resolve(result)
        } catch (err) {
          cleanup()
          reject(err)
        }
      }

      video.onerror = () => {
        cleanup()
        reject(new Error('Could not load video for thumbnail'))
      }
    })
  }

  async readTextFile(file) {
    const result = await Filesystem.readFile({
      path: file.path,
      directory: file.directory,
      encoding: 'utf8',
    })
    return result.data
  }
}

// --- File renaming ---

export async function renameFile(oldPath, newName, directory) {
  const dir = oldPath.substring(0, oldPath.lastIndexOf('/'))
  const newPath = `${dir}/${newName}`

  await Filesystem.rename({
    from: oldPath,
    to: newPath,
    directory,
  })

  return newPath
}

// --- Helpers ---

function getMimeType(ext) {
  const map = {
    pdf: 'application/pdf',
    jpg: 'image/jpeg',
    jpeg: 'image/jpeg',
    png: 'image/png',
    webp: 'image/webp',
    heic: 'image/heic',
    heif: 'image/heif',
    gif: 'image/gif',
    bmp: 'image/bmp',
    doc: 'application/msword',
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    txt: 'text/plain',
    mp4: 'video/mp4',
    mov: 'video/quicktime',
    mkv: 'video/x-matroska',
    webm: 'video/webm',
    '3gp': 'video/3gpp',
    avi: 'video/x-msvideo',
    m4v: 'video/x-m4v',
  }
  return map[ext] || 'application/octet-stream'
}

function base64ToArrayBuffer(base64) {
  const binary = atob(base64)
  const buffer = new ArrayBuffer(binary.length)
  const view = new Uint8Array(buffer)
  for (let i = 0; i < binary.length; i++) {
    view[i] = binary.charCodeAt(i)
  }
  return buffer
}
