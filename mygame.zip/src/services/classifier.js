/**
 * SPARPLE Document Classifier
 * Rule-based pattern matching for Indian & international documents
 * Zero dependencies, runs fully offline
 */

export const DOC_TYPES = {
  PASSPORT: 'passport',
  AADHAAR: 'aadhaar',
  PAN: 'pan',
  VOTER_ID: 'voter_id',
  DRIVING_LICENSE: 'driving_license',
  BIRTH_CERTIFICATE: 'birth_certificate',
  TENTH_MARKSHEET: 'tenth_marksheet',
  TWELFTH_MARKSHEET: 'twelfth_marksheet',
  DEGREE_CERTIFICATE: 'degree_certificate',
  COLLEGE_ID: 'college_id',
  MEDICAL_REPORT: 'medical_report',
  PRESCRIPTION: 'prescription',
  INSURANCE: 'insurance',
  BANK_STATEMENT: 'bank_statement',
  SALARY_SLIP: 'salary_slip',
  ITR: 'itr',
  GST_INVOICE: 'gst_invoice',
  ELECTRICITY_BILL: 'electricity_bill',
  GAS_BILL: 'gas_bill',
  WATER_BILL: 'water_bill',
  MOBILE_BILL: 'mobile_bill',
  RECEIPT: 'receipt',
  AMAZON_RECEIPT: 'amazon_receipt',
  FLIGHT_TICKET: 'flight_ticket',
  TRAIN_TICKET: 'train_ticket',
  BUS_TICKET: 'bus_ticket',
  HOTEL_BOOKING: 'hotel_booking',
  VEHICLE_RC: 'vehicle_rc',
  PROPERTY_DOCUMENT: 'property_document',
  PHOTO: 'photo',
  VIDEO: 'video',
  UNKNOWN: 'unknown',
}

export const DOC_CATEGORIES = {
  [DOC_TYPES.PASSPORT]: 'Government',
  [DOC_TYPES.AADHAAR]: 'Government',
  [DOC_TYPES.PAN]: 'Government',
  [DOC_TYPES.VOTER_ID]: 'Government',
  [DOC_TYPES.DRIVING_LICENSE]: 'Government',
  [DOC_TYPES.BIRTH_CERTIFICATE]: 'Government',
  [DOC_TYPES.TENTH_MARKSHEET]: 'Education',
  [DOC_TYPES.TWELFTH_MARKSHEET]: 'Education',
  [DOC_TYPES.DEGREE_CERTIFICATE]: 'Education',
  [DOC_TYPES.COLLEGE_ID]: 'Education',
  [DOC_TYPES.MEDICAL_REPORT]: 'Medical',
  [DOC_TYPES.PRESCRIPTION]: 'Medical',
  [DOC_TYPES.INSURANCE]: 'Financial',
  [DOC_TYPES.BANK_STATEMENT]: 'Financial',
  [DOC_TYPES.SALARY_SLIP]: 'Financial',
  [DOC_TYPES.ITR]: 'Financial',
  [DOC_TYPES.GST_INVOICE]: 'Financial',
  [DOC_TYPES.ELECTRICITY_BILL]: 'Bills',
  [DOC_TYPES.GAS_BILL]: 'Bills',
  [DOC_TYPES.WATER_BILL]: 'Bills',
  [DOC_TYPES.MOBILE_BILL]: 'Bills',
  [DOC_TYPES.RECEIPT]: 'Shopping',
  [DOC_TYPES.AMAZON_RECEIPT]: 'Shopping',
  [DOC_TYPES.FLIGHT_TICKET]: 'Travel',
  [DOC_TYPES.TRAIN_TICKET]: 'Travel',
  [DOC_TYPES.BUS_TICKET]: 'Travel',
  [DOC_TYPES.HOTEL_BOOKING]: 'Travel',
  [DOC_TYPES.VEHICLE_RC]: 'Vehicle',
  [DOC_TYPES.PROPERTY_DOCUMENT]: 'Property',
  [DOC_TYPES.PHOTO]: 'Photos',
  [DOC_TYPES.VIDEO]: 'Videos',
  [DOC_TYPES.UNKNOWN]: 'Other',
}

export const DOC_LABELS = {
  [DOC_TYPES.PASSPORT]: 'Passport',
  [DOC_TYPES.AADHAAR]: 'Aadhaar Card',
  [DOC_TYPES.PAN]: 'PAN Card',
  [DOC_TYPES.VOTER_ID]: 'Voter ID',
  [DOC_TYPES.DRIVING_LICENSE]: 'Driving Licence',
  [DOC_TYPES.BIRTH_CERTIFICATE]: 'Birth Certificate',
  [DOC_TYPES.TENTH_MARKSHEET]: '10th Marksheet',
  [DOC_TYPES.TWELFTH_MARKSHEET]: '12th Marksheet',
  [DOC_TYPES.DEGREE_CERTIFICATE]: 'Degree Certificate',
  [DOC_TYPES.COLLEGE_ID]: 'College ID',
  [DOC_TYPES.MEDICAL_REPORT]: 'Medical Report',
  [DOC_TYPES.PRESCRIPTION]: 'Prescription',
  [DOC_TYPES.INSURANCE]: 'Insurance',
  [DOC_TYPES.BANK_STATEMENT]: 'Bank Statement',
  [DOC_TYPES.SALARY_SLIP]: 'Salary Slip',
  [DOC_TYPES.ITR]: 'Income Tax Return',
  [DOC_TYPES.GST_INVOICE]: 'GST Invoice',
  [DOC_TYPES.ELECTRICITY_BILL]: 'Electricity Bill',
  [DOC_TYPES.GAS_BILL]: 'Gas Bill',
  [DOC_TYPES.WATER_BILL]: 'Water Bill',
  [DOC_TYPES.MOBILE_BILL]: 'Mobile Bill',
  [DOC_TYPES.RECEIPT]: 'Receipt',
  [DOC_TYPES.AMAZON_RECEIPT]: 'Amazon Receipt',
  [DOC_TYPES.FLIGHT_TICKET]: 'Flight Ticket',
  [DOC_TYPES.TRAIN_TICKET]: 'Train Ticket',
  [DOC_TYPES.BUS_TICKET]: 'Bus Ticket',
  [DOC_TYPES.HOTEL_BOOKING]: 'Hotel Booking',
  [DOC_TYPES.VEHICLE_RC]: 'Vehicle RC',
  [DOC_TYPES.PROPERTY_DOCUMENT]: 'Property Document',
  [DOC_TYPES.PHOTO]: 'Photo',
  [DOC_TYPES.VIDEO]: 'Video',
  [DOC_TYPES.UNKNOWN]: 'Unknown',
}

// Classification rules — each rule has patterns and a weight
const RULES = [
  {
    type: DOC_TYPES.PASSPORT,
    patterns: [
      /passport\s*no/i, /passport\s*number/i, /republic\s*of\s*india.*passport/i,
      /\bpassport\b/i, /machine\s*readable\s*zone/i, /\bMRZ\b/,
      /nationality.*indian/i, /place\s*of\s*birth/i,
      /[A-Z]\d{7}/, // Indian passport number format
    ],
    weights: [3, 3, 4, 2, 3, 3, 2, 1, 4],
    threshold: 4,
  },
  {
    type: DOC_TYPES.AADHAAR,
    patterns: [
      /aadhaar/i, /aadhar/i, /uidai/i, /unique\s*identification/i,
      /\d{4}\s\d{4}\s\d{4}/, // Aadhaar number format
      /enrolment\s*no/i, /vid\s*:\s*\d/i,
      /government\s*of\s*india.*identity/i,
    ],
    weights: [4, 4, 4, 3, 4, 2, 3, 2],
    threshold: 4,
  },
  {
    type: DOC_TYPES.PAN,
    patterns: [
      /permanent\s*account\s*number/i, /\bPAN\b/, /income\s*tax\s*department/i,
      /[A-Z]{5}\d{4}[A-Z]/, // PAN format
      /father['s]*\s*name/i,
    ],
    weights: [4, 3, 3, 4, 1],
    threshold: 4,
  },
  {
    type: DOC_TYPES.VOTER_ID,
    patterns: [
      /voter/i, /election\s*commission/i, /elector/i,
      /epic\s*no/i, /electoral\s*photo/i,
    ],
    weights: [3, 4, 3, 4, 4],
    threshold: 3,
  },
  {
    type: DOC_TYPES.DRIVING_LICENSE,
    patterns: [
      /driving\s*licen[sc]e/i, /transport\s*department/i,
      /\bDL\s*no/i, /licence\s*no/i, /vehicle\s*class/i,
      /\bcov\b/i, /motor\s*vehicle/i,
    ],
    weights: [4, 3, 3, 2, 3, 2, 2],
    threshold: 3,
  },
  {
    type: DOC_TYPES.TENTH_MARKSHEET,
    patterns: [
      /class\s*x\b/i, /10th/i, /secondary\s*school/i,
      /cbse|icse|state\s*board/i, /secondary\s*examination/i,
      /\bmarks?\s*sheet\b/i, /roll\s*no.*10/i,
    ],
    weights: [4, 3, 3, 2, 4, 2, 2],
    threshold: 3,
  },
  {
    type: DOC_TYPES.TWELFTH_MARKSHEET,
    patterns: [
      /class\s*xii\b/i, /12th/i, /higher\s*secondary/i,
      /senior\s*secondary/i, /intermediate/i,
      /cbse|icse|state\s*board/i, /\bmarks?\s*sheet\b/i,
    ],
    weights: [4, 3, 3, 3, 2, 2, 2],
    threshold: 3,
  },
  {
    type: DOC_TYPES.DEGREE_CERTIFICATE,
    patterns: [
      /degree\s*certificate/i, /bachelor\s*of/i, /master\s*of/i,
      /university\b/i, /convocation/i, /graduation/i,
      /doctor\s*of\s*philosophy|ph\.?d/i,
    ],
    weights: [4, 4, 4, 2, 3, 2, 4],
    threshold: 4,
  },
  {
    type: DOC_TYPES.MEDICAL_REPORT,
    patterns: [
      /laboratory\s*report/i, /blood\s*test/i, /haemoglobin|hemoglobin/i,
      /pathology/i, /radiology|x-ray|mri|ct\s*scan/i,
      /patient\s*name/i, /referring\s*doctor/i,
      /test\s*result/i, /normal\s*range/i,
    ],
    weights: [4, 4, 3, 3, 4, 2, 3, 3, 3],
    threshold: 4,
  },
  {
    type: DOC_TYPES.PRESCRIPTION,
    patterns: [
      /\bRx\b/, /prescription/i, /dr\.\s+[a-z]/i,
      /tablet|capsule|syrup/i, /mg\s*\/?\s*(day|od|bd|tds)/i,
      /diagnosis/i, /clinic|hospital/i,
    ],
    weights: [3, 4, 2, 3, 3, 3, 2],
    threshold: 4,
  },
  {
    type: DOC_TYPES.INSURANCE,
    patterns: [
      /insurance\s*policy/i, /policy\s*number/i, /sum\s*insured/i,
      /premium/i, /insured\s*name/i, /cover\s*note/i,
      /health\s*insurance|life\s*insurance|motor\s*insurance/i,
    ],
    weights: [4, 3, 4, 2, 2, 3, 3],
    threshold: 4,
  },
  {
    type: DOC_TYPES.BANK_STATEMENT,
    patterns: [
      /account\s*(no|number|statement)/i, /balance/i,
      /debit|credit/i, /transaction/i,
      /ifsc/i, /branch/i, /opening\s*balance|closing\s*balance/i,
    ],
    weights: [4, 2, 2, 2, 4, 1, 4],
    threshold: 5,
  },
  {
    type: DOC_TYPES.SALARY_SLIP,
    patterns: [
      /salary\s*slip|pay\s*slip|payslip/i, /basic\s*pay/i,
      /hra|house\s*rent\s*allowance/i, /pf\s*deduction|provident\s*fund/i,
      /gross\s*salary|net\s*salary/i, /employee\s*id/i,
    ],
    weights: [4, 3, 3, 4, 4, 2],
    threshold: 4,
  },
  {
    type: DOC_TYPES.ITR,
    patterns: [
      /income\s*tax\s*return/i, /assessment\s*year/i,
      /acknowledgement\s*number/i, /pan.*itr/i,
      /taxable\s*income/i, /itr[-\s]?\d/i,
    ],
    weights: [4, 3, 4, 3, 3, 4],
    threshold: 4,
  },
  {
    type: DOC_TYPES.ELECTRICITY_BILL,
    patterns: [
      /electricity\s*bill/i, /electric\s*supply/i, /power\s*corporation/i,
      /unit\s*consumed/i, /meter\s*no/i, /kwh/i,
      /mseb|bescom|tata\s*power|reliance\s*energy|bses/i,
    ],
    weights: [4, 3, 3, 4, 3, 3, 4],
    threshold: 4,
  },
  {
    type: DOC_TYPES.GAS_BILL,
    patterns: [
      /gas\s*bill/i, /lpg/i, /indane|hp\s*gas|bharatgas/i,
      /cylinder/i, /gas\s*connection/i,
    ],
    weights: [4, 3, 4, 3, 4],
    threshold: 4,
  },
  {
    type: DOC_TYPES.MOBILE_BILL,
    patterns: [
      /mobile\s*bill|phone\s*bill/i, /airtel|jio|vi\b|vodafone|bsnl/i,
      /data\s*usage/i, /outgoing\s*calls/i, /prepaid|postpaid/i,
    ],
    weights: [4, 4, 3, 3, 3],
    threshold: 4,
  },
  {
    type: DOC_TYPES.AMAZON_RECEIPT,
    patterns: [
      /amazon/i, /order\s*#|order\s*id/i,
      /shipped\s*to|delivery\s*address/i,
      /amazon\.in|amazon\.com/i,
    ],
    weights: [3, 2, 2, 4],
    threshold: 4,
  },
  {
    type: DOC_TYPES.RECEIPT,
    patterns: [
      /receipt/i, /invoice\s*no/i, /total\s*amount/i,
      /thank\s*you\s*for\s*(your\s*)?purchase/i,
      /gst\s*no|gstin/i,
    ],
    weights: [3, 3, 2, 3, 3],
    threshold: 4,
  },
  {
    type: DOC_TYPES.FLIGHT_TICKET,
    patterns: [
      /boarding\s*pass/i, /flight\s*no|flight\s*number/i,
      /pnr/i, /departure|arrival/i,
      /airline|airways/i, /seat\s*no/i,
      /indigo|air\s*india|spicejet|vistara/i,
    ],
    weights: [4, 4, 4, 2, 3, 3, 4],
    threshold: 4,
  },
  {
    type: DOC_TYPES.TRAIN_TICKET,
    patterns: [
      /indian\s*railway/i, /pnr\s*no/i, /train\s*no/i,
      /irctc/i, /berth|coach/i, /sleeper|ac\s*\d/i,
    ],
    weights: [4, 4, 3, 4, 3, 3],
    threshold: 4,
  },
  {
    type: DOC_TYPES.VEHICLE_RC,
    patterns: [
      /registration\s*certificate/i, /vehicle\s*registration/i,
      /chassis\s*no/i, /engine\s*no/i, /rto/i,
      /fuel\s*type|seating\s*capacity/i,
    ],
    weights: [4, 4, 4, 4, 3, 3],
    threshold: 4,
  },
]

/**
 * Classify a non-document media file (photo or video) that didn't match
 * any document pattern. Used when OCR found no confident document type.
 */
export function classifyMedia(kind) {
  const type = kind === 'video' ? DOC_TYPES.VIDEO : DOC_TYPES.PHOTO
  return {
    type,
    label: DOC_LABELS[type],
    category: DOC_CATEGORIES[type],
    confidence: 100, // We're certain it's a photo/video, just not a "document"
    tags: [type],
  }
}

/**
 * Classify a document based on extracted text
 * Returns { type, label, category, confidence, tags }
 */
export function classifyDocument(text) {
  if (!text || text.trim().length < 10) {
    return { type: DOC_TYPES.UNKNOWN, label: 'Unknown', category: 'Other', confidence: 0, tags: [] }
  }

  const normalizedText = text.toLowerCase()
  let bestMatch = null
  let bestScore = 0
  const allTags = new Set()

  for (const rule of RULES) {
    let score = 0
    for (let i = 0; i < rule.patterns.length; i++) {
      if (rule.patterns[i].test(normalizedText)) {
        score += rule.weights[i]
        allTags.add(rule.type)
      }
    }

    if (score >= rule.threshold && score > bestScore) {
      bestScore = score
      bestMatch = rule
    }
  }

  if (!bestMatch) {
    return {
      type: DOC_TYPES.UNKNOWN,
      label: DOC_LABELS[DOC_TYPES.UNKNOWN],
      category: DOC_CATEGORIES[DOC_TYPES.UNKNOWN],
      confidence: 0,
      tags: [],
    }
  }

  // Confidence: normalize score against a "perfect match" score
  const maxPossibleScore = bestMatch.weights.reduce((a, b) => a + b, 0)
  const confidence = Math.min(Math.round((bestScore / maxPossibleScore) * 100), 99)

  return {
    type: bestMatch.type,
    label: DOC_LABELS[bestMatch.type],
    category: DOC_CATEGORIES[bestMatch.type],
    confidence,
    tags: [...allTags],
  }
}

/**
 * Auto-suggest a clean filename based on classification and extracted text
 */
export function suggestFilename(classification, extractedText, originalName) {
  const { type } = classification
  const ext = originalName.split('.').pop() || 'pdf'

  // Try to extract a name/date from text
  const nameMatch = extractedText.match(/name[:\s]+([A-Z][a-z]+ [A-Z][a-z]+)/i)
  const yearMatch = extractedText.match(/\b(20\d{2}|19\d{2})\b/)
  const monthMatch = extractedText.match(/\b(january|february|march|april|may|june|july|august|september|october|november|december)\b/i)

  const name = nameMatch ? nameMatch[1].replace(/\s+/g, '_') : null
  const year = yearMatch ? yearMatch[1] : new Date().getFullYear()
  const month = monthMatch ? monthMatch[1].substring(0, 3).toUpperCase() : null

  const label = DOC_LABELS[type] || 'Document'
  const labelSlug = label.replace(/\s+/g, '_')

  let suggested = labelSlug
  if (name) suggested += `_${name}`
  if (month && year) suggested += `_${month}_${year}`
  else if (year) suggested += `_${year}`

  return `${suggested}.${ext}`
}

/**
 * Get the system labels that apply to a document type
 */
export function getSystemLabels(type) {
  const labelMap = {
    [DOC_TYPES.PASSPORT]: ['Government', 'Travel', 'Identity', 'Important'],
    [DOC_TYPES.AADHAAR]: ['Government', 'Identity', 'Important'],
    [DOC_TYPES.PAN]: ['Government', 'Identity', 'Financial', 'Important'],
    [DOC_TYPES.VOTER_ID]: ['Government', 'Identity'],
    [DOC_TYPES.DRIVING_LICENSE]: ['Government', 'Identity', 'Vehicle'],
    [DOC_TYPES.BIRTH_CERTIFICATE]: ['Government', 'Identity', 'Important'],
    [DOC_TYPES.TENTH_MARKSHEET]: ['Education', 'Certificates'],
    [DOC_TYPES.TWELFTH_MARKSHEET]: ['Education', 'Certificates'],
    [DOC_TYPES.DEGREE_CERTIFICATE]: ['Education', 'Certificates', 'Important'],
    [DOC_TYPES.COLLEGE_ID]: ['Education', 'Identity'],
    [DOC_TYPES.MEDICAL_REPORT]: ['Medical', 'Health'],
    [DOC_TYPES.PRESCRIPTION]: ['Medical', 'Health'],
    [DOC_TYPES.INSURANCE]: ['Financial', 'Insurance', 'Important'],
    [DOC_TYPES.BANK_STATEMENT]: ['Financial', 'Banking'],
    [DOC_TYPES.SALARY_SLIP]: ['Financial', 'Income'],
    [DOC_TYPES.ITR]: ['Financial', 'Tax', 'Important'],
    [DOC_TYPES.GST_INVOICE]: ['Financial', 'Bills'],
    [DOC_TYPES.ELECTRICITY_BILL]: ['Bills', 'Utilities'],
    [DOC_TYPES.GAS_BILL]: ['Bills', 'Utilities'],
    [DOC_TYPES.WATER_BILL]: ['Bills', 'Utilities'],
    [DOC_TYPES.MOBILE_BILL]: ['Bills', 'Telecom'],
    [DOC_TYPES.RECEIPT]: ['Shopping', 'Receipts'],
    [DOC_TYPES.AMAZON_RECEIPT]: ['Shopping', 'Receipts', 'Amazon'],
    [DOC_TYPES.FLIGHT_TICKET]: ['Travel', 'Tickets'],
    [DOC_TYPES.TRAIN_TICKET]: ['Travel', 'Tickets'],
    [DOC_TYPES.BUS_TICKET]: ['Travel', 'Tickets'],
    [DOC_TYPES.HOTEL_BOOKING]: ['Travel', 'Bookings'],
    [DOC_TYPES.VEHICLE_RC]: ['Vehicle', 'Government'],
    [DOC_TYPES.PROPERTY_DOCUMENT]: ['Property', 'Important'],
    [DOC_TYPES.PHOTO]: ['Photos'],
    [DOC_TYPES.VIDEO]: ['Videos'],
    [DOC_TYPES.UNKNOWN]: ['Other'],
  }
  return labelMap[type] || ['Other']
}
