/**
 * SPARPLE Search Service
 * Hybrid search: FTS5 for fast exact/prefix matches, Fuse.js fuzzy fallback
 * for typos, partial words, and vague phrasing.
 */

import Fuse from 'fuse.js'
import { searchDocuments as ftsSearch, getDocuments } from './database.js'

// Fuse config tuned for document search:
// - name and label are weighted higher than raw extracted text
// - threshold 0.4 allows moderate typos/fuzziness without matching garbage
const FUSE_OPTIONS = {
  keys: [
    { name: 'name', weight: 0.35 },
    { name: 'label', weight: 0.25 },
    { name: 'category', weight: 0.15 },
    { name: 'extracted_text', weight: 0.25 },
  ],
  threshold: 0.4,
  distance: 100,
  ignoreLocation: true,
  minMatchCharLength: 2,
  includeScore: true,
}

let fuseIndex = null
let fuseIndexSize = 0

/**
 * Build (or rebuild) the in-memory fuzzy search index.
 * Called after a scan completes, or lazily on first vague search.
 */
export function buildFuseIndex() {
  const allDocs = getDocuments({ limit: 5000 })
  fuseIndex = new Fuse(allDocs, FUSE_OPTIONS)
  fuseIndexSize = allDocs.length
  return fuseIndex
}

function ensureFuseIndex() {
  if (!fuseIndex) {
    buildFuseIndex()
  }
  return fuseIndex
}

/**
 * The main search entry point. Combines exact FTS5 results with
 * fuzzy Fuse.js results so vague queries, typos, and partial phrases
 * still surface something useful.
 */
export function search(query, limit = 50) {
  const trimmed = query.trim()
  if (!trimmed) return getDocuments({ limit })

  // Pass 1 — fast exact/prefix match via SQLite FTS5
  let exactResults = []
  try {
    exactResults = ftsSearch(trimmed, limit)
  } catch {
    exactResults = []
  }

  // Pass 2 — fuzzy match via Fuse.js, always run to catch vague queries,
  // typos, and synonyms that FTS would miss entirely
  const fuse = ensureFuseIndex()
  const fuzzyRaw = fuse.search(trimmed, { limit: limit * 2 })

  // Merge: exact matches first (they're more precise), then fuzzy matches
  // that weren't already found, deduplicated by document id
  const seenIds = new Set(exactResults.map(d => d.id))
  const fuzzyResults = fuzzyRaw
    .filter(r => !seenIds.has(r.item.id))
    .map(r => ({ ...r.item, _fuzzyScore: r.score }))

  const merged = [...exactResults, ...fuzzyResults].slice(0, limit)

  return merged
}

/**
 * Call this after every scan completes so the fuzzy index stays current.
 */
export function refreshSearchIndex() {
  buildFuseIndex()
}

export function getIndexSize() {
  return fuseIndexSize
}
