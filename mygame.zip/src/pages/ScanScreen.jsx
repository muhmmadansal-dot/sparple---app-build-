import React, { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { Scanner } from '../services/scanner.js'
import { useAppContext } from '../hooks/useAppContext.jsx'
import styles from './ScanScreen.module.css'

const PHASES = {
  idle: 'idle',
  permission: 'permission',
  scanning: 'scanning',
  complete: 'complete',
  error: 'error',
}

export default function ScanScreen() {
  const navigate = useNavigate()
  const { refreshStats, markScanned } = useAppContext()
  const [phase, setPhase] = useState(PHASES.idle)
  const [progress, setProgress] = useState(0)
  const [message, setMessage] = useState('')
  const [currentFile, setCurrentFile] = useState('')
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const scannerRef = useRef(null)

  const startScan = async () => {
    setPhase(PHASES.scanning)

    const scanner = new Scanner((prog) => {
      setProgress(prog.progress || 0)
      setMessage(prog.message || '')
      setCurrentFile(prog.current || '')

      if (prog.phase === 'complete') {
        setResult(prog)
        setPhase(PHASES.complete)
        refreshStats()
        markScanned()
      }
    })

    scannerRef.current = scanner

    try {
      await scanner.scan()
    } catch (err) {
      setError(err.message)
      setPhase(PHASES.error)
    }
  }

  const handleDone = () => {
    navigate('/', { replace: true })
  }

  return (
    <div className={styles.screen}>
      {/* Back button */}
      {phase !== PHASES.scanning && (
        <motion.button
          className={styles.backBtn}
          onClick={() => navigate(-1)}
          whileTap={{ scale: 0.9 }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <path d="M15 18L9 12L15 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </motion.button>
      )}

      <AnimatePresence mode="wait">
        {phase === PHASES.idle && <IdleState key="idle" onStart={startScan} />}
        {phase === PHASES.scanning && (
          <ScanningState
            key="scanning"
            progress={progress}
            message={message}
            currentFile={currentFile}
          />
        )}
        {phase === PHASES.complete && <CompleteState key="complete" result={result} onDone={handleDone} />}
        {phase === PHASES.error && <ErrorState key="error" error={error} onRetry={startScan} />}
      </AnimatePresence>
    </div>
  )
}

function IdleState({ onStart }) {
  return (
    <motion.div
      className={styles.centered}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.4 }}
    >
      {/* Animated scan icon */}
      <div className={styles.scanVisual}>
        <motion.div
          className={styles.scanRing}
          animate={{ scale: [1, 1.15, 1], opacity: [0.4, 0.1, 0.4] }}
          transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
        />
        <motion.div
          className={styles.scanRing}
          animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0.05, 0.3] }}
          transition={{ duration: 2.5, repeat: Infinity, delay: 0.4, ease: 'easeInOut' }}
        />
        <div className={styles.scanIcon}>
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none">
            <path d="M3 7V5C3 3.9 3.9 3 5 3H7" stroke="white" strokeWidth="2" strokeLinecap="round" />
            <path d="M17 3H19C20.1 3 21 3.9 21 5V7" stroke="white" strokeWidth="2" strokeLinecap="round" />
            <path d="M21 17V19C21 20.1 20.1 21 19 21H17" stroke="white" strokeWidth="2" strokeLinecap="round" />
            <path d="M7 21H5C3.9 21 3 20.1 3 19V17" stroke="white" strokeWidth="2" strokeLinecap="round" />
            <path d="M3 12H21" stroke="white" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </div>
      </div>

      <h1 className={styles.title}>Scan Your Phone</h1>
      <p className={styles.desc}>
        Sparple will scan your Downloads, Documents, and Images.
        Everything stays on your device. Nothing leaves.
      </p>

      <div className={styles.privacyChips}>
        {['🔒 100% Private', '📡 No Internet', '⚡ Instant Search'].map((chip) => (
          <span key={chip} className={styles.chip}>{chip}</span>
        ))}
      </div>

      <motion.button
        className={styles.startBtn}
        onClick={onStart}
        whileTap={{ scale: 0.96 }}
        animate={{
          boxShadow: [
            '0 8px 32px rgba(124,111,255,0.3)',
            '0 8px 48px rgba(124,111,255,0.55)',
            '0 8px 32px rgba(124,111,255,0.3)',
          ]
        }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        Start Scanning
      </motion.button>
    </motion.div>
  )
}

function ScanningState({ progress, message, currentFile }) {
  return (
    <motion.div
      className={styles.centered}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      {/* Animated scanner visual */}
      <div className={styles.scannerVisual}>
        {/* Folder icons floating */}
        {['📄', '🖼️', '📋', '🗂️', '📊'].map((icon, i) => (
          <motion.div
            key={i}
            className={styles.floatingFile}
            style={{
              left: `${15 + i * 16}%`,
              top: `${20 + (i % 2) * 30}%`,
            }}
            animate={{
              y: [0, -8, 0],
              opacity: [0.4, 0.8, 0.4],
              scale: [0.9, 1.05, 0.9],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              delay: i * 0.3,
              ease: 'easeInOut',
            }}
          >
            {icon}
          </motion.div>
        ))}

        {/* Center vault icon */}
        <div className={styles.vaultCenter}>
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 4, repeat: Infinity, ease: 'linear' }}
            style={{ position: 'absolute' }}
          >
            <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
              <circle cx="40" cy="40" r="38" stroke="url(#scan-ring-grad)" strokeWidth="1.5" strokeDasharray="4 6" />
              <defs>
                <linearGradient id="scan-ring-grad" x1="0" y1="0" x2="80" y2="80">
                  <stop offset="0%" stopColor="#7C6FFF" />
                  <stop offset="100%" stopColor="#A855F7" />
                </linearGradient>
              </defs>
            </svg>
          </motion.div>
          <div className={styles.vaultIcon}>
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
              <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
              <path d="M2 17L12 22L22 17" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
              <path d="M2 12L12 17L22 12" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
            </svg>
          </div>
        </div>
      </div>

      {/* Progress */}
      <div className={styles.progressSection}>
        <div className={styles.progressHeader}>
          <span className={styles.progressLabel}>{message}</span>
          <span className={styles.progressPct}>{progress}%</span>
        </div>
        <div className={styles.progressTrack}>
          <motion.div
            className={styles.progressFill}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
          />
          <motion.div
            className={styles.progressGlow}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
          />
        </div>
        {currentFile && (
          <p className={styles.currentFile} title={currentFile}>
            {currentFile.split('/').pop()}
          </p>
        )}
      </div>

      <p className={styles.privacyNote}>Your files never leave your device</p>
    </motion.div>
  )
}

function CompleteState({ result, onDone }) {
  return (
    <motion.div
      className={styles.centered}
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, ease: [0.34, 1.56, 0.64, 1] }}
    >
      <motion.div
        className={styles.successIcon}
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.2, duration: 0.5, ease: [0.34, 1.56, 0.64, 1] }}
      >
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none">
          <motion.path
            d="M5 12L10 17L19 8"
            stroke="white"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ delay: 0.4, duration: 0.6 }}
          />
        </svg>
      </motion.div>

      <h2 className={styles.title}>All Done!</h2>
      <p className={styles.desc}>
        Found and indexed {result?.newFiles || 0} new documents
        in {Math.round((result?.durationMs || 0) / 1000)}s
      </p>

      <div className={styles.resultStats}>
        <ResultStat value={result?.totalFiles || 0} label="Files scanned" />
        <ResultStat value={result?.newFiles || 0} label="New documents" accent />
      </div>

      <motion.button
        className={styles.startBtn}
        onClick={onDone}
        whileTap={{ scale: 0.96 }}
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
      >
        View My Vault
      </motion.button>
    </motion.div>
  )
}

function ErrorState({ error, onRetry }) {
  return (
    <motion.div
      className={styles.centered}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <div className={styles.errorIcon}>
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="10" stroke="var(--status-error)" strokeWidth="1.8" />
          <path d="M12 8V12M12 16H12.01" stroke="var(--status-error)" strokeWidth="2" strokeLinecap="round" />
        </svg>
      </div>
      <h2 className={styles.title}>Scan Failed</h2>
      <p className={styles.desc}>{error || 'Something went wrong. Make sure storage permission is granted.'}</p>
      <button className={styles.startBtn} onClick={onRetry}>Try Again</button>
    </motion.div>
  )
}

function ResultStat({ value, label, accent }) {
  return (
    <div className={styles.resultStat}>
      <span className={styles.resultValue} style={accent ? { background: 'var(--gradient-accent)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' } : {}}>
        {value}
      </span>
      <span className={styles.resultLabel}>{label}</span>
    </div>
  )
}
