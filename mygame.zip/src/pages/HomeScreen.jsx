import React, { useEffect, useState, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { useAppContext } from '../hooks/useAppContext.jsx'
import { getDocuments, searchDocuments } from '../services/database.js'
import DocumentCard from '../components/DocumentCard.jsx'
import styles from './HomeScreen.module.css'

const CATEGORY_ICONS = {
  Government: '🏛️',
  Education: '🎓',
  Medical: '💊',
  Financial: '💰',
  Travel: '✈️',
  Bills: '⚡',
  Shopping: '🛍️',
  Photos: '🖼️',
  Videos: '🎬',
  Vehicle: '🚗',
  Property: '🏠',
  Other: '📁',
}

const CATEGORY_COLORS = {
  Government: 'var(--doc-government)',
  Education: 'var(--doc-education)',
  Medical: 'var(--doc-medical)',
  Financial: 'var(--doc-financial)',
  Travel: 'var(--doc-travel)',
  Bills: 'var(--doc-identity)',
  Shopping: '#FB923C',
  Photos: '#FB7185',
  Videos: '#22D3EE',
  Vehicle: 'var(--doc-other)',
  Property: '#86EFAC',
  Other: 'var(--doc-other)',
}

export default function HomeScreen() {
  const navigate = useNavigate()
  const { stats, categoryCounts, hasScanned, dbReady } = useAppContext()
  const [recentDocs, setRecentDocs] = useState([])
  const [reviewDocs, setReviewDocs] = useState([])
  const [greeting, setGreeting] = useState('')

  useEffect(() => {
    const h = new Date().getHours()
    if (h < 12) setGreeting('Good morning')
    else if (h < 17) setGreeting('Good afternoon')
    else setGreeting('Good evening')
  }, [])

  useEffect(() => {
    if (!dbReady) return
    setRecentDocs(getDocuments({ limit: 8 }))
    setReviewDocs(getDocuments({ needsReview: true, limit: 3 }))
  }, [dbReady, stats.total])

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.06, delayChildren: 0.1 }
    }
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 16 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: [0.4, 0, 0.2, 1] } }
  }

  return (
    <div className={styles.screen}>
      <div className={styles.scroll}>
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* Header */}
          <motion.div variants={itemVariants} className={styles.header}>
            <div>
              <p className={styles.greeting}>{greeting}</p>
              <h1 className={styles.title}>Your Vault</h1>
            </div>
            <motion.button
              className={styles.notifBtn}
              whileTap={{ scale: 0.9 }}
              onClick={() => navigate('/library')}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path d="M12 3C8.7 3 6 5.7 6 9V14L4 16V17H20V16L18 14V9C18 5.7 15.3 3 12 3Z"
                  stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
                <path d="M10 17C10 18.1 10.9 19 12 19C13.1 19 14 18.1 14 17"
                  stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
              </svg>
              {stats.needs_review > 0 && (
                <span className={styles.badge}>{stats.needs_review}</span>
              )}
            </motion.button>
          </motion.div>

          {/* Stats row */}
          <motion.div variants={itemVariants} className={styles.statsRow}>
            <StatCard value={stats.total} label="Documents" accent />
            <StatCard value={stats.categories} label="Categories" />
            <StatCard value={stats.needs_review} label="To Review" warn={stats.needs_review > 0} />
          </motion.div>

          {/* Search bar */}
          <motion.div variants={itemVariants}>
            <motion.button
              className={styles.searchBar}
              onClick={() => navigate('/search')}
              whileTap={{ scale: 0.98 }}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                <circle cx="10.5" cy="10.5" r="6.5" stroke="var(--text-tertiary)" strokeWidth="1.8" />
                <path d="M15.5 15.5L20 20" stroke="var(--text-tertiary)" strokeWidth="1.8" strokeLinecap="round" />
              </svg>
              <span className={styles.searchPlaceholder}>Search your documents…</span>
              <kbd className={styles.searchKbd}>⌘K</kbd>
            </motion.button>
          </motion.div>

          {/* No documents state */}
          {!hasScanned && (
            <motion.div variants={itemVariants} className={styles.emptyState}>
              <div className={styles.emptyIcon}>
                <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
                  <circle cx="20" cy="20" r="19" stroke="var(--glass-border)" strokeWidth="1.5" />
                  <path d="M12 14H28M12 20H22M12 26H18" stroke="var(--accent-primary)"
                    strokeWidth="2" strokeLinecap="round" />
                </svg>
              </div>
              <h3 className={styles.emptyTitle}>No documents yet</h3>
              <p className={styles.emptyDesc}>Scan your phone to find and organize all your documents instantly.</p>
              <motion.button
                className={styles.scanCta}
                onClick={() => navigate('/scan')}
                whileTap={{ scale: 0.96 }}
                animate={{ boxShadow: ['0 4px 20px rgba(124,111,255,0.3)', '0 4px 30px rgba(124,111,255,0.5)', '0 4px 20px rgba(124,111,255,0.3)'] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                  <path d="M3 7V5C3 3.9 3.9 3 5 3H7" stroke="white" strokeWidth="2" strokeLinecap="round" />
                  <path d="M17 3H19C20.1 3 21 3.9 21 5V7" stroke="white" strokeWidth="2" strokeLinecap="round" />
                  <path d="M21 17V19C21 20.1 20.1 21 19 21H17" stroke="white" strokeWidth="2" strokeLinecap="round" />
                  <path d="M7 21H5C3.9 21 3 20.1 3 19V17" stroke="white" strokeWidth="2" strokeLinecap="round" />
                  <path d="M3 12H21" stroke="white" strokeWidth="2" strokeLinecap="round" />
                </svg>
                Start Scanning
              </motion.button>
            </motion.div>
          )}

          {/* Needs review */}
          {reviewDocs.length > 0 && (
            <motion.div variants={itemVariants} className={styles.section}>
              <div className={styles.sectionHeader}>
                <span className={styles.reviewBadge}>⚠️ Needs Review</span>
                <button className={styles.seeAll} onClick={() => navigate('/library?filter=review')}>
                  See all
                </button>
              </div>
              <div className={styles.reviewList}>
                {reviewDocs.map((doc, i) => (
                  <ReviewCard key={doc.id} doc={doc} index={i} />
                ))}
              </div>
            </motion.div>
          )}

          {/* Categories */}
          {categoryCounts.length > 0 && (
            <motion.div variants={itemVariants} className={styles.section}>
              <div className={styles.sectionHeader}>
                <span className={styles.sectionTitle}>Categories</span>
                <button className={styles.seeAll} onClick={() => navigate('/library')}>
                  See all
                </button>
              </div>
              <div className={styles.categoryGrid}>
                {categoryCounts.slice(0, 6).map((cat, i) => (
                  <motion.button
                    key={cat.category}
                    className={styles.categoryCard}
                    onClick={() => navigate(`/library?category=${cat.category}`)}
                    whileTap={{ scale: 0.94 }}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: i * 0.05, duration: 0.3 }}
                    style={{ '--cat-color': CATEGORY_COLORS[cat.category] || 'var(--accent-primary)' }}
                  >
                    <span className={styles.catIcon}>{CATEGORY_ICONS[cat.category] || '📁'}</span>
                    <span className={styles.catName}>{cat.category}</span>
                    <span className={styles.catCount}>{cat.count}</span>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}

          {/* Recent documents */}
          {recentDocs.length > 0 && (
            <motion.div variants={itemVariants} className={styles.section}>
              <div className={styles.sectionHeader}>
                <span className={styles.sectionTitle}>Recent</span>
                <button className={styles.seeAll} onClick={() => navigate('/library')}>
                  See all
                </button>
              </div>
              <div className={styles.docList}>
                {recentDocs.map((doc, i) => (
                  <DocumentCard key={doc.id} doc={doc} index={i} />
                ))}
              </div>
            </motion.div>
          )}

          <div style={{ height: 32 }} />
        </motion.div>
      </div>
    </div>
  )
}

function StatCard({ value, label, accent, warn }) {
  return (
    <motion.div
      className={styles.statCard}
      whileTap={{ scale: 0.95 }}
      style={accent ? { background: 'var(--gradient-accent-soft)', borderColor: 'rgba(124,111,255,0.2)' } : {}}
    >
      <span className={styles.statValue} style={warn ? { color: 'var(--status-warning)' } : accent ? { background: 'var(--gradient-accent)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' } : {}}>
        {value}
      </span>
      <span className={styles.statLabel}>{label}</span>
    </motion.div>
  )
}

function ReviewCard({ doc, index }) {
  const navigate = useNavigate()
  return (
    <motion.button
      className={styles.reviewCard}
      onClick={() => navigate(`/document/${doc.id}`)}
      whileTap={{ scale: 0.97 }}
      initial={{ opacity: 0, x: -16 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.06 }}
    >
      <div className={styles.reviewCardIcon}>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
          <path d="M14 2H6C4.9 2 4 2.9 4 4V20C4 21.1 4.9 22 6 22H18C19.1 22 20 21.1 20 20V8L14 2Z"
            stroke="var(--status-warning)" strokeWidth="1.8" strokeLinecap="round" />
          <path d="M14 2V8H20" stroke="var(--status-warning)" strokeWidth="1.8" strokeLinecap="round" />
          <path d="M12 11V13M12 15H12.01" stroke="var(--status-warning)" strokeWidth="2" strokeLinecap="round" />
        </svg>
      </div>
      <div className={styles.reviewCardText}>
        <span className={styles.reviewCardName}>{doc.name}</span>
        <span className={styles.reviewCardSub}>Tap to identify</span>
      </div>
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
        <path d="M9 18L15 12L9 6" stroke="var(--text-tertiary)" strokeWidth="2" strokeLinecap="round" />
      </svg>
    </motion.button>
  )
}
