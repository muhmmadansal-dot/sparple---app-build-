import React, { useState, useEffect } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { motion } from 'framer-motion'
import { getDocuments, getLabels } from '../services/database.js'
import DocumentCard from '../components/DocumentCard.jsx'
import styles from './LibraryScreen.module.css'

const CATEGORIES = ['All','Government','Education','Medical','Financial','Travel','Bills','Shopping','Photos','Videos','Vehicle','Property','Other']

export default function LibraryScreen() {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const initCat = searchParams.get('category') || 'All'
  const initFilter = searchParams.get('filter')

  const [activeCategory, setActiveCategory] = useState(initCat)
  const [activeLabel, setActiveLabel] = useState(null)
  const [docs, setDocs] = useState([])
  const [labels, setLabels] = useState([])
  const [showReviewOnly, setShowReviewOnly] = useState(initFilter === 'review')
  const [showStarred, setShowStarred] = useState(false)

  useEffect(() => {
    setLabels(getLabels())
  }, [])

  useEffect(() => {
    const opts = { limit: 100 }
    if (activeCategory !== 'All') opts.category = activeCategory
    if (activeLabel) opts.label = activeLabel
    if (showReviewOnly) opts.needsReview = true
    if (showStarred) opts.starred = true
    setDocs(getDocuments(opts))
  }, [activeCategory, activeLabel, showReviewOnly, showStarred])

  return (
    <div className={styles.screen}>
      <div className={styles.header}>
        <h1 className={styles.title}>Library</h1>
        <div className={styles.filterRow}>
          <button
            className={`${styles.filterBtn} ${showStarred ? styles.filterBtnActive : ''}`}
            onClick={() => { setShowStarred(!showStarred); setShowReviewOnly(false) }}
          >⭐ Starred</button>
          <button
            className={`${styles.filterBtn} ${showReviewOnly ? styles.filterBtnActive : ''}`}
            onClick={() => { setShowReviewOnly(!showReviewOnly); setShowStarred(false) }}
          >⚠️ Review</button>
        </div>
      </div>

      {/* Category tabs */}
      <div className={styles.tabsWrap}>
        <div className={styles.tabs}>
          {CATEGORIES.map(cat => (
            <motion.button
              key={cat}
              className={`${styles.tab} ${activeCategory === cat ? styles.tabActive : ''}`}
              onClick={() => { setActiveCategory(cat); setActiveLabel(null) }}
              whileTap={{ scale: 0.92 }}
            >
              {cat}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Label chips */}
      <div className={styles.labelsWrap}>
        <div className={styles.labels}>
          <button
            className={`${styles.labelBtn} ${!activeLabel ? styles.labelBtnActive : ''}`}
            onClick={() => setActiveLabel(null)}
          >All</button>
          {labels.map(l => (
            <button
              key={l.name}
              className={`${styles.labelBtn} ${activeLabel === l.name ? styles.labelBtnActive : ''}`}
              style={activeLabel === l.name ? { borderColor: l.color, color: l.color } : {}}
              onClick={() => setActiveLabel(activeLabel === l.name ? null : l.name)}
            >
              {l.name}
              {l.doc_count > 0 && <span className={styles.labelCount}>{l.doc_count}</span>}
            </button>
          ))}
        </div>
      </div>

      {/* Results */}
      <div className={styles.scroll}>
        {docs.length === 0 ? (
          <div className={styles.empty}>
            <span style={{ fontSize: 40 }}>📂</span>
            <p className={styles.emptyTitle}>No documents here</p>
            <p className={styles.emptyDesc}>Scan your phone to find documents.</p>
            <button className={styles.scanBtn} onClick={() => navigate('/scan')}>Scan Now</button>
          </div>
        ) : (
          <motion.div
            className={styles.list}
            initial="hidden"
            animate="visible"
            variants={{ visible: { transition: { staggerChildren: 0.04 } } }}
          >
            <p className={styles.resultCount}>{docs.length} document{docs.length !== 1 ? 's' : ''}</p>
            {docs.map((doc, i) => (
              <DocumentCard key={doc.id} doc={doc} index={i} />
            ))}
            <div style={{ height: 24 }} />
          </motion.div>
        )}
      </div>
    </div>
  )
}
