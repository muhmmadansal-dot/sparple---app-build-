/**
 * Copies onnxruntime-web WASM binaries into public/ at build time.
 *
 * Why this needs to be careful:
 * @xenova/transformers ships its OWN pinned copy of onnxruntime-web nested
 * inside its own node_modules (node_modules/@xenova/transformers/node_modules/
 * onnxruntime-web), which can be a DIFFERENT version than whatever
 * onnxruntime-web ends up hoisted to the top-level node_modules/onnxruntime-web.
 *
 * If we copy the wrong version's .wasm files, the filenames or internal
 * expectations won't match what @xenova/transformers actually requests at
 * runtime, and you get:
 *   "both async and sync fetching of the wasm failed"
 * ...with ZERO indication of why, because this script used to just warn
 * and exit 0 even when it found nothing useful.
 *
 * This version:
 *   1. Prefers the nested @xenova/transformers copy of onnxruntime-web
 *      (that's the one whose code paths actually run).
 *   2. Falls back to the top-level onnxruntime-web if the nested one
 *      isn't there for some reason.
 *   3. HARD FAILS the build (non-zero exit) if no .wasm files are found
 *      anywhere, instead of silently shipping a broken APK.
 */
import { copyFileSync, existsSync, mkdirSync, readdirSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'

const __dirname = dirname(fileURLToPath(import.meta.url))
const root = join(__dirname, '..')
const destDir = join(root, 'public')

if (!existsSync(destDir)) mkdirSync(destDir, { recursive: true })

const candidates = [
  join(root, 'node_modules', '@xenova', 'transformers', 'node_modules', 'onnxruntime-web', 'dist'),
  join(root, 'node_modules', 'onnxruntime-web', 'dist'),
]

const ortDist = candidates.find(existsSync)

if (!ortDist) {
  console.error('[Sparple] FATAL: could not find onnxruntime-web/dist in either:')
  candidates.forEach(c => console.error('  - ' + c))
  console.error('[Sparple] Run `npm install` first. Aborting build — shipping without')
  console.error('           these files means semantic search will be broken in the APK.')
  process.exit(1)
}

console.log(`[Sparple] Using onnxruntime-web dist: ${ortDist}`)

// Copy every .wasm file. We keep ALL variants (not just non-threaded) because
// which one gets requested depends on runtime SharedArrayBuffer detection —
// better to have all of them present than guess wrong and 404.
const wasmFiles = readdirSync(ortDist).filter(f => f.endsWith('.wasm'))

if (wasmFiles.length === 0) {
  console.error(`[Sparple] FATAL: ${ortDist} exists but contains no .wasm files.`)
  console.error('[Sparple] onnxruntime-web may have changed its dist layout. Aborting build.')
  process.exit(1)
}

for (const file of wasmFiles) {
  copyFileSync(join(ortDist, file), join(destDir, file))
  console.log(`[Sparple] Copied ${file} -> public/${file}`)
}

// Also copy the .mjs/.js companion files some builds need alongside the wasm.
const companionExtensions = ['.mjs', '.js']
const companions = readdirSync(ortDist).filter(f =>
  companionExtensions.some(ext => f.endsWith(ext)) && f.includes('ort-wasm')
)
for (const file of companions) {
  copyFileSync(join(ortDist, file), join(destDir, file))
  console.log(`[Sparple] Copied ${file} -> public/${file}`)
}

// Also copy the main ort shim JS (some Transformers.js builds look for it).
for (const shim of ['ort.min.js', 'ort.js', 'ort.min.mjs', 'ort.mjs']) {
  const src = join(ortDist, shim)
  if (existsSync(src)) {
    copyFileSync(src, join(destDir, shim))
    console.log(`[Sparple] Copied ${shim} -> public/${shim}`)
  }
}

console.log(`[Sparple] ONNX WASM copy complete: ${wasmFiles.length} wasm file(s) copied.`)
