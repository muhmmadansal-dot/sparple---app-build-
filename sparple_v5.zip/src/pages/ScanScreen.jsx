import React, { useState, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { Filesystem } from '@capacitor/filesystem'
import { Scanner } from '../services/scanner.js'
import { useAppContext } from '../hooks/useAppContext.jsx'
import styles from './ScanScreen.module.css'

// All phases this screen can be in
// idle → (request perms) → permDenied | downloading → scanning → complete | error
const PHASE = {
  idle: 'idle',
  permDenied: 'permDenied',
  downloading: 'downloading',   // model download progress
  scanning: 'scanning',
  complete: 'complete',
  error: 'error',
}

export default function ScanScreen() {
  const navigate = useNavigate()
  const { refreshStats, markScanned } = useAppContext()
  const [phase, setPhase] = useState(PHASE.idle)
  const [modelProgress, setModelProgress] = useState({ pct: 0, label: 'Preparing AI search engine…' })
  const [scanProgress, setScanProgress] = useState(0)
  const [scanMessage, setScanMessage] = useState('')
  const [scanFile, setScanFile] = useState('')
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const scannerRef = useRef(null)

  // ─── Step 1: request runtime permissions ────────────────────────────────────
  const requestPermissionsAndProceed = async () => {
    try {
      // Capacitor Filesystem.requestPermissions() triggers the system dialog
      const status = await Filesystem.requestPermissions()

      // 'granted' or 'denied'. On Android <13 it's always 'granted' if manifest is correct.
      const ok = status?.publicStorage === 'granted' || status?.publicStorage === 'prompt'
      if (!ok) {
        setPhase(PHASE.permDenied)
        return
      }
    } catch (err) {
      // Emulator / desktop web — no native permission needed, proceed anyway
      console.warn('[ScanScreen] Permissions API not available (web?):', err.message)
    }

    // Permissions OK → start model download
    startModelThenScan()
  }

  // ─── Step 2: download model, then scan ──────────────────────────────────────
  const startModelThenScan = async () => {
    setPhase(PHASE.downloading)
    setModelProgress({ pct: 0, label: 'Starting download…' })

    const scanner = new Scanner((prog) => {
      if (prog.phase === 'model') {
        setModelProgress({
          pct: prog.progress || 0,
          label: prog.message || 'Downloading AI search model…',
        })
      } else if (prog.phase === 'discovering') {
        // Transition to scanning UI once model is done and we start walking dirs
        setPhase(PHASE.scanning)
        setScanMessage(prog.message || '')
        setScanProgress(0)
      } else if (prog.phase === 'scanning') {
        setScanProgress(prog.progress || 0)
        setScanMessage(prog.message || '')
        setScanFile(prog.current || '')
      } else if (prog.phase === 'complete') {
        setResult(prog)
        setPhase(PHASE.complete)
        refreshStats()
        markScanned()
      }
    })

    scannerRef.current = scanner

    try {
      await scanner.scan()
    } catch (err) {
      console.error('[ScanScreen] scan() threw:', err)
      const detail = [
        err?.name && `${err.name}: ${err.message}`,
        err?.cause && `Cause: ${err.cause.message || err.cause}`,
        err?.stack,
      ].filter(Boolean).join('\n')
      setError(detail || 'Unknown error. Check storage permission.')
      setPhase(PHASE.error)
    }
  }

  const handleDone = () => navigate('/', { replace: true })

  return (
    <div className={styles.screen}>
      {/* Back button — hidden while scanning / downloading */}
      {phase !== PHASE.scanning && phase !== PHASE.downloading && (
        <motion.button
          className={styles.backBtn}
          onClick={() => navigate(-1)}
          whileTap={{ scale: 0.9 }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <path d="M15 18L9 12L15 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </motion.button>
      )}

      <AnimatePresence mode="wait">
        {phase === PHASE.idle && (
          <IdleState key="idle" onStart={requestPermissionsAndProceed} />
        )}
        {phase === PHASE.permDenied && (
          <PermDeniedState key="permDenied" onRetry={requestPermissionsAndProceed} />
        )}
        {phase === PHASE.downloading && (
          <DownloadingState key="downloading" pct={modelProgress.pct} label={modelProgress.label} />
        )}
        {phase === PHASE.scanning && (
          <ScanningState
            key="scanning"
            progress={scanProgress}
            message={scanMessage}
            currentFile={scanFile}
          />
        )}
        {phase === PHASE.complete && (
          <CompleteState key="complete" result={result} onDone={handleDone} />
        )}
        {phase === PHASE.error && (
          <ErrorState key="error" error={error} onRetry={requestPermissionsAndProceed} />
        )}
      </AnimatePresence>
    </div>
  )
}

// ─── Idle ─────────────────────────────────────────────────────────────────────
function IdleState({ onStart }) {
  return (
    <motion.div
      className={styles.centered}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.4 }}
    >
      <div className={styles.scanVisual}>
        <motion.div
          className={styles.scanRing}
          animate={{ scale: [1, 1.15, 1], opacity: [0.4, 0.1, 0.4] }}
          transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
        />
        <motion.div
          className={styles.scanRing}
          animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0.05, 0.3] }}
          transition={{ duration: 2.5, repeat: Infinity, delay: 0.4, ease: 'easeInOut' }}
        />
        <div className={styles.scanIcon}>
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none">
            <path d="M3 7V5C3 3.9 3.9 3 5 3H7" stroke="white" strokeWidth="2" strokeLinecap="round" />
            <path d="M17 3H19C20.1 3 21 3.9 21 5V7" stroke="white" strokeWidth="2" strokeLinecap="round" />
            <path d="M21 17V19C21 20.1 20.1 21 19 21H17" stroke="white" strokeWidth="2" strokeLinecap="round" />
            <path d="M7 21H5C3.9 21 3 20.1 3 19V17" stroke="white" strokeWidth="2" strokeLinecap="round" />
            <path d="M3 12H21" stroke="white" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </div>
      </div>

      <h1 className={styles.title}>Scan Your Phone</h1>
      <p className={styles.desc}>
        Sparple scans Downloads, Documents, and Screenshots —
        not your whole camera roll. Everything stays on your device.
      </p>

      <div className={styles.infoBox}>
        <p className={styles.infoRow}>📂 Downloads · Documents · Screenshots</p>
        <p className={styles.infoRow}>🧠 On-device AI search models (~110 MB, one-time download)</p>
        <p className={styles.infoRow}>🔒 Nothing ever leaves your phone</p>
      </div>

      <motion.button
        className={styles.startBtn}
        onClick={onStart}
        whileTap={{ scale: 0.96 }}
        animate={{
          boxShadow: [
            '0 8px 32px rgba(124,111,255,0.3)',
            '0 8px 48px rgba(124,111,255,0.55)',
            '0 8px 32px rgba(124,111,255,0.3)',
          ]
        }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        Start Scanning
      </motion.button>
    </motion.div>
  )
}

// ─── Permission Denied ────────────────────────────────────────────────────────
function PermDeniedState({ onRetry }) {
  return (
    <motion.div
      className={styles.centered}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <div className={styles.errorIcon}>
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="10" stroke="var(--status-warning)" strokeWidth="1.8" />
          <path d="M12 7V13" stroke="var(--status-warning)" strokeWidth="2" strokeLinecap="round" />
          <circle cx="12" cy="16" r="1" fill="var(--status-warning)" />
        </svg>
      </div>
      <h2 className={styles.title}>Permission Required</h2>
      <p className={styles.desc}>
        Sparple needs storage access to scan your files.
        Please tap Allow on the permission dialog, or go to{' '}
        <strong>Settings → Apps → Sparple → Permissions → Storage</strong> and enable it.
      </p>
      <button className={styles.startBtn} onClick={onRetry}>
        Try Again
      </button>
    </motion.div>
  )
}

// ─── Model Downloading ────────────────────────────────────────────────────────
function DownloadingState({ pct, label }) {
  return (
    <motion.div
      className={styles.centered}
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.35 }}
    >
      {/* Pulsing brain icon */}
      <motion.div
        className={styles.modelIcon}
        animate={{ scale: [1, 1.07, 1], opacity: [0.85, 1, 0.85] }}
        transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
      >
        <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
          <circle cx="26" cy="26" r="25" stroke="url(#model-grad)" strokeWidth="1.5" />
          {/* Brain outline simplified */}
          <path d="M20 18C17 18 15 20 15 23C15 25 16 26.5 18 27C16 28 15 29.5 15 31C15 34 17 36 20 36H22V18H20Z"
            stroke="white" strokeWidth="1.5" strokeLinecap="round" fill="none" opacity="0.9" />
          <path d="M32 18C35 18 37 20 37 23C37 25 36 26.5 34 27C36 28 37 29.5 37 31C37 34 35 36 32 36H30V18H32Z"
            stroke="white" strokeWidth="1.5" strokeLinecap="round" fill="none" opacity="0.9" />
          <line x1="26" y1="18" x2="26" y2="36" stroke="white" strokeWidth="1.5" opacity="0.4" />
          <defs>
            <linearGradient id="model-grad" x1="0" y1="0" x2="52" y2="52">
              <stop offset="0%" stopColor="#7C6FFF" />
              <stop offset="100%" stopColor="#A855F7" />
            </linearGradient>
          </defs>
        </svg>
      </motion.div>

      <h1 className={styles.title}>Setting Up AI Search</h1>
      <p className={styles.desc}>
        Downloading the on-device AI model that powers semantic search.
        This only happens once — after this, everything works offline.
      </p>

      {/* Progress bar */}
      <div className={styles.modelProgressWrap}>
        <div className={styles.progressHeader}>
          <span className={styles.progressLabel}>{label}</span>
          <span className={styles.progressPct}>{pct}%</span>
        </div>
        <div className={styles.progressTrack}>
          <motion.div
            className={styles.progressFill}
            animate={{ width: `${pct}%` }}
            transition={{ duration: 0.4, ease: 'easeOut' }}
          />
          <motion.div
            className={styles.progressGlow}
            animate={{ width: `${pct}%` }}
            transition={{ duration: 0.4, ease: 'easeOut' }}
          />
        </div>
      </div>

      <div className={styles.modelInfoChips}>
        {['Text search · MiniLM', 'Image search · CLIP', '~110 MB total'].map(t => (
          <span key={t} className={styles.chip}>{t}</span>
        ))}
      </div>

      <p className={styles.privacyNote}>
        Model runs 100% on your device after download
      </p>
    </motion.div>
  )
}

// ─── Scanning ─────────────────────────────────────────────────────────────────
function ScanningState({ progress, message, currentFile }) {
  return (
    <motion.div
      className={styles.centered}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <div className={styles.scannerVisual}>
        {['📄', '🖼️', '📋', '🗂️', '📊'].map((icon, i) => (
          <motion.div
            key={i}
            className={styles.floatingFile}
            style={{ left: `${10 + i * 18}%`, top: `${20 + (i % 2) * 30}%` }}
            animate={{ y: [0, -8, 0], opacity: [0.4, 0.8, 0.4], scale: [0.9, 1.05, 0.9] }}
            transition={{ duration: 2, repeat: Infinity, delay: i * 0.3, ease: 'easeInOut' }}
          >
            {icon}
          </motion.div>
        ))}
        <div className={styles.vaultCenter}>
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 4, repeat: Infinity, ease: 'linear' }}
            style={{ position: 'absolute' }}
          >
            <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
              <circle cx="40" cy="40" r="38" stroke="url(#scan-ring-grad)" strokeWidth="1.5" strokeDasharray="4 6" />
              <defs>
                <linearGradient id="scan-ring-grad" x1="0" y1="0" x2="80" y2="80">
                  <stop offset="0%" stopColor="#7C6FFF" />
                  <stop offset="100%" stopColor="#A855F7" />
                </linearGradient>
              </defs>
            </svg>
          </motion.div>
          <div className={styles.vaultIcon}>
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
              <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
              <path d="M2 17L12 22L22 17" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
              <path d="M2 12L12 17L22 12" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
            </svg>
          </div>
        </div>
      </div>

      <div className={styles.progressSection}>
        <div className={styles.progressHeader}>
          <span className={styles.progressLabel}>{message}</span>
          <span className={styles.progressPct}>{progress}%</span>
        </div>
        <div className={styles.progressTrack}>
          <motion.div
            className={styles.progressFill}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
          />
          <motion.div
            className={styles.progressGlow}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
          />
        </div>
        {currentFile && (
          <p className={styles.currentFile} title={currentFile}>
            {currentFile.split('/').pop()}
          </p>
        )}
      </div>

      <p className={styles.privacyNote}>Your files never leave your device</p>
    </motion.div>
  )
}

// ─── Complete ─────────────────────────────────────────────────────────────────
function CompleteState({ result, onDone }) {
  return (
    <motion.div
      className={styles.centered}
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, ease: [0.34, 1.56, 0.64, 1] }}
    >
      <motion.div
        className={styles.successIcon}
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.2, duration: 0.5, ease: [0.34, 1.56, 0.64, 1] }}
      >
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none">
          <motion.path
            d="M5 12L10 17L19 8"
            stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ delay: 0.4, duration: 0.6 }}
          />
        </svg>
      </motion.div>

      <h2 className={styles.title}>All Done!</h2>
      <p className={styles.desc}>
        Indexed {result?.newFiles || 0} new documents in{' '}
        {Math.round((result?.durationMs || 0) / 1000)}s
      </p>

      <div className={styles.resultStats}>
        <ResultStat value={result?.totalFiles || 0} label="Files scanned" />
        <ResultStat value={result?.newFiles || 0} label="New indexed" accent />
      </div>

      <motion.button
        className={styles.startBtn}
        onClick={onDone}
        whileTap={{ scale: 0.96 }}
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
      >
        View My Vault
      </motion.button>
    </motion.div>
  )
}

// ─── Error ────────────────────────────────────────────────────────────────────
function ErrorState({ error, onRetry }) {
  const [copied, setCopied] = useState(false)

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(error || '')
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    } catch {
      // Clipboard API unavailable — user can still select text manually
    }
  }

  return (
    <motion.div
      className={styles.centered}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <div className={styles.errorIcon}>
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="10" stroke="var(--status-error)" strokeWidth="1.8" />
          <path d="M12 8V12M12 16H12.01" stroke="var(--status-error)" strokeWidth="2" strokeLinecap="round" />
        </svg>
      </div>
      <h2 className={styles.title}>Scan Failed</h2>
      <pre
        style={{
          whiteSpace: 'pre-wrap',
          wordBreak: 'break-word',
          textAlign: 'left',
          fontSize: '12px',
          lineHeight: 1.5,
          maxHeight: '30vh',
          overflowY: 'auto',
          background: 'rgba(255,255,255,0.05)',
          border: '1px solid rgba(255,255,255,0.1)',
          borderRadius: '8px',
          padding: '12px',
          margin: '12px 0',
          color: 'var(--text-secondary, #aaa)',
        }}
      >
        {error || 'Something went wrong. Make sure storage permission is granted.'}
      </pre>
      <button className={styles.startBtn} onClick={handleCopy} style={{ marginBottom: 8 }}>
        {copied ? 'Copied!' : 'Copy error details'}
      </button>
      <button className={styles.startBtn} onClick={onRetry}>Try Again</button>
    </motion.div>
  )
}

function ResultStat({ value, label, accent }) {
  return (
    <div className={styles.resultStat}>
      <span
        className={styles.resultValue}
        style={accent ? { background: 'var(--gradient-accent)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' } : {}}
      >
        {value}
      </span>
      <span className={styles.resultLabel}>{label}</span>
    </div>
  )
}
