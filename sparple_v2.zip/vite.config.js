import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { resolve } from 'path'

export default defineConfig({
  plugins: [react()],

  resolve: {
    alias: {
      '@': resolve(__dirname, './src'),
    },
  },

  build: {
    outDir: 'dist',
    sourcemap: false,
    // Raise the chunk-size warning threshold — ONNX and Tesseract are big by nature.
    chunkSizeWarningLimit: 4096,
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom', 'react-router-dom'],
          pdf:    ['pdfjs-dist'],
          ocr:    ['tesseract.js'],
          ai:     ['@xenova/transformers'],
        },
      },
    },
  },

  optimizeDeps: {
    // sql.js and onnxruntime-web ship pre-built WASM — skip Vite's bundler.
    exclude: ['sql.js', 'onnxruntime-web'],
  },

  worker: {
    format: 'es',
  },

  // Vite's dev server needs these headers too so local testing works.
  server: {
    headers: {
      'Cross-Origin-Embedder-Policy': 'require-corp',
      'Cross-Origin-Opener-Policy': 'same-origin',
    },
  },
})
