/**
 * Copies onnxruntime-web WASM binaries into public/ at build time.
 *
 * Why: @xenova/transformers loads ONNX Runtime WASM files at runtime.
 * By default it fetches them from jsDelivr CDN. Inside a Capacitor Android
 * WebView (capacitor:// scheme) those CDN fetches can fail with CORS / mixed-
 * content errors, making the model completely non-functional.
 *
 * Bundling the WASM files with the app means:
 *   1. Zero CDN dependency — model works fully offline after first download.
 *   2. No CORS / scheme issues inside the WebView.
 *   3. We only copy the single-threaded variants because Android WebView
 *      does not support SharedArrayBuffer (required for the threaded WASM),
 *      so the threaded files are dead weight.
 */
import { copyFileSync, existsSync, mkdirSync, readdirSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'

const __dirname = dirname(fileURLToPath(import.meta.url))
const root = join(__dirname, '..')
const destDir = join(root, 'public')

if (!existsSync(destDir)) mkdirSync(destDir, { recursive: true })

// onnxruntime-web ships its WASM files in dist/
const ortDist = join(root, 'node_modules', 'onnxruntime-web', 'dist')

if (!existsSync(ortDist)) {
  console.warn('[Sparple] onnxruntime-web dist not found — skipping WASM copy.')
  console.warn('          Run: npm install')
  process.exit(0)
}

// Copy every .wasm file that is NOT the threaded variant.
// Threaded WASM requires SharedArrayBuffer which is unavailable in Android WebView.
const files = readdirSync(ortDist).filter(f => f.endsWith('.wasm') && !f.includes('threaded'))

if (files.length === 0) {
  console.warn('[Sparple] No single-threaded WASM files found in onnxruntime-web/dist — check package version.')
} else {
  for (const file of files) {
    copyFileSync(join(ortDist, file), join(destDir, file))
    console.log(`[Sparple] Copied ${file} -> public/${file}`)
  }
}

// Also copy the onnxruntime-web JS shim (some Transformers.js builds look for it)
const ortJs = join(ortDist, 'ort.min.js')
const ortJsFallback = join(ortDist, 'ort.js')
if (existsSync(ortJs)) {
  copyFileSync(ortJs, join(destDir, 'ort.min.js'))
  console.log('[Sparple] Copied ort.min.js -> public/ort.min.js')
} else if (existsSync(ortJsFallback)) {
  copyFileSync(ortJsFallback, join(destDir, 'ort.js'))
  console.log('[Sparple] Copied ort.js -> public/ort.js')
}

console.log('[Sparple] ONNX WASM copy complete.')
