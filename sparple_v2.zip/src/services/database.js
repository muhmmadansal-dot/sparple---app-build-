/**
 * SPARPLE Database Service
 * SQLite via sql.js — fully offline, persisted to Capacitor Filesystem
 */

import { Filesystem, Directory, Encoding } from '@capacitor/filesystem'

let db = null
let SQL = null

const DB_PATH = 'sparple_vault.db'

export async function initDB() {
  if (db) return db

  // Dynamically import sql.js
  const sqljs = await import('sql.js')
  SQL = await sqljs.default({
    locateFile: (file) => `/${file}`,
  })

  // Try to load existing DB
  try {
    const result = await Filesystem.readFile({
      path: DB_PATH,
      directory: Directory.Data,
    })
    const binaryData = base64ToUint8Array(result.data)
    db = new SQL.Database(binaryData)
    console.log('[Sparple DB] Loaded existing database')
  } catch {
    // No existing DB — create fresh
    db = new SQL.Database()
    console.log('[Sparple DB] Created new database')
  }

  await createSchema()
  return db
}

async function createSchema() {
  db.run(`
    CREATE TABLE IF NOT EXISTS documents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      original_name TEXT NOT NULL,
      path TEXT NOT NULL UNIQUE,
      type TEXT NOT NULL DEFAULT 'unknown',
      category TEXT NOT NULL DEFAULT 'Other',
      label TEXT NOT NULL DEFAULT 'Unknown',
      confidence INTEGER DEFAULT 0,
      extracted_text TEXT DEFAULT '',
      suggested_name TEXT DEFAULT '',
      file_size INTEGER DEFAULT 0,
      mime_type TEXT DEFAULT '',
      thumbnail_b64 TEXT DEFAULT '',
      needs_review INTEGER DEFAULT 0,
      is_starred INTEGER DEFAULT 0,
      embedding BLOB,
      created_at TEXT NOT NULL,
      modified_at TEXT NOT NULL,
      indexed_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS document_labels (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      document_id INTEGER NOT NULL,
      label TEXT NOT NULL,
      is_system INTEGER DEFAULT 1,
      FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE,
      UNIQUE(document_id, label)
    );

    CREATE TABLE IF NOT EXISTS labels (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      color TEXT DEFAULT '#7C6FFF',
      icon TEXT DEFAULT 'tag',
      is_system INTEGER DEFAULT 0,
      doc_count INTEGER DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS scan_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      scanned_at TEXT NOT NULL,
      total_files INTEGER DEFAULT 0,
      new_files INTEGER DEFAULT 0,
      duration_ms INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE VIRTUAL TABLE IF NOT EXISTS documents_fts
      USING fts5(
        name, extracted_text, label, category,
        content=documents, content_rowid=id
      );

    CREATE TRIGGER IF NOT EXISTS documents_fts_insert
      AFTER INSERT ON documents BEGIN
        INSERT INTO documents_fts(rowid, name, extracted_text, label, category)
        VALUES (new.id, new.name, new.extracted_text, new.label, new.category);
      END;

    CREATE TRIGGER IF NOT EXISTS documents_fts_update
      AFTER UPDATE ON documents BEGIN
        UPDATE documents_fts SET
          name = new.name,
          extracted_text = new.extracted_text,
          label = new.label,
          category = new.category
        WHERE rowid = new.id;
      END;

    CREATE TRIGGER IF NOT EXISTS documents_fts_delete
      AFTER DELETE ON documents BEGIN
        DELETE FROM documents_fts WHERE rowid = old.id;
      END;
  `)

  // Migration: add embedding column if this DB was created before semantic search existed
  try {
    db.run(`ALTER TABLE documents ADD COLUMN embedding BLOB`)
  } catch {
    // Column already exists — fine
  }

  // Seed default labels
  const defaultLabels = [
    { name: 'Important', color: '#F87171', icon: 'star' },
    { name: 'Government', color: '#818CF8', icon: 'landmark' },
    { name: 'Education', color: '#34D399', icon: 'graduation-cap' },
    { name: 'Medical', color: '#F87171', icon: 'heart-pulse' },
    { name: 'Financial', color: '#FBBF24', icon: 'wallet' },
    { name: 'Travel', color: '#60A5FA', icon: 'plane' },
    { name: 'Bills', color: '#A78BFA', icon: 'receipt' },
    { name: 'Shopping', color: '#FB923C', icon: 'shopping-bag' },
    { name: 'Identity', color: '#E879F9', icon: 'id-card' },
    { name: 'Certificates', color: '#2DD4BF', icon: 'award' },
    { name: 'Vehicle', color: '#94A3B8', icon: 'car' },
    { name: 'Property', color: '#86EFAC', icon: 'home' },
    { name: 'Other', color: '#64748B', icon: 'folder' },
  ]

  const now = new Date().toISOString()
  for (const label of defaultLabels) {
    db.run(
      `INSERT OR IGNORE INTO labels (name, color, icon, is_system, doc_count, created_at)
       VALUES (?, ?, ?, 1, 0, ?)`,
      [label.name, label.color, label.icon, now]
    )
  }

  await persistDB()
}

export async function persistDB() {
  if (!db) return
  const data = db.export()
  const base64 = uint8ArrayToBase64(data)
  await Filesystem.writeFile({
    path: DB_PATH,
    data: base64,
    directory: Directory.Data,
  })
}

// --- Document CRUD ---

export function insertDocument(doc) {
  const now = new Date().toISOString()
  db.run(`
    INSERT OR REPLACE INTO documents
      (name, original_name, path, type, category, label, confidence,
       extracted_text, suggested_name, file_size, mime_type, thumbnail_b64,
       needs_review, is_starred, created_at, modified_at, indexed_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
  `, [
    doc.name, doc.originalName, doc.path, doc.type, doc.category,
    doc.label, doc.confidence, doc.extractedText, doc.suggestedName,
    doc.fileSize, doc.mimeType, doc.thumbnailB64 || '',
    doc.needsReview ? 1 : 0, 0,
    doc.createdAt || now, doc.modifiedAt || now, now,
  ])
  return db.exec('SELECT last_insert_rowid() as id')[0]?.values[0][0]
}

export function insertDocumentLabels(documentId, labels, isSystem = true) {
  for (const label of labels) {
    db.run(
      `INSERT OR IGNORE INTO document_labels (document_id, label, is_system)
       VALUES (?, ?, ?)`,
      [documentId, label, isSystem ? 1 : 0]
    )
    db.run(`UPDATE labels SET doc_count = doc_count + 1 WHERE name = ?`, [label])
  }
}

export function getDocuments({ category, label, needsReview, starred, limit = 50, offset = 0 } = {}) {
  let query = `SELECT d.*, GROUP_CONCAT(dl.label, '|') as all_labels
               FROM documents d
               LEFT JOIN document_labels dl ON d.id = dl.document_id
               WHERE 1=1`
  const params = []

  if (category) { query += ` AND d.category = ?`; params.push(category) }
  if (label) { query += ` AND dl.label = ?`; params.push(label) }
  if (needsReview) { query += ` AND d.needs_review = 1` }
  if (starred) { query += ` AND d.is_starred = 1` }

  query += ` GROUP BY d.id ORDER BY d.indexed_at DESC LIMIT ? OFFSET ?`
  params.push(limit, offset)

  return execQuery(query, params)
}

export function searchDocuments(query, limit = 50) {
  if (!query.trim()) return getDocuments({ limit })

  return execQuery(`
    SELECT d.*, GROUP_CONCAT(dl.label, '|') as all_labels,
           highlight(documents_fts, 1, '<mark>', '</mark>') as highlighted_text
    FROM documents_fts
    JOIN documents d ON d.id = documents_fts.rowid
    LEFT JOIN document_labels dl ON d.id = dl.document_id
    WHERE documents_fts MATCH ?
    GROUP BY d.id
    ORDER BY rank
    LIMIT ?
  `, [query + '*', limit])
}

export function updateDocumentLabel(id, type, label, category) {
  db.run(
    `UPDATE documents SET type = ?, label = ?, category = ?, needs_review = 0
     WHERE id = ?`,
    [type, label, category, id]
  )
}

export function renameDocument(id, newName) {
  db.run(`UPDATE documents SET name = ?, modified_at = ? WHERE id = ?`,
    [newName, new Date().toISOString(), id])
}

export function toggleStar(id) {
  db.run(`UPDATE documents SET is_starred = NOT is_starred WHERE id = ?`, [id])
}

export function getStats() {
  const result = execQuery(`
    SELECT
      COUNT(*) as total,
      SUM(CASE WHEN needs_review = 1 THEN 1 ELSE 0 END) as needs_review,
      SUM(CASE WHEN is_starred = 1 THEN 1 ELSE 0 END) as starred,
      COUNT(DISTINCT category) as categories
    FROM documents
  `)
  return result[0] || { total: 0, needs_review: 0, starred: 0, categories: 0 }
}

export function getCategoryCounts() {
  return execQuery(`
    SELECT category, COUNT(*) as count
    FROM documents
    GROUP BY category
    ORDER BY count DESC
  `)
}

export function getLabels() {
  return execQuery(`SELECT * FROM labels ORDER BY is_system DESC, name ASC`)
}

export function documentExists(path) {
  const result = execQuery(`SELECT id FROM documents WHERE path = ?`, [path])
  return result.length > 0
}

export function insertScanHistory(record) {
  db.run(
    `INSERT INTO scan_history (scanned_at, total_files, new_files, duration_ms)
     VALUES (?, ?, ?, ?)`,
    [new Date().toISOString(), record.totalFiles, record.newFiles, record.durationMs]
  )
}

// --- Semantic search support ---

export function setDocumentEmbedding(id, bytes) {
  if (!bytes) return
  db.run(`UPDATE documents SET embedding = ? WHERE id = ?`, [bytes, id])
}

/**
 * Returns every document that has a stored embedding, as
 * [{ id, embedding: Uint8Array }]. Used to compute similarity scores
 * against a query vector at search time.
 */
export function getAllEmbeddings() {
  if (!db) return []
  try {
    const result = db.exec(`SELECT id, embedding FROM documents WHERE embedding IS NOT NULL`)
    if (!result.length) return []
    const { columns, values } = result[0]
    const idIdx = columns.indexOf('id')
    const embIdx = columns.indexOf('embedding')
    return values.map(row => ({ id: row[idIdx], embedding: row[embIdx] }))
  } catch (err) {
    console.error('[Sparple DB] getAllEmbeddings error:', err)
    return []
  }
}

export function getDocumentsByIds(ids) {
  if (!ids || !ids.length) return {}
  const placeholders = ids.map(() => '?').join(',')
  const rows = execQuery(`
    SELECT d.*, GROUP_CONCAT(dl.label, '|') as all_labels
    FROM documents d
    LEFT JOIN document_labels dl ON d.id = dl.document_id
    WHERE d.id IN (${placeholders})
    GROUP BY d.id
  `, ids)
  const byId = {}
  for (const row of rows) byId[row.id] = row
  return byId
}

// --- Helpers ---

function execQuery(sql, params = []) {
  try {
    const result = db.exec(sql, params)
    if (!result.length) return []
    const { columns, values } = result[0]
    return values.map(row => {
      const obj = {}
      columns.forEach((col, i) => { obj[col] = row[i] })
      return obj
    })
  } catch (err) {
    console.error('[Sparple DB] Query error:', err, sql)
    return []
  }
}

function uint8ArrayToBase64(uint8Array) {
  let binary = ''
  for (let i = 0; i < uint8Array.length; i++) {
    binary += String.fromCharCode(uint8Array[i])
  }
  return btoa(binary)
}

function base64ToUint8Array(base64) {
  const binary = atob(base64)
  const uint8Array = new Uint8Array(binary.length)
  for (let i = 0; i < binary.length; i++) {
    uint8Array[i] = binary.charCodeAt(i)
  }
  return uint8Array
}
