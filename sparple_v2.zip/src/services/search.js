/**
 * SPARPLE Search Service
 * Hybrid search: SQLite FTS5 (exact/keyword matches) combined with
 * on-device semantic similarity (understands meaning, not just words).
 *
 * Example: searching "my passport" will match a document whose extracted
 * text never says the word "passport" but whose content (MRZ lines,
 * "Republic of India", a photo page, etc.) is semantically close to it.
 */

import { searchDocuments as ftsSearch, getDocuments, getAllEmbeddings, getDocumentsByIds } from './database.js'
import { embedText, cosineSimilarity, bytesToVector, getModelStatus } from './embeddings.js'

const SEMANTIC_MIN_SCORE = 0.32 // below this, a "semantic" match is just noise

export async function search(query, { limit = 30 } = {}) {
  const q = (query || '').trim()
  if (!q) return { results: getDocuments({ limit }), semanticActive: false }

  // 1. Lexical (fast, exact word/prefix matches, always available)
  const lexical = ftsSearch(q, limit)
  const scored = new Map()
  lexical.forEach((doc, i) => {
    // Earlier rank = stronger keyword match
    scored.set(doc.id, { doc, score: 1.4 - i * (1 / Math.max(lexical.length, 1)) })
  })

  // 2. Semantic (understands meaning — runs the on-device model)
  let semanticActive = false
  if (getModelStatus() !== 'error') {
    try {
      const qVec = await embedText(q)
      if (qVec) {
        const all = getAllEmbeddings()
        if (all.length) {
          semanticActive = true
          const ranked = all
            .map(({ id, embedding }) => ({ id, sim: cosineSimilarity(qVec, bytesToVector(embedding)) }))
            .filter(r => r.sim >= SEMANTIC_MIN_SCORE)
            .sort((a, b) => b.sim - a.sim)
            .slice(0, limit)

          if (ranked.length) {
            const docsById = getDocumentsByIds(ranked.map(r => r.id))
            for (const r of ranked) {
              const doc = docsById[r.id]
              if (!doc) continue
              const existing = scored.get(r.id)
              if (existing) {
                existing.score += r.sim
              } else {
                scored.set(r.id, { doc, score: r.sim })
              }
            }
          }
        }
      }
    } catch (err) {
      console.warn('[Search] Semantic search skipped:', err)
    }
  }

  const results = Array.from(scored.values())
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(({ doc, score }) => ({ ...doc, _matchScore: score }))

  return { results, semanticActive }
}
