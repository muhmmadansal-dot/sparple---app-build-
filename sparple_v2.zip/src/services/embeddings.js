/**
 * SPARPLE Embeddings Service
 *
 * Model:  Xenova/all-MiniLM-L6-v2  (quantized ONNX, ~23 MB)
 * Fetched from Hugging Face Hub on first scan, then cached in browser Cache Storage.
 * Every subsequent search is 100% offline.
 *
 * ──────────────────────────────────────────────────────────────────────────────
 * Android WebView compatibility
 * ──────────────────────────────────────────────────────────────────────────────
 * Problem 1 — WASM files
 *   @xenova/transformers + onnxruntime-web fetch .wasm binaries from jsDelivr CDN
 *   by default.  Inside a Capacitor WebView (capacitor:// scheme) those CDN fetches
 *   can fail silently due to mixed-content / scheme restrictions.
 *
 *   Fix: scripts/copy-onnx-wasm.js copies the .wasm files into public/ at build
 *   time.  We set wasmPaths = '/' so ONNX Runtime loads them from the bundled app.
 *
 * Problem 2 — SharedArrayBuffer / multi-threading
 *   ONNX Runtime's threaded WASM backend requires SharedArrayBuffer, which Android
 *   WebView only makes available when cross-origin isolation headers are present.
 *   We inject those headers in MainActivity.java.  As a belt-and-suspenders safety
 *   net we also set numThreads = 1 here, so ONNX falls back to single-threaded WASM
 *   (which works everywhere) if the headers are somehow absent.
 * ──────────────────────────────────────────────────────────────────────────────
 */

import { env, pipeline } from '@xenova/transformers'

// ── ONNX / WASM configuration (must happen before first pipeline() call) ─────

// Load bundled .wasm files from public/ — not from a CDN.
// This is set on the onnxruntime-web env that @xenova/transformers re-exports.
env.backends.onnx.wasm.wasmPaths = '/'

// Force single-thread mode as a fallback safety net.
// If MainActivity.java successfully injects COOP/COEP headers, ONNX Runtime
// will auto-detect SharedArrayBuffer support and upgrade to multi-thread.
// If not, numThreads=1 ensures it still works without throwing.
env.backends.onnx.wasm.numThreads = 1

// Blob-URL-based proxy worker is blocked in WebView CSP — disable it.
env.backends.onnx.wasm.proxy = false

// ── Hugging Face / cache settings ────────────────────────────────────────────

// Cache downloaded model weights in browser Cache Storage (persists across restarts).
env.useBrowserCache = true

// Never look for models on localhost.
env.allowLocalModels = false

// ── Pipeline singleton ────────────────────────────────────────────────────────

const MODEL_ID = 'Xenova/all-MiniLM-L6-v2'

let _promise = null
let _status  = 'idle'   // 'idle' | 'downloading' | 'ready' | 'error'

export function getModelStatus() { return _status }

/**
 * Load the feature-extraction pipeline.
 * Idempotent — subsequent calls return the existing promise.
 *
 * onProgress?: ({ pct: number, label: string }) => void
 */
export function loadModel(onProgress) {
  if (_promise) return _promise

  _status = 'downloading'

  _promise = pipeline('feature-extraction', MODEL_ID, {
    quantized: true,   // q8 — ~23 MB, runs well on mid-range Android CPUs

    progress_callback: (info) => {
      if (!onProgress) return
      // @xenova/transformers v2 fires status 'progress' or 'download'
      if (info.status === 'progress' || info.status === 'download') {
        const pct = info.total ? Math.round((info.loaded / info.total) * 100) : 0
        onProgress({
          pct,
          label: pct < 99
            ? `Downloading AI model… ${pct}%`
            : 'Almost ready…',
        })
      }
    },
  })
  .then((model) => {
    _status = 'ready'
    return model
  })
  .catch((err) => {
    _status  = 'error'
    _promise = null   // allow retry on next scan attempt
    console.error('[Embeddings] Model load failed:', err)
    throw err
  })

  return _promise
}

/**
 * Pre-warm the model before scanning begins.
 * Returns true if model loaded OK, false if we should fall back to keyword-only.
 */
export async function preloadModel(onProgress) {
  try {
    await loadModel(onProgress)
    return true
  } catch {
    return false
  }
}

/**
 * Embed a text string → normalized Float32Array[384], or null on failure.
 */
export async function embedText(text) {
  const s = (text || '').trim().slice(0, 2000)
  if (!s) return null
  try {
    const pipe = await loadModel()
    const out  = await pipe(s, { pooling: 'mean', normalize: true })
    return Float32Array.from(out.data)
  } catch (err) {
    console.warn('[Embeddings] embedText failed:', err)
    return null
  }
}

/**
 * Dot-product cosine similarity.
 * Vectors from the pipeline are already L2-normalised, so dot == cosine.
 */
export function cosineSimilarity(a, b) {
  if (!a || !b || a.length !== b.length) return 0
  let d = 0
  for (let i = 0; i < a.length; i++) d += a[i] * b[i]
  return d
}

// ── Float32Array ↔ raw bytes for SQLite BLOB persistence ─────────────────────

export function vectorToBytes(vec) {
  if (!vec) return null
  const buf = vec.buffer
  return new Uint8Array(buf.slice ? buf.slice(0) : buf)
}

export function bytesToVector(bytes) {
  if (!bytes || !bytes.length) return null
  const buf = bytes.buffer
    ? bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength)
    : bytes
  return new Float32Array(buf)
}
