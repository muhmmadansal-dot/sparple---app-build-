/**
 * Copies sql.js's WASM binary into public/ at build time.
 *
 * ROOT CAUSE FOUND (from an actual in-app runtime error, copy-pasted by the
 * user via the "Copy error details" button — not guessed):
 *
 *   Error: both async and sync fetching of the wasm failed
 *     at ... sql-wasm-browser-*.js ...
 *
 * This error was ALWAYS coming from sql.js (the SQLite engine), not from
 * ONNX Runtime / @xenova/transformers. Every previous fix attempt patched
 * the ONNX WASM copy script — which was a real bug too, but not THIS bug.
 * database.js sets `locateFile: (file) => \`/${file}\`` telling sql.js to
 * fetch its wasm binary (sql-wasm.wasm) from the app root at runtime, but
 * nothing ever copied that file into public/. It was 404ing from day one.
 *
 * Fix: copy sql-wasm.wasm (and any other sql.js dist file that might be
 * requested) from node_modules/sql-wasm's actual package name is "sql.js",
 * dist folder into public/. Hard-fails the build if not found.
 */
import { copyFileSync, existsSync, mkdirSync, readdirSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'

const __dirname = dirname(fileURLToPath(import.meta.url))
const root = join(__dirname, '..')
const destDir = join(root, 'public')

if (!existsSync(destDir)) mkdirSync(destDir, { recursive: true })

const sqlJsDist = join(root, 'node_modules', 'sql.js', 'dist')

if (!existsSync(sqlJsDist)) {
  console.error(`[Sparple] FATAL: could not find sql.js dist at ${sqlJsDist}`)
  console.error('[Sparple] Run `npm install` first. Aborting build — without')
  console.error('           sql-wasm.wasm the entire database layer will fail')
  console.error('           at runtime with "both async and sync fetching of the wasm failed".')
  process.exit(1)
}

// Copy every .wasm file, plus the loader .js files (some builds need both
// the browser and worker variants depending on how sql.js is imported).
const files = readdirSync(sqlJsDist).filter(f => f.endsWith('.wasm') || f.endsWith('.js'))

if (!files.some(f => f.endsWith('.wasm'))) {
  console.error(`[Sparple] FATAL: no .wasm file found in ${sqlJsDist}`)
  console.error('[Sparple] sql.js may have changed its dist layout. Aborting build.')
  process.exit(1)
}

for (const file of files) {
  copyFileSync(join(sqlJsDist, file), join(destDir, file))
  console.log(`[Sparple] Copied ${file} -> public/${file}`)
}

console.log(`[Sparple] sql.js WASM copy complete: ${files.length} file(s) copied.`)
